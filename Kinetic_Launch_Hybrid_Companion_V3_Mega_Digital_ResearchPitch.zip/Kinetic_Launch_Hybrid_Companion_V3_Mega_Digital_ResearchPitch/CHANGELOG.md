# Changelog

## 3.0.0 Mega Digital Upgrade
- Unified two source projects under one orchestrated package.
- Added mega_core orchestration, compatibility, event ledger, readiness and scenario layers.
- Added schemas, provenance, interface contracts, migration guide, examples and CI-style validation.
- Preserved digital-only safety boundary.

## V3.1 Research Pitch Addition

- Added a quick 6-slide presentation draft for the cold distortion engine research concept.
- Added oral pitch scripts at 15s / 45s / 90s length.
- Added a structured research scope card and a reusable example request.
- Maintains strict digital-only boundaries: no propulsion recipe, physical dimensions, ignition, trajectory, release-load or manufacturing details.
