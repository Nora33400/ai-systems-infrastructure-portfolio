const pptxgen = require('pptxgenjs');
const { warnIfSlideHasOverlaps, warnIfSlideElementsOutOfBounds } = require('/home/oai/skills/slides/pptxgenjs_helpers');

const pptx = new pptxgen();
pptx.layout = 'LAYOUT_WIDE';
pptx.author = 'Nora / AIONE Research';
pptx.subject = 'Ébauche de présentation rapide — moteur à distorsion froide';
pptx.title = 'Moteur à distorsion froide — Pitch recherche';
pptx.company = 'AIONE / Kinetic Digital Package';
pptx.lang = 'fr-FR';
pptx.theme = {
  headFontFace: 'Aptos Display',
  bodyFontFace: 'Aptos',
  lang: 'fr-FR'
};
pptx.defineLayout({ name: 'CUSTOM_WIDE', width: 13.333, height: 7.5 });
pptx.layout = 'CUSTOM_WIDE';
pptx.margin = 0;

const W = 13.333, H = 7.5;
const C = {
  bg: '08111F',
  bg2: '0E1E33',
  ink: 'F4F7FB',
  muted: 'B5C0CE',
  line: '59708C',
  cyan: '67E8F9',
  blue: '60A5FA',
  violet: 'A78BFA',
  green: '86EFAC',
  amber: 'FCD34D',
  red: 'FDA4AF',
  panel: '10233A',
  panel2: '122943',
  white: 'FFFFFF'
};

function bg(slide) {
  slide.background = { color: C.bg };
  slide.addShape(pptx.ShapeType.rect, { x:0, y:0, w:W, h:H, fill:{color:C.bg}, line:{color:C.bg} });
  slide.addShape(pptx.ShapeType.rect, { x:0.25, y:0.25, w:12.833, h:7.0, fill:{color:C.bg, transparency:100}, line:{color:'203A59', transparency:30, pt:0.8} });
}
function title(slide, t, sub) {
  slide.addText(t, {x:0.55, y:0.42, w:8.6, h:0.48, fontFace:'Aptos Display', fontSize:30, bold:true, color:C.ink, margin:0});
  if (sub) slide.addText(sub, {x:0.58, y:0.96, w:8.8, h:0.3, fontSize:12.5, color:C.muted, margin:0});
}
function footer(slide, n) {
  slide.addText('AIONE · Kinetic Digital Package · version recherche non-physique', {x:0.55, y:7.08, w:7.3, h:0.25, fontSize:8.5, color:'7891AD', margin:0});
  slide.addText(String(n).padStart(2,'0'), {x:12.35, y:7.02, w:0.42, h:0.26, fontSize:9, bold:true, color:C.cyan, align:'right', margin:0});
}
function pill(slide, text, x, y, w, color) {
  slide.addShape(pptx.ShapeType.roundRect, {x, y, w, h:0.34, rectRadius:0.08, fill:{color, transparency:12}, line:{color, transparency:0, pt:0.8}});
  slide.addText(text, {x:x+0.1, y:y+0.085, w:w-0.2, h:0.14, fontSize:8.7, color:C.ink, bold:true, margin:0, align:'center'});
}
function panel(slide, x, y, w, h, opts={}) {
  slide.addShape(pptx.ShapeType.roundRect, {x,y,w,h,rectRadius:0.12,fill:{color:opts.fill||C.panel, transparency: opts.tr||0}, line:{color:opts.line||'203A59', transparency: opts.ltr||15, pt:0.8}});
}
function node(slide, txt, x, y, w, h, color) {
  slide.addShape(pptx.ShapeType.roundRect, {x,y,w,h,rectRadius:0.12,fill:{color, transparency:8},line:{color, pt:1}});
  slide.addText(txt, {x:x+0.12, y:y+0.1, w:w-0.24, h:h-0.2, fontSize:12, bold:true, color:C.ink, align:'center', valign:'mid', margin:0});
}
function arrow(slide, x1,y1,x2,y2,color=C.line) {
  slide.addShape(pptx.ShapeType.line, {x:x1, y:y1, w:x2-x1, h:y2-y1, line:{color, pt:1.4, beginArrowType:'none', endArrowType:'triangle'}});
}
function check(slide) {
  warnIfSlideHasOverlaps(slide, pptx, { muteContainment:true, ignoreDecorativeShapes:true, ignoreLines:true });
  warnIfSlideElementsOutOfBounds(slide, pptx);
}

// Slide 1
{
  const s = pptx.addSlide(); bg(s);
  s.addText('Moteur à distorsion froide', {x:0.75,y:1.05,w:8.2,h:0.55,fontFace:'Aptos Display',fontSize:38,bold:true,color:C.ink,margin:0});
  s.addText('Ébauche rapide d’un travail de recherche — intégration numérique dans Kinetic V3', {x:0.78,y:1.73,w:8.7,h:0.38,fontSize:15,color:C.muted,margin:0});
  pill(s,'Hypothèse conceptuelle',0.82,2.34,2.0,C.violet);
  pill(s,'Digital twin abstrait',2.98,2.34,1.8,C.blue);
  pill(s,'Traçabilité & V&V',4.95,2.34,1.6,C.cyan);
  // Conceptual swirl: concentric ellipses no overlap warnings due to decorative containment muted
  const cx=10.55, cy=3.75;
  ['1.0','1.55','2.1','2.65'].forEach((r,i)=>{
    s.addShape(pptx.ShapeType.arc, {x:cx-parseFloat(r),y:cy-parseFloat(r)*0.58,w:parseFloat(r)*2,h:parseFloat(r)*1.16,adjustPoint:0.25,fill:{color:C.bg,transparency:100},line:{color:[C.cyan,C.blue,C.violet,C.green][i],pt:2-i*0.2,transparency: i*10},rotate:i*18});
  });
  s.addShape(pptx.ShapeType.ellipse, {x:9.92,y:3.37,w:1.26,h:0.76,fill:{color:C.cyan,transparency:30},line:{color:C.cyan,pt:1}});
  s.addText('NOX', {x:10.13,y:3.58,w:0.85,h:0.18,fontSize:12,bold:true,color:C.ink,align:'center',margin:0});
  s.addText('Statut : modèle exploratoire, non validé physiquement, documenté pour simulation et discussion.', {x:0.78,y:6.15,w:7.2,h:0.34,fontSize:11.5,color:'A9B8C9',margin:0});
  footer(s,1); check(s);
}

// Slide 2
{
  const s = pptx.addSlide(); bg(s); title(s,'1 · Idée de recherche','Remplacer la promesse physique par une représentation calculable et vérifiable.');
  panel(s,0.7,1.65,3.55,4.5,{fill:C.panel2});
  s.addText('Problème classique', {x:0.95,y:1.93,w:2.6,h:0.25,fontSize:16,bold:true,color:C.ink,margin:0});
  s.addText('• poussée / énergie / masse\n• contraintes thermiques\n• trajectoire et guidage\n• validation physique lourde', {x:0.98,y:2.42,w:2.8,h:1.4,fontSize:14,color:C.muted,breakLine:false,fit:'shrink',margin:0.02});
  panel(s,4.9,1.65,3.55,4.5,{fill:C.panel2});
  s.addText('Hypothèse froide', {x:5.15,y:1.93,w:2.6,h:0.25,fontSize:16,bold:true,color:C.ink,margin:0});
  s.addText('• carte de distances locale\n• pente d’espace abstraite\n• NOX comme noyau conceptuel\n• pas de recette physique', {x:5.18,y:2.42,w:2.8,h:1.4,fontSize:14,color:C.muted,margin:0.02});
  arrow(s,4.32,3.85,4.8,3.85,C.cyan);
  // right insight
  s.addShape(pptx.ShapeType.bracePair, {x:9.35,y:1.76,w:0.52,h:4.3,fill:{color:C.bg,transparency:100},line:{color:C.violet,pt:1.2}});
  s.addText('Objectif V3', {x:10.0,y:2.0,w:2.35,h:0.3,fontSize:18,bold:true,color:C.cyan,margin:0});
  s.addText('Décrire une architecture de recherche qui peut être reliée aux modules Kinetic sans transformer l’idée en plan de construction réel.', {x:10.0,y:2.55,w:2.35,h:1.42,fontSize:13.2,color:C.ink,margin:0.02,fit:'shrink'});
  s.addText('Livrable : scénario numérique, lexique, contraintes, risques, preuves de cohérence.', {x:10.0,y:4.55,w:2.35,h:0.72,fontSize:12.2,color:C.muted,margin:0.02,fit:'shrink'});
  footer(s,2); check(s);
}

// Slide 3
{
  const s = pptx.addSlide(); bg(s); title(s,'2 · Architecture conceptuelle','Une lecture en couches : noyau, champ, enveloppe, observabilité.');
  const cx=3.2, cy=4.0;
  s.addShape(pptx.ShapeType.ellipse,{x:1.0,y:2.0,w:4.4,h:4.0,fill:{color:C.blue,transparency:88},line:{color:C.blue,pt:1.2}});
  s.addShape(pptx.ShapeType.ellipse,{x:1.6,y:2.48,w:3.2,h:3.0,fill:{color:C.violet,transparency:82},line:{color:C.violet,pt:1.2}});
  s.addShape(pptx.ShapeType.ellipse,{x:2.28,y:3.05,w:1.84,h:1.85,fill:{color:C.cyan,transparency:28},line:{color:C.cyan,pt:1.2}});
  s.addText('NOX', {x:2.78,y:3.75,w:0.83,h:0.23,fontSize:16,bold:true,color:C.ink,align:'center',margin:0});
  node(s,'Noyau NOX\nsource hypothétique',6.1,1.7,2.5,0.8,C.cyan);
  node(s,'Champ froid\ntransition abstraite',9.1,2.65,2.55,0.8,C.blue);
  node(s,'Enveloppe cinétique\ninterface Kinetic',6.1,3.65,2.5,0.8,C.violet);
  node(s,'Observabilité\nlogs + métriques',9.1,4.62,2.55,0.8,C.green);
  arrow(s,8.62,2.1,9.02,2.97,C.line);
  arrow(s,9.0,3.55,8.65,3.96,C.line);
  arrow(s,8.62,4.08,9.02,4.93,C.line);
  s.addText('Point important', {x:0.9,y:6.35,w:1.8,h:0.26,fontSize:13,bold:true,color:C.amber,margin:0});
  s.addText('Le schéma est une carte de recherche numérique : il ne contient aucun dimensionnement ni procédé de fabrication.', {x:2.85,y:6.35,w:8.4,h:0.27,fontSize:12,color:C.muted,margin:0});
  footer(s,3); check(s);
}

// Slide 4
{
  const s = pptx.addSlide(); bg(s); title(s,'3 · Intégration dans le ZIP Kinetic','Transformer un concept en objet de projet vérifiable.');
  node(s,'Travail de recherche\n« distorsion froide »',0.85,2.0,2.25,0.9,C.violet);
  node(s,'Research Brief\nlexique + hypothèses',3.65,2.0,2.05,0.9,C.blue);
  node(s,'Digital Twin\nétats + scénarios',6.2,2.0,2.05,0.9,C.cyan);
  node(s,'Matrices\nrisques / V&V',8.75,2.0,2.05,0.9,C.green);
  node(s,'Dossier projet\nprêt à discuter',11.05,2.0,1.85,0.9,C.amber);
  arrow(s,3.15,2.45,3.58,2.45,C.line);
  arrow(s,5.76,2.45,6.13,2.45,C.line);
  arrow(s,8.32,2.45,8.68,2.45,C.line);
  arrow(s,10.86,2.45,11.0,2.45,C.line);
  panel(s,1.15,4.1,10.9,1.55,{fill:C.panel2});
  s.addText('Règle de sécurité du package', {x:1.42,y:4.38,w:3.0,h:0.25,fontSize:15,bold:true,color:C.ink,margin:0});
  s.addText('Les champs physiques sensibles sont remplacés par des variables abstraites, des scores normalisés et des preuves de cohérence logicielle.', {x:4.75,y:4.38,w:6.45,h:0.38,fontSize:12.8,color:C.muted,margin:0});
  pill(s,'Accepté : hypothèses, états, risques, métriques',1.45,5.17,3.45,C.green);
  pill(s,'Rejeté : recette, allumage, géométrie, trajectoire',5.3,5.17,3.55,C.red);
  footer(s,4); check(s);
}

// Slide 5
{
  const s = pptx.addSlide(); bg(s); title(s,'4 · Ébauche de pitch en 45 secondes','Une formulation simple pour présenter le travail sans surpromesse.');
  panel(s,0.85,1.55,5.7,4.65,{fill:C.panel2});
  s.addText('Pitch court', {x:1.15,y:1.9,w:2.0,h:0.3,fontSize:18,bold:true,color:C.cyan,margin:0});
  s.addText('« Je travaille sur un modèle exploratoire appelé moteur à distorsion froide. L’idée n’est pas de prouver aujourd’hui un moteur réel, mais de formaliser une architecture numérique capable de représenter une modification locale de la carte des distances. Le noyau NOX sert de centre conceptuel ; autour, j’ajoute un digital twin, des contraintes, des scénarios et une validation logicielle pour transformer l’intuition en objet de recherche partageable. »', {x:1.15,y:2.55,w:4.85,h:2.75,fontSize:14,color:C.ink,margin:0.02,fit:'shrink'});
  panel(s,7.05,1.55,5.15,4.65,{fill:C.panel2});
  s.addText('Ce que ça prouve / ne prouve pas', {x:7.35,y:1.9,w:3.3,h:0.3,fontSize:18,bold:true,color:C.amber,margin:0});
  s.addText('Prouve numériquement :\n• cohérence de vocabulaire\n• scénarios rejouables\n• garde-fous de périmètre\n• critères de discussion\n\nNe prouve pas :\n• propulsion réelle\n• antigravité\n• matériaux ou carburants physiques', {x:7.35,y:2.55,w:4.05,h:2.7,fontSize:13.5,color:C.muted,margin:0.02,fit:'shrink'});
  footer(s,5); check(s);
}

// Slide 6
{
  const s = pptx.addSlide(); bg(s); title(s,'5 · Roadmap de recherche','Passer d’une idée forte à un dossier numérique défendable.');
  const steps = [
    ['01','Lexique','NOX, champ froid, enveloppe, pente, matérialiseur'],
    ['02','Formalisme','variables abstraites, états, contraintes, invariants'],
    ['03','Simulation','scénarios nominaux, dégradés, impossibilités, logs'],
    ['04','Critique','ce qui manque, ce qui est faux, ce qui reste testable'],
    ['05','Présentation','pitch, figures, annexe technique non-sensible']
  ];
  steps.forEach((d,i)=>{
    const x = 0.8 + i*2.48;
    panel(s,x,1.85,2.05,3.55,{fill:i%2?C.panel:C.panel2});
    s.addText(d[0], {x:x+0.15,y:2.10,w:0.55,h:0.35,fontSize:18,bold:true,color:C.cyan,margin:0});
    s.addText(d[1], {x:x+0.15,y:2.68,w:1.6,h:0.32,fontSize:16,bold:true,color:C.ink,margin:0});
    s.addText(d[2], {x:x+0.15,y:3.32,w:1.65,h:1.55,fontSize:11.5,color:C.muted,margin:0.02,fit:'shrink'});
  });
  s.addText('Résultat attendu', {x:1.0,y:6.12,w:2.1,h:0.28,fontSize:15,bold:true,color:C.green,margin:0});
  s.addText('Un travail présentable comme recherche spéculative structurée : clair, traçable, discutable, sans confusion avec une validation physique.', {x:3.1,y:6.13,w:8.4,h:0.28,fontSize:12.4,color:C.muted,margin:0});
  footer(s,6); check(s);
}

pptx.writeFile({ fileName: '/mnt/data/Kinetic_Launch_Hybrid_Companion_V3_Mega_Digital_ResearchPitch/presentations/Moteur_Distortion_Froide_Quick_Pitch.pptx' });
