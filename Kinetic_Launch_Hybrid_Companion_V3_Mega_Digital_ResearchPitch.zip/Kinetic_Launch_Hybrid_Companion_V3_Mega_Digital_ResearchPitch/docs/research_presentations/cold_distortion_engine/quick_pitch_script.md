# Script oral — moteur à distorsion froide

## Version 15 secondes

Je travaille sur une architecture de recherche appelée **moteur à distorsion froide**. Le but n'est pas de fabriquer un moteur réel ici, mais de transformer une intuition spéculative en modèle numérique : un noyau NOX, une enveloppe de distorsion abstraite, des scénarios, des limites et une traçabilité vérifiable.

## Version 45 secondes

Je travaille sur un modèle exploratoire appelé **moteur à distorsion froide**. L'idée n'est pas de prouver aujourd'hui un moteur réel, mais de formaliser une architecture numérique capable de représenter une modification locale de la carte des distances. Le noyau NOX sert de centre conceptuel ; autour, j'ajoute un digital twin, des contraintes, des scénarios et une validation logicielle pour transformer l'intuition en objet de recherche partageable. Le résultat attendu est un dossier clair, discutable, reproductible et volontairement séparé de toute recette physique.

## Version 90 secondes

Mon travail part d'une intuition : au lieu de penser uniquement la propulsion comme une poussée classique, je veux représenter un système qui agirait sur la **structure relationnelle des distances**. Pour éviter la confusion avec une affirmation physique non prouvée, je le traite comme un objet de recherche numérique.

Le centre du modèle est le **noyau NOX**. Il ne désigne pas ici un composant réel, mais un point logique autour duquel s'organisent les hypothèses : champ froid, enveloppe cinétique, pente locale abstraite et observabilité. Le package Kinetic sert ensuite à transformer ce concept en artefact projet : lexique, états, scénarios, risques, matrices V&V, ledger et rapports.

Ce que cette recherche peut produire maintenant, c'est une architecture traçable, des simulations abstraites et une base de discussion. Ce qu'elle ne prétend pas produire, c'est une preuve de propulsion réelle, une antigravité démontrée ou un plan de construction. La valeur actuelle est donc dans la formalisation : rendre l'idée partageable, critiquable, testable numériquement et améliorable.

## Notes par slide

### 1. Titre
Présenter le sujet comme recherche spéculative structurée, pas comme moteur déjà validé.

### 2. Idée de recherche
Contraster propulsion classique et hypothèse froide. Insister sur la représentation numérique.

### 3. Architecture conceptuelle
Expliquer NOX, champ froid, enveloppe cinétique et observabilité comme couches de modèle.

### 4. Intégration dans le ZIP Kinetic
Montrer comment une idée devient un dossier projet : brief, digital twin, risques, validation.

### 5. Pitch en 45 secondes
Utiliser le paragraphe comme formulation prête à dire à quelqu'un.

### 6. Roadmap
Présenter les prochaines étapes : lexique, formalisme, simulation, critique, présentation.
