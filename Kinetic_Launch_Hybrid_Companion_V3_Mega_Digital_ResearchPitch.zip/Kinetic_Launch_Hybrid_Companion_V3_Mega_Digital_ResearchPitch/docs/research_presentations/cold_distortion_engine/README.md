# Présentation rapide — moteur à distorsion froide

## Statut

Cette présentation est une ébauche de communication de recherche. Elle formalise le moteur à distorsion froide comme **objet numérique spéculatif** : hypothèses, lexique, architecture conceptuelle, scénarios, critères de cohérence et limites de périmètre.

Elle ne constitue pas une validation physique et ne contient pas de paramètres exploitables de propulsion, de propergol, de guidage, d'allumage, de structure ou de lancement.

## Objectif

Ajouter au package Kinetic V3 un support court permettant de présenter le travail de recherche de Nora sur :

- le moteur à distorsion froide ;
- le noyau NOX comme centre conceptuel ;
- la notion de champ froid et de pente locale abstraite ;
- l'intégration dans un digital twin non-physique ;
- la transformation d'une intuition de recherche en dossier traçable.

## Fichiers ajoutés

- `presentations/Moteur_Distortion_Froide_Quick_Pitch.pptx` : présentation PowerPoint 6 slides.
- `docs/research_presentations/cold_distortion_engine/quick_pitch_script.md` : texte oral court et notes par slide.
- `docs/research_presentations/cold_distortion_engine/research_scope_card.json` : fiche structurée du périmètre.
- `examples/research_requests/cold_distortion_engine_pitch_request.json` : exemple de demande intégrable à l'orchestrateur projet.

## Formulation courte

> Je travaille sur un modèle exploratoire appelé moteur à distorsion froide. L'idée n'est pas de prouver aujourd'hui un moteur réel, mais de formaliser une architecture numérique capable de représenter une modification locale de la carte des distances. Le noyau NOX sert de centre conceptuel ; autour, j'ajoute un digital twin, des contraintes, des scénarios et une validation logicielle pour transformer l'intuition en objet de recherche partageable.

## Garde-fous

Accepté : vocabulaire, hypothèses, diagrammes conceptuels, digital twin abstrait, scénarios, risques, matrices V&V.

Rejeté : recette de carburant, dimensionnement moteur, paramètres d'allumage, géométrie de tuyère, charges réelles d'accroche/libération, trajectoire de lancement, procédé de fabrication.
