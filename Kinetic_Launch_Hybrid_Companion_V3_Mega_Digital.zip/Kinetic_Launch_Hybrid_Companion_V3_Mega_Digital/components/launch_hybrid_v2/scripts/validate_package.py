from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def run(cmd):
    p=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True)
    return {"command":" ".join(cmd),"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr}

def main():
    checks=[]
    checks.append(run([sys.executable,"-m","pytest","-q"]))
    with tempfile.TemporaryDirectory() as d:
        checks.append(run([sys.executable,"-m","src.kinetic_launch_hybrid.cli","instantiate","examples/request_super_safe.json",d]))
        out=Path(d)
        required={"project_instance.json","digital_twin_snapshot.json","fault_campaign.json","coverage.json","manifest.sha256.json"}
        artifact_ok=required.issubset({p.name for p in out.iterdir()})
    rejected=run([sys.executable,"-m","src.kinetic_launch_hybrid.cli","validate","examples/request_rejected_sensitive.json"])
    result={"tests_ok":checks[0]["returncode"]==0,"nominal_ok":checks[1]["returncode"]==0 and artifact_ok,"sensitive_request_rejected":rejected["returncode"]==2,"overall":"PASS" if checks[0]["returncode"]==0 and checks[1]["returncode"]==0 and artifact_ok and rejected["returncode"]==2 else "FAIL"}
    print(json.dumps(result,indent=2))
    return 0 if result["overall"]=="PASS" else 1
if __name__=="__main__": raise SystemExit(main())
