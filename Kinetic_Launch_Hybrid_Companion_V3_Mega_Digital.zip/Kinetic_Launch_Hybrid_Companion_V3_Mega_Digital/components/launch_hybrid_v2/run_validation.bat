@echo off
python scripts\validate_package.py
exit /b %errorlevel%
