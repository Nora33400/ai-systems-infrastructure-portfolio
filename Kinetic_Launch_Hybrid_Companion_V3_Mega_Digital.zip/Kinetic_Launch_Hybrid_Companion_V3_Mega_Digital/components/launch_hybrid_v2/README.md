# Kinetic Launch & Hybrid Companion V2 — Super Digital Update

Version **2.0.0** du compagnon numérique Kinetic Launch / Hybrid, conçue pour être ajoutée à un workflow projet concret sans introduire de paramètres de construction ou d'exploitation réels.

## Ce que V2 ajoute
- orchestration multi-sous-systèmes : support/rampe, accroches/libération, hybride principal, hybride auxiliaire, carburants surrogates ;
- Digital Twin Snapshot versionné ;
- simulations nominale, dégradée et campagnes de fautes logiques ;
- matrice d'interfaces et contrats d'intégration ;
- exigences, V&V, risques, couverture et preuves numériques ;
- comparaison multicritère de carburants **surrogates abstraits** ;
- estimation du travail numérique (heures, coût logiciel/documentaire ROM) ;
- intégration AIONE + Kinetic Shroud V3 ;
- CLI de validation, instanciation, simulation et comparaison ;
- manifestes SHA-256 et rapports reproductibles.

## Périmètre
`DIGITAL_CONCEPT_ONLY`. Les valeurs sont normalisées 0..1 ou représentent du travail logiciel/documentaire. Aucune recette de propergol, géométrie moteur, charge réelle de fixation, force de libération, séquence d'allumage réelle, trajectoire, guidage ou paramètre permettant la construction directe n'est produit.

## Démarrage
```bash
python -m src.kinetic_launch_hybrid.cli validate examples/request_super_safe.json
python -m src.kinetic_launch_hybrid.cli instantiate examples/request_super_safe.json outputs/demo_super
python -m src.kinetic_launch_hybrid.cli simulate examples/request_super_degraded.json outputs/demo_degraded
python -m src.kinetic_launch_hybrid.cli compare examples/request_super_safe.json
python -m pytest -q
```

## Sorties principales
`project_instance.json`, `digital_twin_snapshot.json`, `requirements.csv`, `vv_matrix.csv`, `risk_register.csv`, `interface_matrix.csv`, `wbs.csv`, `effort_estimate.csv`, `fuel_surrogates.csv`, `state_trace.json`, `fault_campaign.json`, `coverage.json`, `gaps.md`, `executive_report.md`, `manifest.sha256.json`.
