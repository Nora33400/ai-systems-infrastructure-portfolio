# Validation Report — Kinetic Launch Hybrid Companion V2

## Résultat
**PASS** — validation numérique reproductible.

## Contrôles exécutés
- `pytest`: **15 passed** ;
- compilation Python: PASS ;
- validation package: PASS ;
- scénario nominal: `COMPLETE` ;
- scénario principal dégradé: `COMPLETE`, coordination `GRACEFUL_DEGRADATION` ;
- scénario défaut capteur: terminal sûr, `LaunchSupport=SAFE`, `AttachmentRelease=LOCKED_LOGICAL` ;
- campagne de fautes abstraites: safe-terminal rate `1.0` sur les cas intégrés ;
- requête contenant `chamber_pressure` / `release_force`: **REJECTED**, code de sortie `2` ;
- génération Digital Twin Snapshot + manifestes SHA-256: PASS.

## Couverture automatique
La démo V2 marque **14/15 exigences** comme vérifiées automatiquement (`0.9333`). L'exigence restante est volontairement maintenue comme inspection documentaire plutôt que déclarée automatiquement satisfaite.

## Périmètre
Cette validation couvre uniquement le logiciel, la simulation logique, les contrats d'interface, la traçabilité et les surrogates normalisés. Elle ne qualifie aucun matériel, propergol, moteur, dispositif de fixation/libération ou profil de vol réel.
