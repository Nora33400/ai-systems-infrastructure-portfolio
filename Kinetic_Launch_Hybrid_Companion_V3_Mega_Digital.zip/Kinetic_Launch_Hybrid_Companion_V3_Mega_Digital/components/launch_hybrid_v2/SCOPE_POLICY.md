# Politique de périmètre

Ce package décrit une architecture **numérique abstraite**. Il est destiné à l'ingénierie système, la traçabilité, les interfaces, la simulation logique et la préparation documentaire.

## Autorisé dans le package
- indices normalisés 0..1 ;
- états logiques, interlocks abstraits, santé capteurs virtuelle ;
- comparaison multicritère de candidats anonymisés ;
- risques, exigences, WBS, tests et preuves numériques ;
- estimation d'effort logiciel/documentaire.

## Volontairement absent/bloqué
- composition chimique/recette ou proportions de propergol ;
- géométrie interne moteur, tuyère ou grain ;
- débits, pressions, poussées, impulsions spécifiques ;
- énergie ou dispositif réel d'allumage ;
- dimensions, précharges, charges de rupture ou forces de libération des accroches ;
- guidage, trajectoire, cible, azimut ou profil réel de lancement.

Le moteur `ScopeGuard` rejette les champs correspondants au chargement d'une demande.
