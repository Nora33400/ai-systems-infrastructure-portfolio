$ErrorActionPreference = "Stop"
python .\scripts\validate_package.py
