# Changelog

## 2.0.0 — Super Digital Update
- ajout du modèle Digital Twin Snapshot ;
- orchestration par sous-systèmes et bus d'événements abstrait ;
- scénarios nominal/dégradé/fault injection ;
- modèle principal/auxiliaire commun avec dégradation contrôlée ;
- comparaison carburants surrogates avec sensibilité des pondérations ;
- génération couverture exigences/V&V ;
- matrice ICD numérique ;
- estimation de charge numérique et budget ROM logiciel/documentaire ;
- adaptateurs AIONE + Shroud V3 ;
- ScopeGuard renforcé et audit de périmètre ;
- CLI multi-commandes ;
- tests étendus et validation reproductible.
