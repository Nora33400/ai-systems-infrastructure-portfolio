from __future__ import annotations

LAUNCH_ORDER=["OFF","SAFE","CONFIGURED","SIM_READY","HOLD","ABSTRACT_RELEASE_WINDOW","COMPLETE"]
ATTACHMENT_ORDER=["UNVERIFIED","LOCKED_LOGICAL","VERIFIED","HOLD","RELEASE_ELIGIBLE","RELEASED_LOGICAL"]


def simulate_launch_state(interlocks_ok=True, sensors_ok=True, propulsion_ok=True):
    trace=[{"subsystem":"launch_support","state":"OFF","event":"INIT"}]
    if not interlocks_ok or not sensors_ok or not propulsion_ok:
        trace.append({"subsystem":"launch_support","state":"SAFE","event":"FAULT_TO_SAFE"})
        return trace
    for state,event in [
        ("SAFE","ARM_SIMULATION"),("CONFIGURED","LOAD_ABSTRACT_CONFIG"),
        ("SIM_READY","DIGITAL_CHECK_COMPLETE"),("HOLD","ENTER_LOGICAL_HOLD"),
        ("ABSTRACT_RELEASE_WINDOW","RELEASE_CONSENSUS_AVAILABLE"),("COMPLETE","SIMULATION_COMPLETE")]:
        trace.append({"subsystem":"launch_support","state":state,"event":event})
    return trace


def simulate_attachment_state(sensor_health=1.0, consensus=1.0, inhibit=False):
    t=[{"subsystem":"attachment_release","state":"UNVERIFIED","event":"INIT"}]
    if inhibit or sensor_health<0.5 or consensus<0.5:
        t.append({"subsystem":"attachment_release","state":"LOCKED_LOGICAL","event":"INHIBIT_TO_SAFE"})
        return t
    for state,event in [
        ("LOCKED_LOGICAL","DECLARE_HELD"),("VERIFIED","VIRTUAL_SENSOR_CONSENSUS"),
        ("HOLD","MAINTAIN_LOGICAL_HOLD"),("RELEASE_ELIGIBLE","ABSTRACT_RELEASE_CRITERIA_MET"),
        ("RELEASED_LOGICAL","LOGICAL_RELEASE_RECORDED")]:
        t.append({"subsystem":"attachment_release","state":state,"event":event})
    return t
