from __future__ import annotations
from .state_machine import simulate_launch_state, simulate_attachment_state
from .models import evaluate_propulsion_pair, bounded

FAULTS={"sensor_dropout","interlock_mismatch","primary_degraded","auxiliary_unavailable","release_inhibit"}

def run_scenario(normalized: dict, faults: list[str] | None=None) -> dict:
    faults=set(faults or [])
    unknown=sorted(faults-FAULTS)
    if unknown: raise ValueError("Unknown abstract faults: "+", ".join(unknown))
    n=dict(normalized)
    if "primary_degraded" in faults:
        n["primary_health_index"]=min(n.get("primary_health_index",0.9),0.55)
        n["primary_stability_index"]=min(n.get("primary_stability_index",0.88),0.58)
    if "auxiliary_unavailable" in faults:
        n["auxiliary_health_index"]=0.25
    propulsion=evaluate_propulsion_pair(n)
    sensor_health=bounded(n.get("sensor_health_index",0.92))
    interlock_health=bounded(n.get("interlock_health_index",0.94))
    consensus=bounded(n.get("release_consensus_index",0.9))
    if "sensor_dropout" in faults: sensor_health=0.35
    if "interlock_mismatch" in faults: interlock_health=0.3
    inhibit="release_inhibit" in faults or propulsion["coordination_mode"]=="SAFE_HOLD"
    propulsion_ok=propulsion["coordination_mode"]!="SAFE_HOLD"
    launch=simulate_launch_state(interlock_health>=0.5,sensor_health>=0.5,propulsion_ok)
    attachment=simulate_attachment_state(sensor_health,consensus,inhibit)
    final_safe = launch[-1]["state"] in {"SAFE","COMPLETE"} and attachment[-1]["state"] in {"LOCKED_LOGICAL","RELEASED_LOGICAL"}
    released=attachment[-1]["state"]=="RELEASED_LOGICAL"
    return {
        "faults":sorted(faults),"normalized_inputs":n,"propulsion":propulsion,
        "launch_trace":launch,"attachment_trace":attachment,
        "released_logically":released,"safe_terminal":final_safe,
        "scenario_status":"COMPLETE" if final_safe else "INVALID"
    }
