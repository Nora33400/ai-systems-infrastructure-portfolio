from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable


def bounded(v: float) -> float:
    return max(0.0, min(1.0, float(v)))

@dataclass
class FuelSurrogate:
    id: str
    energy_index: float
    response_index: float
    handling_safety_index: float
    manufacturability_index: float
    storage_stability_index: float
    supply_resilience_index: float = 0.5

    def score(self, weights: dict | None = None) -> float:
        w = weights or {
            "energy_index":0.12,
            "response_index":0.08,
            "handling_safety_index":0.28,
            "manufacturability_index":0.20,
            "storage_stability_index":0.20,
            "supply_resilience_index":0.12,
        }
        total=sum(max(0.0,float(x)) for x in w.values()) or 1.0
        return round(sum(bounded(getattr(self,k))*max(0.0,float(v)) for k,v in w.items())/total,4)

    def to_dict(self, weights=None):
        d=asdict(self); d["concept_score"]=self.score(weights); return d

@dataclass
class PropulsionChain:
    name: str
    health_index: float
    thermal_margin_index: float
    stability_index: float
    sensor_confidence_index: float
    command_authority_index: float
    redundancy_index: float

    def evaluate(self) -> dict:
        vals={k:bounded(v) for k,v in asdict(self).items() if k!="name"}
        readiness=round(
            0.30*vals["health_index"] +
            0.18*vals["thermal_margin_index"] +
            0.18*vals["stability_index"] +
            0.14*vals["sensor_confidence_index"] +
            0.08*vals["command_authority_index"] +
            0.12*vals["redundancy_index"], 4)
        floor=min(vals["health_index"],vals["thermal_margin_index"],vals["stability_index"],vals["sensor_confidence_index"])
        state="NOMINAL" if floor>=0.72 and readiness>=0.76 else ("DEGRADED" if floor>=0.42 else "UNAVAILABLE")
        return {"name":self.name,"readiness_index":readiness,"state":state,"inputs":vals}

def evaluate_propulsion_pair(normalized: dict) -> dict:
    def chain(prefix, defaults):
        return PropulsionChain(
            name=prefix,
            health_index=normalized.get(f"{prefix}_health_index",defaults[0]),
            thermal_margin_index=normalized.get(f"{prefix}_thermal_margin_index",defaults[1]),
            stability_index=normalized.get(f"{prefix}_stability_index",defaults[2]),
            sensor_confidence_index=normalized.get(f"{prefix}_sensor_confidence_index",defaults[3]),
            command_authority_index=normalized.get(f"{prefix}_command_authority_index",defaults[4]),
            redundancy_index=normalized.get(f"{prefix}_redundancy_index",defaults[5]),
        ).evaluate()
    primary=chain("primary",(0.9,0.85,0.88,0.9,0.8,0.75))
    auxiliary=chain("auxiliary",(0.86,0.82,0.84,0.88,0.75,0.85))
    overall=round(0.68*primary["readiness_index"]+0.32*auxiliary["readiness_index"],4)
    mode="DUAL_NOMINAL" if primary["state"]==auxiliary["state"]=="NOMINAL" else (
        "GRACEFUL_DEGRADATION" if "UNAVAILABLE" not in {primary["state"],auxiliary["state"]} else "SAFE_HOLD")
    return {"primary":primary,"auxiliary":auxiliary,"combined_readiness_index":overall,"coordination_mode":mode}
