from __future__ import annotations
from .requirements import REQS

def build_coverage(test_status: dict[str,str] | None=None):
    test_status=test_status or {}
    rows=[]
    for rid,domain,text,method in REQS:
        status=test_status.get(rid,"PLANNED")
        rows.append({"requirement_id":rid,"domain":domain,"method":method,"status":status,"evidence_id":"EV-"+rid})
    verified=sum(1 for r in rows if r["status"]=="VERIFIED")
    return {"rows":rows,"requirements":len(rows),"verified":verified,"coverage_ratio":round(verified/len(rows),4)}
