from __future__ import annotations
from .scenario import run_scenario, FAULTS

def run_fault_campaign(normalized: dict) -> dict:
    cases=[([],"nominal")]+[([f],f) for f in sorted(FAULTS)]+[
        (["sensor_dropout","primary_degraded"],"combined_sensor_primary"),
        (["interlock_mismatch","release_inhibit"],"combined_interlock_inhibit")]
    results=[]
    for faults,label in cases:
        r=run_scenario(normalized,faults)
        results.append({"id":label,"faults":faults,"status":r["scenario_status"],"safe_terminal":r["safe_terminal"],"released_logically":r["released_logically"],"coordination_mode":r["propulsion"]["coordination_mode"]})
    pass_count=sum(1 for x in results if x["safe_terminal"])
    return {"cases":results,"pass_count":pass_count,"case_count":len(results),"safe_terminal_rate":round(pass_count/len(results),4)}
