from __future__ import annotations
from dataclasses import dataclass

BLOCKED_FRAGMENTS = {
    "propellant_recipe", "fuel_formula", "chemical_formula", "oxidizer_name",
    "oxidizer_fuel_ratio", "o_f_ratio", "mix_ratio", "chamber_pressure",
    "mass_flow", "massflow", "nozzle_throat", "nozzle_exit", "expansion_ratio",
    "grain_geometry", "port_diameter", "regression_rate_mm", "ignition_energy",
    "igniter", "thrust_newton", "thrust_n", "specific_impulse", "isp_seconds",
    "hold_down_release_force", "release_force", "bolt_diameter", "bolt_preload",
    "fastener_size", "pyrotechnic", "explosive_bolt", "launch_azimuth",
    "trajectory", "guidance_gain", "target_coordinates", "target_location",
    "burn_time_seconds", "combustion_temperature", "injector_geometry",
    "orifice_diameter", "tank_pressure", "feed_pressure", "oxidizer_flow"
}

@dataclass
class ScopeAudit:
    ok: bool
    hits: list[str]
    status: str = "DIGITAL_CONCEPT_ONLY"

class ScopeViolation(ValueError):
    pass

def _walk(value, path=""):
    if isinstance(value, dict):
        for k, v in value.items():
            p = f"{path}.{k}" if path else str(k)
            yield p, str(k), v
            yield from _walk(v, p)
    elif isinstance(value, list):
        for i, v in enumerate(value):
            yield from _walk(v, f"{path}[{i}]")

def audit_scope(payload: dict) -> ScopeAudit:
    hits=[]
    for path,key,_ in _walk(payload):
        kl=key.lower().replace("-","_").replace(" ","_")
        if any(f in kl for f in BLOCKED_FRAGMENTS):
            hits.append(path)
    return ScopeAudit(ok=not hits, hits=sorted(set(hits)))

def validate_scope(payload: dict) -> None:
    audit=audit_scope(payload)
    if not audit.ok:
        raise ScopeViolation("Champs hors périmètre numérique abstrait: " + ", ".join(audit.hits))
