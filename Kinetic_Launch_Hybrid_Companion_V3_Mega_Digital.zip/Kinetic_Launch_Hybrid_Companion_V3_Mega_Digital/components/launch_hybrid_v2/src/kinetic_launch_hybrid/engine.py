from __future__ import annotations
import csv, json, hashlib
from pathlib import Path
from .scope_guard import validate_scope, audit_scope
from .models import FuelSurrogate
from .scenario import run_scenario
from .fault_injection import run_fault_campaign
from .digital_twin import build_snapshot
from .requirements import REQS, RISKS, WBS, INTERFACES
from .estimation import estimate_effort
from .coverage import build_coverage
from .report import executive_report


def _csv(path, header, rows):
    with open(path,"w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(header); w.writerows(rows)

def _j(path,obj):
    Path(path).write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding="utf-8")

def _fuel_rows(payload):
    weights=payload.get("fuel_weights")
    rows=[]
    for x in payload.get("fuel_surrogates",[]):
        rows.append(FuelSurrogate(**x).to_dict(weights))
    return sorted(rows,key=lambda r:r["concept_score"],reverse=True)

def instantiate(payload: dict, out_dir: str | Path) -> dict:
    validate_scope(payload)
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    normalized=payload.get("normalized_inputs",{})
    scenario=run_scenario(normalized,payload.get("faults",[]))
    fuel_rows=_fuel_rows(payload)
    fault_campaign=run_fault_campaign(normalized)
    test_status={
        "REQ-SYS-001":"VERIFIED","REQ-SYS-002":"VERIFIED","REQ-LS-001":"VERIFIED","REQ-LS-002":"VERIFIED",
        "REQ-AR-001":"VERIFIED","REQ-HP-001":"VERIFIED","REQ-HA-001":"VERIFIED","REQ-CO-001":"VERIFIED",
        "REQ-HF-001":"VERIFIED","REQ-HF-002":"VERIFIED","REQ-FI-001":"VERIFIED","REQ-DT-001":"VERIFIED",
        "REQ-SF-001":"VERIFIED","REQ-INT-001":"VERIFIED"
    }
    coverage=build_coverage(test_status)
    effort=estimate_effort(float(payload.get("digital_rate_eur_per_hour",85.0)))
    interface_dicts=[{"id":a,"source":b,"target":c,"signal":d,"contract":e,"transport":f} for a,b,c,d,e,f in INTERFACES]
    snapshot=build_snapshot(payload["project_id"],payload.get("domains",{}),scenario,fuel_rows,interface_dicts)
    instance={
        "schema":"kinetic.project.instance/2.0","status":"DIGITAL_CONCEPT_ONLY",
        "project_id":payload["project_id"],"objective":payload["objective"],"domains":payload.get("domains",{}),
        "scenario_status":scenario["scenario_status"],"propulsion":scenario["propulsion"],
        "best_fuel_surrogate":fuel_rows[0]["id"] if fuel_rows else None,
        "state_final":{"launch_support":scenario["launch_trace"][-1]["state"],"attachment_release":scenario["attachment_trace"][-1]["state"]},
        "coverage_ratio":coverage["coverage_ratio"],"fault_campaign_safe_terminal_rate":fault_campaign["safe_terminal_rate"],
        "digital_effort":{"hours_base":effort["total_hours_base"],"cost_base_eur":effort["total_cost_base_eur"]},
        "limitations":["no physical sizing","no propellant recipe/chemistry","no real release loads","no ignition design","no guidance/trajectory"]
    }
    _j(out/"project_instance.json",instance)
    _j(out/"digital_twin_snapshot.json",snapshot)
    _j(out/"state_trace.json",{"launch":scenario["launch_trace"],"attachment_release":scenario["attachment_trace"]})
    _j(out/"fault_campaign.json",fault_campaign)
    _j(out/"coverage.json",coverage)
    _j(out/"scope_audit.json",audit_scope(payload).__dict__)
    _csv(out/"requirements.csv",["id","domain","requirement","vv_method"],REQS)
    _csv(out/"vv_matrix.csv",["requirement_id","method","status","evidence_id"],[(r["requirement_id"],r["method"],r["status"],r["evidence_id"]) for r in coverage["rows"]])
    _csv(out/"risk_register.csv",["id","risk","severity","probability","score","mitigation"],[(a,b,c,d,c*d,e) for a,b,c,d,e in RISKS])
    _csv(out/"interface_matrix.csv",["id","source","target","signal","contract","transport"],INTERFACES)
    _csv(out/"wbs.csv",["wbs","work_package","owner_role","hours_base"],WBS)
    _csv(out/"effort_estimate.csv",["wbs","work_package","owner_role","hours_low","hours_base","hours_high","cost_base_eur"],[(r["wbs"],r["work_package"],r["owner_role"],r["hours_low"],r["hours_base"],r["hours_high"],r["cost_base_eur"]) for r in effort["rows"]])
    if fuel_rows:
        _csv(out/"fuel_surrogates.csv",list(fuel_rows[0]),[[r[k] for k in fuel_rows[0]] for r in fuel_rows])
    (out/"gaps.md").write_text("""# Data gaps / excluded physical parameters

This run is complete at the digital-concept layer. Physical dimensions, materials, loads, release forces, propellant chemistry, engine internal geometry, flow/pressure/thrust data, ignition design, launch site, trajectory and guidance remain external and are not generated here.
""",encoding="utf-8")
    (out/"executive_report.md").write_text(executive_report(instance,coverage,fault_campaign,effort),encoding="utf-8")
    hashes={}
    for p in sorted(out.iterdir()):
        if p.is_file() and p.name!="manifest.sha256.json": hashes[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
    _j(out/"manifest.sha256.json",hashes)
    return instance
