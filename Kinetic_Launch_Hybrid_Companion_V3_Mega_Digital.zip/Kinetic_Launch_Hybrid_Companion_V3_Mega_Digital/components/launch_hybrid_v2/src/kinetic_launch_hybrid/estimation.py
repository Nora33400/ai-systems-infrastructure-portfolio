from __future__ import annotations
from .requirements import WBS

def estimate_effort(rate_eur_per_hour: float=85.0, contingency: float=0.20):
    rows=[]
    for wid,name,owner,hours in WBS:
        low=round(hours*0.85,1); base=float(hours); high=round(hours*(1+contingency),1)
        rows.append({"wbs":wid,"work_package":name,"owner_role":owner,"hours_low":low,"hours_base":base,"hours_high":high,"cost_base_eur":round(base*rate_eur_per_hour,2)})
    total_hours=sum(r["hours_base"] for r in rows)
    return {"rows":rows,"rate_eur_per_hour":rate_eur_per_hour,"total_hours_base":total_hours,"total_cost_base_eur":round(total_hours*rate_eur_per_hour,2),"scope":"digital engineering/software/documentation only"}
