from __future__ import annotations
import argparse, json
from pathlib import Path
from .engine import instantiate
from .scope_guard import validate_scope, ScopeViolation, audit_scope
from .scenario import run_scenario
from .models import FuelSurrogate

def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))

def main(argv=None):
    ap=argparse.ArgumentParser(prog="kinetic-launch-hybrid")
    sp=ap.add_subparsers(dest="cmd",required=True)
    v=sp.add_parser("validate"); v.add_argument("request")
    i=sp.add_parser("instantiate"); i.add_argument("request"); i.add_argument("output")
    s=sp.add_parser("simulate"); s.add_argument("request"); s.add_argument("output")
    c=sp.add_parser("compare"); c.add_argument("request")
    a=ap.parse_args(argv)
    payload=load(a.request)
    try: validate_scope(payload)
    except ScopeViolation as e:
        print(json.dumps({"ok":False,"error":str(e)},ensure_ascii=False)); return 2
    if a.cmd=="validate":
        print(json.dumps(audit_scope(payload).__dict__,indent=2,ensure_ascii=False)); return 0
    if a.cmd in {"instantiate","simulate"}:
        r=instantiate(payload,a.output); print(json.dumps(r,indent=2,ensure_ascii=False)); return 0
    if a.cmd=="compare":
        weights=payload.get("fuel_weights")
        rows=sorted([FuelSurrogate(**x).to_dict(weights) for x in payload.get("fuel_surrogates",[])],key=lambda r:r["concept_score"],reverse=True)
        print(json.dumps(rows,indent=2,ensure_ascii=False)); return 0
    return 1

if __name__=="__main__": raise SystemExit(main())
