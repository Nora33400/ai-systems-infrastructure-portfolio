from __future__ import annotations
from datetime import datetime, timezone
import hashlib, json

def build_snapshot(project_id: str, domains: dict, scenario: dict, fuel_ranking: list[dict], interfaces: list[dict]) -> dict:
    base={
        "schema":"kinetic.digital_twin.snapshot/2.0",
        "project_id":project_id,
        "status":"DIGITAL_CONCEPT_ONLY",
        "generated_at":datetime.now(timezone.utc).isoformat(),
        "domains":domains,
        "subsystems":{
            "launch_support":{"state":scenario["launch_trace"][-1]["state"]},
            "attachment_release":{"state":scenario["attachment_trace"][-1]["state"]},
            "primary_hybrid":scenario["propulsion"]["primary"],
            "auxiliary_hybrid":scenario["propulsion"]["auxiliary"],
        },
        "fuel_surrogate_ranking":fuel_ranking,
        "interfaces":interfaces,
        "limitations":["dimensionless concept indices only","no physical sizing","no propellant formulation","no trajectory/guidance"]
    }
    canonical=json.dumps(base,sort_keys=True,ensure_ascii=False).encode()
    base["snapshot_sha256"]=hashlib.sha256(canonical).hexdigest()
    return base
