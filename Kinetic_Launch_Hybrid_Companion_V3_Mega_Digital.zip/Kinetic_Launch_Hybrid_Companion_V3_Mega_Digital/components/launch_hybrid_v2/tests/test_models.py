from src.kinetic_launch_hybrid.models import FuelSurrogate, evaluate_propulsion_pair

def test_fuel_score_bounded():
    f=FuelSurrogate("X",1,1,1,1,1,1); assert f.score()==1.0

def test_propulsion_contract():
    p=evaluate_propulsion_pair({}); assert 0<=p["combined_readiness_index"]<=1; assert p["coordination_mode"] in {"DUAL_NOMINAL","GRACEFUL_DEGRADATION","SAFE_HOLD"}

def test_primary_degraded_mode():
    p=evaluate_propulsion_pair({"primary_health_index":0.5,"primary_stability_index":0.55}); assert p["primary"]["state"]=="DEGRADED"
