from src.kinetic_launch_hybrid.scenario import run_scenario
from src.kinetic_launch_hybrid.fault_injection import run_fault_campaign

def test_nominal_complete():
    r=run_scenario({}); assert r["scenario_status"]=="COMPLETE"; assert r["released_logically"]

def test_sensor_dropout_safe():
    r=run_scenario({},["sensor_dropout"]); assert r["safe_terminal"]; assert not r["released_logically"]

def test_release_inhibit_safe():
    r=run_scenario({},["release_inhibit"]); assert r["safe_terminal"]; assert not r["released_logically"]

def test_fault_campaign():
    c=run_fault_campaign({}); assert c["case_count"]>=7; assert c["safe_terminal_rate"]==1.0
