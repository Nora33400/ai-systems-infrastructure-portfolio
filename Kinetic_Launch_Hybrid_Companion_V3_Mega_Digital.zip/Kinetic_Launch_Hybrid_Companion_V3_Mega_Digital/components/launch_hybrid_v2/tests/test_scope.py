import pytest
from src.kinetic_launch_hybrid.scope_guard import validate_scope, ScopeViolation, audit_scope

def test_scope_allows_normalized():
    p={"normalized_inputs":{"sensor_health_index":0.8}}; validate_scope(p); assert audit_scope(p).ok

def test_scope_blocks_chamber_pressure():
    with pytest.raises(ScopeViolation): validate_scope({"x":{"chamber_pressure":1}})

def test_scope_blocks_release_force():
    with pytest.raises(ScopeViolation): validate_scope({"attachment":{"release_force":1}})

def test_scope_blocks_recipe():
    with pytest.raises(ScopeViolation): validate_scope({"propellant_recipe":"x"})
