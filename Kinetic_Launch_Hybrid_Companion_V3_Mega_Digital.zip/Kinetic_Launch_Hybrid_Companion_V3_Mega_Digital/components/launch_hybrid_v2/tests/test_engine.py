import json, tempfile
from pathlib import Path
from src.kinetic_launch_hybrid.engine import instantiate
ROOT=Path(__file__).resolve().parents[1]

def test_full_instantiation_outputs():
    p=json.loads((ROOT/"examples/request_super_safe.json").read_text())
    with tempfile.TemporaryDirectory() as d:
        r=instantiate(p,d); out=Path(d)
        assert r["status"]=="DIGITAL_CONCEPT_ONLY"
        for name in ["project_instance.json","digital_twin_snapshot.json","requirements.csv","vv_matrix.csv","risk_register.csv","interface_matrix.csv","effort_estimate.csv","fuel_surrogates.csv","fault_campaign.json","executive_report.md","manifest.sha256.json"]: assert (out/name).exists()

def test_degraded_instantiation():
    p=json.loads((ROOT/"examples/request_super_degraded.json").read_text())
    with tempfile.TemporaryDirectory() as d:
        r=instantiate(p,d); assert r["scenario_status"]=="COMPLETE"; assert r["propulsion"]["coordination_mode"] in {"GRACEFUL_DEGRADATION","SAFE_HOLD"}

def test_best_fuel_selected():
    p=json.loads((ROOT/"examples/request_super_safe.json").read_text())
    with tempfile.TemporaryDirectory() as d:
        r=instantiate(p,d); assert r["best_fuel_surrogate"] in {"HF-A","HF-B","HF-C"}
