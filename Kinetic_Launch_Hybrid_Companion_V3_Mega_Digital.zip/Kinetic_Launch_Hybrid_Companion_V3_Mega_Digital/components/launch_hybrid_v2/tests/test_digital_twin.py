from src.kinetic_launch_hybrid.scenario import run_scenario
from src.kinetic_launch_hybrid.digital_twin import build_snapshot

def test_snapshot_hash():
    s=build_snapshot("X",{},run_scenario({}),[],[]); assert len(s["snapshot_sha256"])==64; assert s["status"]=="DIGITAL_CONCEPT_ONLY"
