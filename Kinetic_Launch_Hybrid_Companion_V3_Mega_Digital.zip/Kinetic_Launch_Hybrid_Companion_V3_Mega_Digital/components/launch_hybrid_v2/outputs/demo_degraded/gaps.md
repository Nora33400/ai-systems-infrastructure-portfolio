# Data gaps / excluded physical parameters

This run is complete at the digital-concept layer. Physical dimensions, materials, loads, release forces, propellant chemistry, engine internal geometry, flow/pressure/thrust data, ignition design, launch site, trajectory and guidance remain external and are not generated here.
