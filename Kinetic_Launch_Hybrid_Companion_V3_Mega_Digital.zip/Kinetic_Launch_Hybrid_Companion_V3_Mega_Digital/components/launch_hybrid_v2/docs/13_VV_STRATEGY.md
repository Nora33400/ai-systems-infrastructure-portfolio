# Verification & validation strategy

V2 combines inspection, analysis, simulation, review and automated tests. Evidence IDs follow `EV-REQ-*`. The run emits a coverage ratio and a V&V matrix. Physical qualification remains explicitly outside the package.
