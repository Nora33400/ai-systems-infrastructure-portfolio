# Validation evidence

The distributed package contains pytest output and generated demo runs under `outputs/`. SHA-256 manifests make each generated artifact auditable.
