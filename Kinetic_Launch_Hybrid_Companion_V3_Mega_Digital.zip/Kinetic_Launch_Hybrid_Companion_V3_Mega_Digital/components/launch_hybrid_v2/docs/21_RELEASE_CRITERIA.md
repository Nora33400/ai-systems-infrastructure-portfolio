# Digital release criteria

A V2 instance is release-ready at the digital layer when ScopeGuard passes, scenario status is COMPLETE, all fault-campaign cases are safe-terminal, snapshot hash exists, manifest hash exists and unresolved gaps are acknowledged.
