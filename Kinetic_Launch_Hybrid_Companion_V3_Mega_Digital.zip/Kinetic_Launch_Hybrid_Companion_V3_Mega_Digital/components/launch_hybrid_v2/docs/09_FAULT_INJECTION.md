# Fault injection

Included faults are software-level abstractions: sensor_dropout, interlock_mismatch, primary_degraded, auxiliary_unavailable and release_inhibit. Campaign success means every injected case reaches a declared safe terminal state in the digital model.
