# Roadmap

V2.1: richer telemetry schema and dashboard adapter.
V2.2: stochastic sensitivity analysis over normalized indices.
V2.3: requirements delta engine between project revisions.
V2.4: event replay / event sourcing for full audit history.
V3 candidate: federated digital twin contracts across the broader Kinetic/AIONE ecosystem.
