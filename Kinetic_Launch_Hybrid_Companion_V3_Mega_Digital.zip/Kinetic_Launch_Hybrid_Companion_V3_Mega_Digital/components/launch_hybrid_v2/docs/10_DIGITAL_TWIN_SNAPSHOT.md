# Digital Twin Snapshot

The snapshot serializes project ID, domain enablement, subsystem states, fuel ranking, interfaces, limitations and a content hash. It is a handoff artifact for other AIONE tools or dashboards.
