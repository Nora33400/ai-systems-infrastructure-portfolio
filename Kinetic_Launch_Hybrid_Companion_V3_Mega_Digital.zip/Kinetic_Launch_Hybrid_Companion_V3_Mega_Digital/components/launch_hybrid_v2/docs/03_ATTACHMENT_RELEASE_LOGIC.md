# Attachment / release logical model

The package models attachment as a state contract: UNVERIFIED → LOCKED_LOGICAL → VERIFIED → HOLD → RELEASE_ELIGIBLE → RELEASED_LOGICAL. Eligibility requires virtual sensor health, consensus and absence of inhibit. This is suitable for software integration and test automation only.
