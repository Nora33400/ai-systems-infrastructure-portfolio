# Primary / auxiliary coordination

Three modes are emitted: DUAL_NOMINAL, GRACEFUL_DEGRADATION, SAFE_HOLD. Coordination is intentionally architectural. It supports application logic, dashboards and fault handling while avoiding real propulsion sequencing.
