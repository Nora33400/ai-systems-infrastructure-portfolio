# Hybrid fuel surrogate framework

Fuel candidates are anonymized IDs such as HF-A/HF-B/HF-C. They are compared by normalized indices: energy potential, response, handling safety, manufacturability, storage stability and supply resilience. The ranking is an engineering-decision placeholder, **not a formulation or chemistry recommendation**.
