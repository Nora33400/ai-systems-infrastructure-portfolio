# Super-update improvement matrix

| V1 | V2 improvement | Digital evidence |
|---|---|---|
| Single state trace | Separate launch + attachment machines | state_trace.json |
| One propulsion health | Primary + auxiliary common contract | project_instance.json |
| Basic fuel ranking | 6-factor weighted surrogate model | fuel_surrogates.csv |
| Few failure checks | Campaign of abstract faults | fault_campaign.json |
| No twin snapshot | Versioned, hashed Digital Twin Snapshot | digital_twin_snapshot.json |
| Static matrices | Coverage metric + evidence IDs | coverage.json |
| No project ROM | WBS hours + digital cost ROM | effort_estimate.csv |
| Basic integration | AIONE + Shroud adapters | integration/*.json |
