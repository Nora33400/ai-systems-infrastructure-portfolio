# Migration V1 → V2

V2 reste compatible avec l'idée générale de V1 mais le schéma d'entrée évolue :

- `regression_index` devient `response_index` pour éviter toute interprétation comme paramètre moteur réel ;
- ajout de `supply_resilience_index` pour les surrogates ;
- les entrées propulsion sont séparées `primary_*` et `auxiliary_*` ;
- `state_trace.json` contient maintenant deux machines à états ;
- ajout de `digital_twin_snapshot.json`, `fault_campaign.json`, `coverage.json`, `interface_matrix.csv` et `effort_estimate.csv` ;
- la CLI expose `validate`, `instantiate`, `simulate`, `compare` ;
- ScopeGuard couvre davantage de champs sensibles.

Un projet V1 peut être migré en conservant `project_id`, `objective`, `domains` et les indices normalisés, puis en adaptant les carburants surrogates au nouveau contrat.
