# Data gaps

Physical dimensions, materials, structural loads, release forces, propellant chemistry, internal engine geometry, pressure/flow/thrust, ignition hardware, site data, trajectory and guidance are intentionally absent. A real regulated engineering program would manage those in separate specialist-controlled processes.
