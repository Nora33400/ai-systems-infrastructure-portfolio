# AIONE integration

`integration/aione_adapter.json` declares commands and artifact contracts. Recommended flow: intake JSON → ScopeGuard → instantiate → snapshot → evidence → AIONE registry. AIONE may render dashboards or schedule additional digital tests from these artifacts.
