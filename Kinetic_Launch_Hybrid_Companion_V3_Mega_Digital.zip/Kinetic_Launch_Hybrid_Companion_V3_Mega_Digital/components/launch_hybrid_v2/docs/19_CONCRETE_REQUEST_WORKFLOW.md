# Concrete request workflow

1. Copy `templates/concrete_request_template.json`.
2. Fill objective and enabled domains.
3. Express subsystem condition as normalized 0..1 indices.
4. Add anonymized fuel surrogates if comparison is required.
5. Run `validate`.
6. Run `instantiate`.
7. Review gaps, risk register, V&V and executive report.
8. Connect outputs to AIONE or Shroud V3.
