# System architecture

V2 uses five digital domains: LaunchSupport, AttachmentRelease, PrimaryHybrid, AuxHybrid and FuelSurrogate. A Scenario Engine computes state traces. A Fault Engine verifies safe terminal behavior. A Digital Twin Snapshot freezes state + interfaces + evidence. All cross-domain values are dimensionless or descriptive.
