# Launch-support digital twin

The launch-support representation is a logical supervisory model, not a structural model. It tracks OFF → SAFE → CONFIGURED → SIM_READY → HOLD → ABSTRACT_RELEASE_WINDOW → COMPLETE. Faults return the model to SAFE. No geometry, loads or timing values for physical launch operations are included.
