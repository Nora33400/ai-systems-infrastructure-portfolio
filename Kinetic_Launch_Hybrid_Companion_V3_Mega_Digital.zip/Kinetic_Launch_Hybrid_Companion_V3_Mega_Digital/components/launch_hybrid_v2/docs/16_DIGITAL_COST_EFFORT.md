# Digital cost & effort

V2 estimates the effort to implement the **software/documentation/simulation package**, not to manufacture a launch system. The default rate is configurable. WBS hours produce low/base/high effort and a base EUR ROM useful for project intake.
