# Operator cookbook

Validate an intake before any run. Instantiate nominal first. Then run degraded/fault examples and compare the state traces. Use `compare` to inspect fuel surrogate ranking. Treat `gaps.md` as an explicit boundary checklist for anything the digital package does not claim to solve.
