# Auxiliary hybrid surrogate

The auxiliary chain uses exactly the same abstract contract as the primary. This enables common validation, replacement of a chain in simulation, and coordinated graceful degradation without embedding hardware construction data.
