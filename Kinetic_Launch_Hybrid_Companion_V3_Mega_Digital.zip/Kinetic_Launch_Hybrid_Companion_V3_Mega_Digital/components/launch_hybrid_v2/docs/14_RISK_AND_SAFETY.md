# Risk and safety

The main digital risks are interpretation drift, unsafe logical transition, traceability loss, out-of-scope data ingress, surrogate over-interpretation and interface version mismatch. Controls include ScopeGuard, fail-safe states, hashes, explicit classification and versioned contracts.
