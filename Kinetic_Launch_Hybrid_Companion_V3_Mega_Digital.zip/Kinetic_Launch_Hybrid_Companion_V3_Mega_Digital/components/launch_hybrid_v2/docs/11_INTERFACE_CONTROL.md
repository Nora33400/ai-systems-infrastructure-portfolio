# Interface control

Interfaces are declared in `interface_matrix.csv` and use versioned JSON contracts. Shared signals are normalized readiness, logical eligibility and evidence references. No physical wiring, actuator, fastener or fluid interface dimensions are defined.
