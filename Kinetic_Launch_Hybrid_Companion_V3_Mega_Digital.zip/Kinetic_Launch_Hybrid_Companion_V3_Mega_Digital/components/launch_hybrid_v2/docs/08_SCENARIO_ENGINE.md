# Scenario engine

A scenario accepts normalized inputs plus abstract faults. It returns launch and attachment traces, propulsion pair health and safe-terminal status. Scenarios are deterministic for reproducible validation.
