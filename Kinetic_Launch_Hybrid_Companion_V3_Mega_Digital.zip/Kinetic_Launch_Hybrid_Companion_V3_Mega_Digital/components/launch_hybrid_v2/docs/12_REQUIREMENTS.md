# Requirements

Requirements are generated from a controlled catalog. IDs are stable across runs. New concrete projects should extend requirements by adding project-specific **digital behavior**, data ownership, UI, telemetry schema or test evidence rather than physical manufacturing parameters.
