# Primary hybrid surrogate

The primary chain exposes normalized health, thermal margin, stability, sensor confidence, command authority and redundancy. V2 adds an explicit readiness index and NOMINAL / DEGRADED / UNAVAILABLE state. These values do not map to real engine pressure, flow, thrust or geometry.
