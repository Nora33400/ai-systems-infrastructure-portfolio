# Glossary

**Surrogate**: abstract candidate represented by normalized scores.
**Digital Twin Snapshot**: immutable serialized digital state.
**Safe terminal**: digital state declared non-progressing under the modeled logic.
**Logical release**: software state transition; not a physical release instruction.
**ROM**: rough-order-of-magnitude estimate.
