# Stratégie V&V

La vérification suit quatre méthodes : **analyse, inspection, démonstration, test**.

Principes :
- aucune exigence critique sans méthode de vérification ;
- les essais commencent à basse énergie ;
- l'environnement représentatif augmente graduellement ;
- tout résultat « meilleur que prévu » doit être reproductible ;
- les tests n'essaient pas de prouver une théorie : ils cherchent aussi à la falsifier.

Référence de structure : logique ECSS de vérification et d'essais au sol.
