# Stratégie V&V — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **preuve, sûreté, maturité, modes de défaillance et facteurs humains**.

## Structure détectée
- Niveau 1: **Stratégie V&V**

## Énoncés de baseline extraits
- aucune exigence critique sans méthode de vérification ;
- les essais commencent à basse énergie ;
- l'environnement représentatif augmente graduellement ;
- tout résultat « meilleur que prévu » doit être reproductible ;
- les tests n'essaient pas de prouver une théorie : ils cherchent aussi à la falsifier.

## Axes à documenter
- danger
- mode de défaillance
- détection
- mitigation
- critère d'acceptation
- maturité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
