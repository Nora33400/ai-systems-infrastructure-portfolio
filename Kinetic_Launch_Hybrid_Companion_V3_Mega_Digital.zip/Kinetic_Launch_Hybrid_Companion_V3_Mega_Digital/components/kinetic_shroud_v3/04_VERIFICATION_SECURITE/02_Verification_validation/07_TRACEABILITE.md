# Stratégie V&V — traçabilité

## Origine
- Ancien chemin V1 : `04_VERIFICATION_SECURITE/02_Verification_validation.md`
- SHA-256 V1 : `6499e49f33a6b7a543eb0f566199a73e76800b83896d6e06ce63c8416f17c926`
- Catégorie : `04_VERIFICATION_SECURITE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
