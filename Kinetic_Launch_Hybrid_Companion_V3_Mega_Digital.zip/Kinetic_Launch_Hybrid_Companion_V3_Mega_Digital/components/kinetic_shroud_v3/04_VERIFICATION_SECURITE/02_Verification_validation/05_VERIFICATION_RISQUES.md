# Stratégie V&V — vérification, risques et critères

## Méthodes
- analyse
- inspection
- démonstration
- test progressif
- revue indépendante

## Points issus de la source
- Vérifier : aucune exigence critique sans méthode de vérification ;
- Vérifier : les essais commencent à basse énergie ;
- Vérifier : l'environnement représentatif augmente graduellement ;
- Vérifier : tout résultat « meilleur que prévu » doit être reproductible ;
- Vérifier : les tests n'essaient pas de prouver une théorie : ils cherchent aussi à la falsifier.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
