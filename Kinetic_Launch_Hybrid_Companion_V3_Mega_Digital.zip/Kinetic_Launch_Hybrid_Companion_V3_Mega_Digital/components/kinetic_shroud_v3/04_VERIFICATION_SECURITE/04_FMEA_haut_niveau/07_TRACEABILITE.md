# FMEA haut niveau — traçabilité

## Origine
- Ancien chemin V1 : `04_VERIFICATION_SECURITE/04_FMEA_haut_niveau.md`
- SHA-256 V1 : `0ae8cf04ba519e6071a71ada0f1d3a3f0f9d5597adee1c3a75f0c2cd9e71d83e`
- Catégorie : `04_VERIFICATION_SECURITE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
