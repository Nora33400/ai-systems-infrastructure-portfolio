# FMEA haut niveau — dossier développé

**Ancien document :** `04_VERIFICATION_SECURITE/04_FMEA_haut_niveau.md`  
**Catégorie :** `04_VERIFICATION_SECURITE`  
**Version :** V2 Expanded  
**Hash source :** `0ae8cf04ba519e6071a71ada0f1d3a3f0f9d5597adee1c3a75f0c2cd9e71d83e`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
