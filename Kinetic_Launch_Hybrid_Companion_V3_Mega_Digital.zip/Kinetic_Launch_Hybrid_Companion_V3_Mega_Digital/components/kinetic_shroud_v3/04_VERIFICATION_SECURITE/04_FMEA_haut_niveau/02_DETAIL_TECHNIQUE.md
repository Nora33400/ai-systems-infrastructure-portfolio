# FMEA haut niveau — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **preuve, sûreté, maturité, modes de défaillance et facteurs humains**.

## Structure détectée
- Niveau 1: **FMEA haut niveau**

## Énoncés de baseline extraits
- | Élément | Mode de défaillance | Effet | Détection | Disposition V1 |
|---|---|---|---|---|
| Segment | ne libère pas | asymétrie/interférence | position + charge | stop expérimental |
| Segment | libération prématurée | perte intégrité | état verrou + redondance | empêcher énergie |
| Réservoir mobile | bloque | collision / transfert incomplet | position | maquette inerte d'abord |
| Interface | jeu excessif | vibration | métrologie | rework |
| Capteur | valeur fausse | mauvaise décision | plausibilité / redondance | état sûr |
| Logiciel | état incohérent | séquence erronée | watchdog / journal | inhibit |
| Humain | tâche impossible sous charge | erreur / blessure | analyse HF | supprimer tâche dynamique |

## Axes à documenter
- danger
- mode de défaillance
- détection
- mitigation
- critère d'acceptation
- maturité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
