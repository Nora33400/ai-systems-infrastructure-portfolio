# FMEA haut niveau

| Élément | Mode de défaillance | Effet | Détection | Disposition V1 |
|---|---|---|---|---|
| Segment | ne libère pas | asymétrie/interférence | position + charge | stop expérimental |
| Segment | libération prématurée | perte intégrité | état verrou + redondance | empêcher énergie |
| Réservoir mobile | bloque | collision / transfert incomplet | position | maquette inerte d'abord |
| Interface | jeu excessif | vibration | métrologie | rework |
| Capteur | valeur fausse | mauvaise décision | plausibilité / redondance | état sûr |
| Logiciel | état incohérent | séquence erronée | watchdog / journal | inhibit |
| Humain | tâche impossible sous charge | erreur / blessure | analyse HF | supprimer tâche dynamique |
