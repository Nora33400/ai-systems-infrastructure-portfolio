# Audit des affirmations de la source

| Affirmation source | Statut V1 | Motif |
|---|---|---|
| « zéro énergie » | corrigée | transfert d'énergie ≠ énergie gratuite |
| « 100 % du carburant » | rejetée | pertes, ullage, résidus, transferts et marges existent |
| « masse/taille pas grave » | rejetée | masse et charges restent fondamentales |
| « trajectoire parfaitement conservée » | rejetée | système réel a perturbations, jeux et incertitudes |
| « dizaines de millions économisés » | non démontrée | pas de modèle coût sourcé |
| « rampe = idéal » | non démontrée | bénéfice dépend charges, site, énergie, aérodynamique, coût |
| « humain remplace l'automatisation » | limité | facteurs humains et sûreté peuvent rendre l'inverse préférable |
