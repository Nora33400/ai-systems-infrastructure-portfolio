# Audit des affirmations de la source — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **preuve, sûreté, maturité, modes de défaillance et facteurs humains**.

## Structure détectée
- Niveau 1: **Audit des affirmations de la source**

## Énoncés de baseline extraits
- | Affirmation source | Statut V1 | Motif |
|---|---|---|
| « zéro énergie » | corrigée | transfert d'énergie ≠ énergie gratuite |
| « 100 % du carburant » | rejetée | pertes, ullage, résidus, transferts et marges existent |
| « masse/taille pas grave » | rejetée | masse et charges restent fondamentales |
| « trajectoire parfaitement conservée » | rejetée | système réel a perturbations, jeux et incertitudes |
| « dizaines de millions économisés » | non démontrée | pas de modèle coût sourcé |
| « rampe = idéal » | non démontrée | bénéfice dépend charges, site, énergie, aérodynamique, coût |
| « humain remplace l'automatisation » | limité | facteurs humains et sûreté peuvent rendre l'inverse préférable |

## Axes à documenter
- danger
- mode de défaillance
- détection
- mitigation
- critère d'acceptation
- maturité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
