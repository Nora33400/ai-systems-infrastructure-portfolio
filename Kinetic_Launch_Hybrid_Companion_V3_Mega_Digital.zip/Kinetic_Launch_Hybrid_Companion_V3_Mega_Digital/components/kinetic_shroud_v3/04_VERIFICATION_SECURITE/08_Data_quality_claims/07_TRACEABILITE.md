# Audit des affirmations de la source — traçabilité

## Origine
- Ancien chemin V1 : `04_VERIFICATION_SECURITE/08_Data_quality_claims.md`
- SHA-256 V1 : `1daafdbb6a53874f74c9607986fab0094b98f63e9d05d5bff3a43cb4d89c7ab3`
- Catégorie : `04_VERIFICATION_SECURITE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
