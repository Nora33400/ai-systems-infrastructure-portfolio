# Évaluation TRL préliminaire — vérification, risques et critères

## Méthodes
- analyse
- inspection
- démonstration
- test progressif
- revue indépendante

## Points issus de la source
- Vérifier : **Noyau Home pressurisé** : TRL 2 — Concept formulé; architecture spécifique non démontrée
- Vérifier : **Coque externe 4 étages segmentés** : TRL 2 — Concept formulé; charges/interfaces non validées
- Vérifier : **Séparation latérale multi-segments** : TRL 2 — Principe conceptuel; preuve mécanique représentative à faire
- Vérifier : **Réservoirs périphériques mobiles** : TRL 1-2 — Idée; faisabilité cryogénique et structurelle non démontrée
- Vérifier : **Mécanismes passifs de transfert** : TRL 2 — Principe mécanique connu, intégration spécifique non démontrée
- Vérifier : **Rampe assistée** : TRL 1-2 — Concept système; exigences de performance absentes
- Vérifier : **Facteurs humains en noyau X niveaux** : TRL 1-2 — Concept; contraintes physiologiques non fermées
- Vérifier : **Modèle coût/WBS/V&V** : TRL 3 — Méthode documentée et calculable; données industrielles à enrichir

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
