# Évaluation TRL préliminaire — traçabilité

## Origine
- Ancien chemin V1 : `04_VERIFICATION_SECURITE/05_TRL.md`
- SHA-256 V1 : `c35a9105026db788595d45b04d8bb2087c7c022eecc03811f7115f858b8880a4`
- Catégorie : `04_VERIFICATION_SECURITE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
