# Évaluation TRL préliminaire

- **Noyau Home pressurisé** : TRL 2 — Concept formulé; architecture spécifique non démontrée
- **Coque externe 4 étages segmentés** : TRL 2 — Concept formulé; charges/interfaces non validées
- **Séparation latérale multi-segments** : TRL 2 — Principe conceptuel; preuve mécanique représentative à faire
- **Réservoirs périphériques mobiles** : TRL 1-2 — Idée; faisabilité cryogénique et structurelle non démontrée
- **Mécanismes passifs de transfert** : TRL 2 — Principe mécanique connu, intégration spécifique non démontrée
- **Rampe assistée** : TRL 1-2 — Concept système; exigences de performance absentes
- **Facteurs humains en noyau X niveaux** : TRL 1-2 — Concept; contraintes physiologiques non fermées
- **Modèle coût/WBS/V&V** : TRL 3 — Méthode documentée et calculable; données industrielles à enrichir
