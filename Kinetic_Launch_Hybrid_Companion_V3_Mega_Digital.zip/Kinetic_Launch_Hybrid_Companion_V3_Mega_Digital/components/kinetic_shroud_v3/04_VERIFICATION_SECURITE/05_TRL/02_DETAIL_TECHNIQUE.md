# Évaluation TRL préliminaire — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **preuve, sûreté, maturité, modes de défaillance et facteurs humains**.

## Structure détectée
- Niveau 1: **Évaluation TRL préliminaire**

## Énoncés de baseline extraits
- **Noyau Home pressurisé** : TRL 2 — Concept formulé; architecture spécifique non démontrée
- **Coque externe 4 étages segmentés** : TRL 2 — Concept formulé; charges/interfaces non validées
- **Séparation latérale multi-segments** : TRL 2 — Principe conceptuel; preuve mécanique représentative à faire
- **Réservoirs périphériques mobiles** : TRL 1-2 — Idée; faisabilité cryogénique et structurelle non démontrée
- **Mécanismes passifs de transfert** : TRL 2 — Principe mécanique connu, intégration spécifique non démontrée
- **Rampe assistée** : TRL 1-2 — Concept système; exigences de performance absentes
- **Facteurs humains en noyau X niveaux** : TRL 1-2 — Concept; contraintes physiologiques non fermées
- **Modèle coût/WBS/V&V** : TRL 3 — Méthode documentée et calculable; données industrielles à enrichir

## Axes à documenter
- danger
- mode de défaillance
- détection
- mitigation
- critère d'acceptation
- maturité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
