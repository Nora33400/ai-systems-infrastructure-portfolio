# Facteurs humains — vérification, risques et critères

## Méthodes
- analyse
- inspection
- démonstration
- test progressif
- revue indépendante

## Points issus de la source
- Vérifier : aucune connexion manuelle de fluide dangereux en phase dynamique ;
- Vérifier : aucun déplacement nécessaire à la survie de mission pendant séparation ;
- Vérifier : instrumentation lisible en mode dégradé ;
- Vérifier : tâches critiques automatisées ou inhibées jusqu'à phase sûre ;
- Vérifier : entraînement et procédures séparés du mécanisme structurel.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
