# Facteurs humains — traçabilité

## Origine
- Ancien chemin V1 : `04_VERIFICATION_SECURITE/06_Human_factors.md`
- SHA-256 V1 : `105cbbd1f626ad34e9af64cc91892b29a9fd783ebe746218442041fd9f4703d6`
- Catégorie : `04_VERIFICATION_SECURITE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
