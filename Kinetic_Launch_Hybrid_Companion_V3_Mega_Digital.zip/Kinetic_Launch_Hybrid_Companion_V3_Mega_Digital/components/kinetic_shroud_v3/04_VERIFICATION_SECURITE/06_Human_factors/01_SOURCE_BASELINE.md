# Facteurs humains

La mobilité d'un technicien sous charge ne doit pas servir de mécanisme de réduction de coût avant validation physiologique et opérationnelle.

V1 :
- aucune connexion manuelle de fluide dangereux en phase dynamique ;
- aucun déplacement nécessaire à la survie de mission pendant séparation ;
- instrumentation lisible en mode dégradé ;
- tâches critiques automatisées ou inhibées jusqu'à phase sûre ;
- entraînement et procédures séparés du mécanisme structurel.
