# Registre des risques — vérification, risques et critères

## Méthodes
- analyse
- inspection
- démonstration
- test progressif
- revue indépendante

## Points issus de la source
- Vérifier : **R-001 Séparation latérale asymétrique** — gravité Très élevée, probabilité Élevée, niveau Critique. Mitigation: Maquette mécanique + instrumentation; indépendance des verrous; détection défaut
- Vérifier : **R-002 Masse structurelle de l'exo-coque** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: Boucle masse/charge; comparaison à architectures de référence
- Vérifier : **R-003 Réservoirs périphériques et interfaces mobiles** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: Limiter mobilité; découpler stockage et séparation; essais pressurisés dédiés
- Vérifier : **R-004 Hypothèse de mécanismes 'passifs' sans pertes** — gravité Élevée, probabilité Moyenne, niveau Élevé. Mitigation: Bilan énergétique et frottement; capteurs de validation
- Vérifier : **R-005 Charges sur équipage/technicien en mouvement** — gravité Très élevée, probabilité Moyenne, niveau Critique. Mitigation: Baseline automatisée; humain hors boucle pendant phases dynamiques
- Vérifier : **R-006 Rampe de lancement: infrastructure et charges** — gravité Très élevée, probabilité Élevée, niveau Critique. Mitigation: Étude indépendante; pas de crédit performance avant validation
- Vérifier : **R-007 Complexité d'interfaces 4 étages × N segments** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: ICD stricts; modularité; limiter variantes
- Vérifier : **R-008 Budget programme sous-estimé** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: JCL/Monte-Carlo; réserve; gates
- Vérifier : **R-009 Normes/licences** — gravité Élevée, probabilité Moyenne, niveau Élevé. Mitigation: Matrice ECSS/FAA + autorité nationale selon site
- Vérifier : **R-010 Dérive de périmètre** — gravité Moyenne, probabilité Élevée, niveau Élevé. Mitigation: Configuration management; baseline versionnée

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
