# Registre des risques

- **R-001 Séparation latérale asymétrique** — gravité Très élevée, probabilité Élevée, niveau Critique. Mitigation: Maquette mécanique + instrumentation; indépendance des verrous; détection défaut
- **R-002 Masse structurelle de l'exo-coque** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: Boucle masse/charge; comparaison à architectures de référence
- **R-003 Réservoirs périphériques et interfaces mobiles** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: Limiter mobilité; découpler stockage et séparation; essais pressurisés dédiés
- **R-004 Hypothèse de mécanismes 'passifs' sans pertes** — gravité Élevée, probabilité Moyenne, niveau Élevé. Mitigation: Bilan énergétique et frottement; capteurs de validation
- **R-005 Charges sur équipage/technicien en mouvement** — gravité Très élevée, probabilité Moyenne, niveau Critique. Mitigation: Baseline automatisée; humain hors boucle pendant phases dynamiques
- **R-006 Rampe de lancement: infrastructure et charges** — gravité Très élevée, probabilité Élevée, niveau Critique. Mitigation: Étude indépendante; pas de crédit performance avant validation
- **R-007 Complexité d'interfaces 4 étages × N segments** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: ICD stricts; modularité; limiter variantes
- **R-008 Budget programme sous-estimé** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: JCL/Monte-Carlo; réserve; gates
- **R-009 Normes/licences** — gravité Élevée, probabilité Moyenne, niveau Élevé. Mitigation: Matrice ECSS/FAA + autorité nationale selon site
- **R-010 Dérive de périmètre** — gravité Moyenne, probabilité Élevée, niveau Élevé. Mitigation: Configuration management; baseline versionnée
