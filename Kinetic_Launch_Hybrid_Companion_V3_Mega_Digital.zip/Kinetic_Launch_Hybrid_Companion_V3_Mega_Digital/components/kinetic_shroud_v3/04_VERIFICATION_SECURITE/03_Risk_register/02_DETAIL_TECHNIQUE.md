# Registre des risques — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **preuve, sûreté, maturité, modes de défaillance et facteurs humains**.

## Structure détectée
- Niveau 1: **Registre des risques**

## Énoncés de baseline extraits
- **R-001 Séparation latérale asymétrique** — gravité Très élevée, probabilité Élevée, niveau Critique. Mitigation: Maquette mécanique + instrumentation; indépendance des verrous; détection défaut
- **R-002 Masse structurelle de l'exo-coque** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: Boucle masse/charge; comparaison à architectures de référence
- **R-003 Réservoirs périphériques et interfaces mobiles** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: Limiter mobilité; découpler stockage et séparation; essais pressurisés dédiés
- **R-004 Hypothèse de mécanismes 'passifs' sans pertes** — gravité Élevée, probabilité Moyenne, niveau Élevé. Mitigation: Bilan énergétique et frottement; capteurs de validation
- **R-005 Charges sur équipage/technicien en mouvement** — gravité Très élevée, probabilité Moyenne, niveau Critique. Mitigation: Baseline automatisée; humain hors boucle pendant phases dynamiques
- **R-006 Rampe de lancement: infrastructure et charges** — gravité Très élevée, probabilité Élevée, niveau Critique. Mitigation: Étude indépendante; pas de crédit performance avant validation
- **R-007 Complexité d'interfaces 4 étages × N segments** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: ICD stricts; modularité; limiter variantes
- **R-008 Budget programme sous-estimé** — gravité Élevée, probabilité Élevée, niveau Critique. Mitigation: JCL/Monte-Carlo; réserve; gates
- **R-009 Normes/licences** — gravité Élevée, probabilité Moyenne, niveau Élevé. Mitigation: Matrice ECSS/FAA + autorité nationale selon site
- **R-010 Dérive de périmètre** — gravité Moyenne, probabilité Élevée, niveau Élevé. Mitigation: Configuration management; baseline versionnée

## Axes à documenter
- danger
- mode de défaillance
- détection
- mitigation
- critère d'acceptation
- maturité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
