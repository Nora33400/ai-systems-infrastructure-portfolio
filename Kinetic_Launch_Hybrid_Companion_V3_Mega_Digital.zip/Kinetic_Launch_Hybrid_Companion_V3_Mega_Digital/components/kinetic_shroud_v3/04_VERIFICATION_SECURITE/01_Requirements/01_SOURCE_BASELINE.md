# Exigences système V1

- **REQ-SYS-001** [Must] Le système doit conserver un noyau interne continu pendant les transitions de coque. — domaine: Architecture, origine: Source
- **REQ-SYS-002** [Must] La coque externe doit être décomposable en quatre étages fonctionnels indépendants. — domaine: Architecture, origine: Source
- **REQ-SYS-003** [Should] Chaque étage externe doit pouvoir supporter une segmentation latérale configurable. — domaine: Architecture, origine: Source
- **REQ-SYS-004** [Must] Toute fonction qualifiée de passive doit posséder un bilan énergie/force explicite. — domaine: Physique, origine: Derived
- **REQ-SYS-005** [Must] Une séparation ne doit pas dépendre d'un unique événement non surveillé. — domaine: Sûreté, origine: Derived
- **REQ-SYS-006** [Must] Les réservoirs pressurisés/cryogéniques doivent être traités comme sous-systèmes critiques dédiés. — domaine: Sûreté, origine: Derived
- **REQ-SYS-007** [Must] La conception habitée doit interdire les raccordements manuels de fluides dangereux sous charge dynamique. — domaine: Facteurs humains, origine: Derived
- **REQ-SYS-008** [Must] Les coûts doivent être liés à une WBS, une hypothèse, une date et un niveau de maturité. — domaine: Programme, origine: Derived
- **REQ-SYS-009** [Must] Les tests doivent être traçables à une exigence et à un critère de réussite. — domaine: V&V, origine: Derived
- **REQ-SYS-010** [Should] Les fonctions de rampe doivent rester séparées du véhicule dans les analyses de coût et de sûreté. — domaine: Infrastructure, origine: Derived
- **REQ-SYS-011** [Must] Les paramètres de vol non définis ne doivent pas être remplacés par des valeurs inventées. — domaine: Modélisation, origine: Derived
- **REQ-SYS-012** [Must] Les estimations doivent fournir une plage d'incertitude et pas seulement un point unique. — domaine: Coût, origine: Derived
