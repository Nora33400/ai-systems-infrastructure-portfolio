# Exigences système V1 — données et calculs

## Valeurs numériques détectées
- `001`
- `002`
- `003`
- `004`
- `005`
- `006`
- `007`
- `008`
- `009`
- `010`
- `011`
- `012`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Discipline de calcul
Pour chaque grandeur : symbole, unité SI, valeur, source, date, incertitude et statut.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
