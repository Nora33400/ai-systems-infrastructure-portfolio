# Exigences système V1 — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **preuve, sûreté, maturité, modes de défaillance et facteurs humains**.

## Structure détectée
- Niveau 1: **Exigences système V1**

## Énoncés de baseline extraits
- **REQ-SYS-001** [Must] Le système doit conserver un noyau interne continu pendant les transitions de coque. — domaine: Architecture, origine: Source
- **REQ-SYS-002** [Must] La coque externe doit être décomposable en quatre étages fonctionnels indépendants. — domaine: Architecture, origine: Source
- **REQ-SYS-003** [Should] Chaque étage externe doit pouvoir supporter une segmentation latérale configurable. — domaine: Architecture, origine: Source
- **REQ-SYS-004** [Must] Toute fonction qualifiée de passive doit posséder un bilan énergie/force explicite. — domaine: Physique, origine: Derived
- **REQ-SYS-005** [Must] Une séparation ne doit pas dépendre d'un unique événement non surveillé. — domaine: Sûreté, origine: Derived
- **REQ-SYS-006** [Must] Les réservoirs pressurisés/cryogéniques doivent être traités comme sous-systèmes critiques dédiés. — domaine: Sûreté, origine: Derived
- **REQ-SYS-007** [Must] La conception habitée doit interdire les raccordements manuels de fluides dangereux sous charge dynamique. — domaine: Facteurs humains, origine: Derived
- **REQ-SYS-008** [Must] Les coûts doivent être liés à une WBS, une hypothèse, une date et un niveau de maturité. — domaine: Programme, origine: Derived
- **REQ-SYS-009** [Must] Les tests doivent être traçables à une exigence et à un critère de réussite. — domaine: V&V, origine: Derived
- **REQ-SYS-010** [Should] Les fonctions de rampe doivent rester séparées du véhicule dans les analyses de coût et de sûreté. — domaine: Infrastructure, origine: Derived
- **REQ-SYS-011** [Must] Les paramètres de vol non définis ne doivent pas être remplacés par des valeurs inventées. — domaine: Modélisation, origine: Derived
- **REQ-SYS-012** [Must] Les estimations doivent fournir une plage d'incertitude et pas seulement un point unique. — domaine: Coût, origine: Derived

## Axes à documenter
- danger
- mode de défaillance
- détection
- mitigation
- critère d'acceptation
- maturité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
