# Exigences système V1 — traçabilité

## Origine
- Ancien chemin V1 : `04_VERIFICATION_SECURITE/01_Requirements.md`
- SHA-256 V1 : `d811d4b170ccc4748dfd67942eb01bf157ecf00f187157f1a0bf3d3628d0d26f`
- Catégorie : `04_VERIFICATION_SECURITE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
