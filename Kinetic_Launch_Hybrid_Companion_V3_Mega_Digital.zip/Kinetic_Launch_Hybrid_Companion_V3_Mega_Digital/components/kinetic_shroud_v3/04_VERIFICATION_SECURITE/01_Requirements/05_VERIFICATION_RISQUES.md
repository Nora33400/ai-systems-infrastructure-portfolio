# Exigences système V1 — vérification, risques et critères

## Méthodes
- analyse
- inspection
- démonstration
- test progressif
- revue indépendante

## Points issus de la source
- Vérifier : **REQ-SYS-001** [Must] Le système doit conserver un noyau interne continu pendant les transitions de coque. — domaine: Architecture, origine: Source
- Vérifier : **REQ-SYS-002** [Must] La coque externe doit être décomposable en quatre étages fonctionnels indépendants. — domaine: Architecture, origine: Source
- Vérifier : **REQ-SYS-003** [Should] Chaque étage externe doit pouvoir supporter une segmentation latérale configurable. — domaine: Architecture, origine: Source
- Vérifier : **REQ-SYS-004** [Must] Toute fonction qualifiée de passive doit posséder un bilan énergie/force explicite. — domaine: Physique, origine: Derived
- Vérifier : **REQ-SYS-005** [Must] Une séparation ne doit pas dépendre d'un unique événement non surveillé. — domaine: Sûreté, origine: Derived
- Vérifier : **REQ-SYS-006** [Must] Les réservoirs pressurisés/cryogéniques doivent être traités comme sous-systèmes critiques dédiés. — domaine: Sûreté, origine: Derived
- Vérifier : **REQ-SYS-007** [Must] La conception habitée doit interdire les raccordements manuels de fluides dangereux sous charge dynamique. — domaine: Facteurs humains, origine: Derived
- Vérifier : **REQ-SYS-008** [Must] Les coûts doivent être liés à une WBS, une hypothèse, une date et un niveau de maturité. — domaine: Programme, origine: Derived
- Vérifier : **REQ-SYS-009** [Must] Les tests doivent être traçables à une exigence et à un critère de réussite. — domaine: V&V, origine: Derived
- Vérifier : **REQ-SYS-010** [Should] Les fonctions de rampe doivent rester séparées du véhicule dans les analyses de coût et de sûreté. — domaine: Infrastructure, origine: Derived

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
