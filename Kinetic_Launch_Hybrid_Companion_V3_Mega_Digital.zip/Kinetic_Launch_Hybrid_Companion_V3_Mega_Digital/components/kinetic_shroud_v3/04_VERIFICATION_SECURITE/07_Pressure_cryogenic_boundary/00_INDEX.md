# Frontière systèmes pressurisés / cryogéniques — dossier développé

**Ancien document :** `04_VERIFICATION_SECURITE/07_Pressure_cryogenic_boundary.md`  
**Catégorie :** `04_VERIFICATION_SECURITE`  
**Version :** V2 Expanded  
**Hash source :** `57bfa8a51ea0bdc6064cdcf295e156a17ab780aa604b67330bd56776f6b71a06`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
