# Frontière systèmes pressurisés / cryogéniques — traçabilité

## Origine
- Ancien chemin V1 : `04_VERIFICATION_SECURITE/07_Pressure_cryogenic_boundary.md`
- SHA-256 V1 : `57bfa8a51ea0bdc6064cdcf295e156a17ab780aa604b67330bd56776f6b71a06`
- Catégorie : `04_VERIFICATION_SECURITE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
