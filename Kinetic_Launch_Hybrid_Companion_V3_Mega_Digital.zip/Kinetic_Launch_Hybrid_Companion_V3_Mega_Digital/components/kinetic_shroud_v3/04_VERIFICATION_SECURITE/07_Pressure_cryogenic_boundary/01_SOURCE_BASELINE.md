# Frontière systèmes pressurisés / cryogéniques

Les « bonbonnes » deviennent, dans un vrai système, des équipements pressurisés/cryogéniques critiques : réservoirs, lignes, vannes, raccords, supports, isolation, protections et contrôles.

La V1 documentaire ne fournit pas de pression, température de service, matériau, épaisseur, procédé de soudage ou procédure d'essai. Ces paramètres doivent être développés sous standard applicable par des ingénieurs qualifiés et avec moyens certifiés.
