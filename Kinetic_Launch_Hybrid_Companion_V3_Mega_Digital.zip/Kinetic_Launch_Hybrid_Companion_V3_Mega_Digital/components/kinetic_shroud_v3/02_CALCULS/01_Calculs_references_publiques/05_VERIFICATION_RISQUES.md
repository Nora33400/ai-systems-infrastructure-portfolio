# Calculs à partir de références publiques — vérification, risques et critères

## Méthodes
- recalcul indépendant
- contrôle d'unités
- test de sensibilité
- bornes P10/P50/P80/P90
- audit hypothèses

## Points issus de la source
- Vérifier : Élancement : `H/D = 70 / 3.7 = 18.918919`
- Vérifier : Fraction charge LEO : `22 800 / 549 054 = 0.041526 = 4.153%`
- Vérifier : Fraction charge LEO : `63 800 / 1 420 788 = 0.044905 = 4.490%`
- Vérifier : Élancement : `124 / 9 = 13.777778`

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
