# Calculs à partir de références publiques

## Falcon 9
Données publiques : H = 70.0 m, D = 3.7 m, masse = 549,054 kg, LEO = 22,800 kg.

- Élancement : `H/D = 70 / 3.7 = 18.918919`
- Fraction charge LEO : `22 800 / 549 054 = 0.041526 = 4.153%`

## Falcon Heavy
- Fraction charge LEO : `63 800 / 1 420 788 = 0.044905 = 4.490%`

## Starship
Données publiques actuelles : H = 124 m, D = 9 m, capacité annoncée = 100+ t.
- Élancement : `124 / 9 = 13.777778`

### Utilisation correcte
Ces valeurs sont des **ancres de plausibilité**, pas des dimensions proposées pour Kinetic‑Shroud.
