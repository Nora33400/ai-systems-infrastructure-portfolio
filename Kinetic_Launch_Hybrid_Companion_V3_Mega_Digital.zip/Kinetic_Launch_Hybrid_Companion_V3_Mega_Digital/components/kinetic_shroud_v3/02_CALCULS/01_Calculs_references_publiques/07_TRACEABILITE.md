# Calculs à partir de références publiques — traçabilité

## Origine
- Ancien chemin V1 : `02_CALCULS/01_Calculs_references_publiques.md`
- SHA-256 V1 : `bd8e62d5fe0e00214779b29e8ed39ac27acde9baaf8f6bcdb33702bfcf3c8d74`
- Catégorie : `02_CALCULS`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
