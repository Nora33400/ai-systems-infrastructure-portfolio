# Calculs à partir de références publiques — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **modèles chiffrés, hypothèses, incertitudes et sensibilité**.

## Structure détectée
- Niveau 1: **Calculs à partir de références publiques**
- Niveau 2: **Falcon 9**
- Niveau 2: **Falcon Heavy**
- Niveau 2: **Starship**
- Niveau 3: **Utilisation correcte**

## Énoncés de baseline extraits
- Élancement : `H/D = 70 / 3.7 = 18.918919`
- Fraction charge LEO : `22 800 / 549 054 = 0.041526 = 4.153%`
- Fraction charge LEO : `63 800 / 1 420 788 = 0.044905 = 4.490%`
- Élancement : `124 / 9 = 13.777778`

## Axes à documenter
- unités et dimensions
- équations
- valeurs d'entrée
- incertitude
- scénarios
- sensibilité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
