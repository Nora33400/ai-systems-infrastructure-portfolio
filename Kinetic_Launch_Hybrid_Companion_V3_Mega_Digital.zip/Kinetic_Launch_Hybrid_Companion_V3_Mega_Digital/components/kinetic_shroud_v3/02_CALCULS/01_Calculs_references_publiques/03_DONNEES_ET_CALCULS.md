# Calculs à partir de références publiques — données et calculs

## Valeurs numériques détectées
- `70.0 m`
- `3.7 m`
- `549,054 kg`
- `22,800 kg`
- `70`
- `3.7`
- `18.918919`
- `22 800`
- `549 054`
- `0.041526`
- `4.153%`
- `63 800`
- `1 420 788`
- `0.044905`
- `4.490%`
- `124 m`
- `9 m`
- `100`
- `124`
- `13.777778`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Discipline de calcul
Pour chaque grandeur : symbole, unité SI, valeur, source, date, incertitude et statut.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
