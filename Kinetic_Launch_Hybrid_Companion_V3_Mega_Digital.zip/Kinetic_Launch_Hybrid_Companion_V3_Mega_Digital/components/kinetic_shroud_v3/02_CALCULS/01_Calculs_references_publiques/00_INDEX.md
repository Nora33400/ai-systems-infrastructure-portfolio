# Calculs à partir de références publiques — dossier développé

**Ancien document :** `02_CALCULS/01_Calculs_references_publiques.md`  
**Catégorie :** `02_CALCULS`  
**Version :** V2 Expanded  
**Hash source :** `bd8e62d5fe0e00214779b29e8ed39ac27acde9baaf8f6bcdb33702bfcf3c8d74`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
