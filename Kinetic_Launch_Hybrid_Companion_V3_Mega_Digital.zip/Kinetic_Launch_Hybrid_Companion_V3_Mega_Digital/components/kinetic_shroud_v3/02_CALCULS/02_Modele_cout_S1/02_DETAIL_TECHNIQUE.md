# Modèle de coût S1 — démonstrateur non-vol — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **modèles chiffrés, hypothèses, incertitudes et sensibilité**.

## Structure détectée
- Niveau 1: **Modèle de coût S1 — démonstrateur non-vol**
- Niveau 2: **Travail**
- Niveau 2: **Hors travail**
- Niveau 3: **Important**

## Énoncés de baseline extraits
- Matières, usinage, sous-traitance: **850,000 €**
- Outillages + instrumentation d'essai: **450,000 €**
- Location / adaptation moyens d'essai: **300,000 €**
- Logiciels, calcul, gestion de configuration: **100,000 €**
- QA, sécurité, documentation, conformité: **250,000 €**

## Axes à documenter
- unités et dimensions
- équations
- valeurs d'entrée
- incertitude
- scénarios
- sensibilité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
