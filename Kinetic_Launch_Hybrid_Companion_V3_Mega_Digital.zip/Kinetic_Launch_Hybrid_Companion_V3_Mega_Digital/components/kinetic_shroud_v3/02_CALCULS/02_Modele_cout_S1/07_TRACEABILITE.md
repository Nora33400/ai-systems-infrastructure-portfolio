# Modèle de coût S1 — démonstrateur non-vol — traçabilité

## Origine
- Ancien chemin V1 : `02_CALCULS/02_Modele_cout_S1.md`
- SHA-256 V1 : `64f38af3e2737bfd4d7de624d057983939e7fa4e61cce879d3c19c396b290b24`
- Catégorie : `02_CALCULS`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
