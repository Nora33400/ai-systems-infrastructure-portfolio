# Modèle de coût S1 — démonstrateur non-vol — données et calculs

## Valeurs numériques détectées
- `29,850 h`
- `3,270,750 €`
- `850,000 €`
- `450,000 €`
- `300,000 €`
- `100,000 €`
- `250,000 €`
- `5,220,750 €`
- `30%`
- `1,566,225 €`
- `6,786,975 €`
- `6.787 M`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Discipline de calcul
Pour chaque grandeur : symbole, unité SI, valeur, source, date, incertitude et statut.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
