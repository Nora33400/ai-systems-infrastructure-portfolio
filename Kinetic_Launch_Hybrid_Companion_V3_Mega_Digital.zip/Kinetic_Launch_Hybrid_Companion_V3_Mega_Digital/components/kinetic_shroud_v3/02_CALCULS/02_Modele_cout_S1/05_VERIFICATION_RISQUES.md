# Modèle de coût S1 — démonstrateur non-vol — vérification, risques et critères

## Méthodes
- recalcul indépendant
- contrôle d'unités
- test de sensibilité
- bornes P10/P50/P80/P90
- audit hypothèses

## Points issus de la source
- Vérifier : Matières, usinage, sous-traitance: **850,000 €**
- Vérifier : Outillages + instrumentation d'essai: **450,000 €**
- Vérifier : Location / adaptation moyens d'essai: **300,000 €**
- Vérifier : Logiciels, calcul, gestion de configuration: **100,000 €**
- Vérifier : QA, sécurité, documentation, conformité: **250,000 €**

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
