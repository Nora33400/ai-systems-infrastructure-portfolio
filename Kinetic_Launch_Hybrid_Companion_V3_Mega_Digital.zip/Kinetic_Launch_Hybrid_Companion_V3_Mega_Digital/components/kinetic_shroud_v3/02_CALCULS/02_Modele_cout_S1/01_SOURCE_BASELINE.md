# Modèle de coût S1 — démonstrateur non-vol

## Travail
Heures totales : **29,850 h**  
Coût travail : **3,270,750 €**

## Hors travail
- Matières, usinage, sous-traitance: **850,000 €**
- Outillages + instrumentation d'essai: **450,000 €**
- Location / adaptation moyens d'essai: **300,000 €**
- Logiciels, calcul, gestion de configuration: **100,000 €**
- QA, sécurité, documentation, conformité: **250,000 €**

Sous-total avant réserve : **5,220,750 €**  
Réserve de planification : **30% = 1,566,225 €**  
**Total déterministe : 6,786,975 € (6.787 M€)**

### Important
Ce montant est un **ROM paramétrique de démonstrateur mécanique non-vol**, pas un devis industriel et pas le coût d'un véhicule orbital.
