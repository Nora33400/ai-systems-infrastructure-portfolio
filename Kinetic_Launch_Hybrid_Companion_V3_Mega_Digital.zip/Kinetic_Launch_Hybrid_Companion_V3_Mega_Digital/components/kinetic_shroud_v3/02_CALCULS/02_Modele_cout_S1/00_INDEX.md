# Modèle de coût S1 — démonstrateur non-vol — dossier développé

**Ancien document :** `02_CALCULS/02_Modele_cout_S1.md`  
**Catégorie :** `02_CALCULS`  
**Version :** V2 Expanded  
**Hash source :** `64f38af3e2737bfd4d7de624d057983939e7fa4e61cce879d3c19c396b290b24`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
