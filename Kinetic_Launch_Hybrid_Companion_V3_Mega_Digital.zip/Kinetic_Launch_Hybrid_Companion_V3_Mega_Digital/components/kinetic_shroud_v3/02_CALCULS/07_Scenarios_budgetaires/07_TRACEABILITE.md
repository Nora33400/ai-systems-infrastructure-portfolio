# Scénarios budgétaires — traçabilité

## Origine
- Ancien chemin V1 : `02_CALCULS/07_Scenarios_budgetaires.md`
- SHA-256 V1 : `3a88ff00a927a2e29ee434a13230694acf1d6a78ca884a88c8187d41a1fd323c`
- Catégorie : `02_CALCULS`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
