# Scénarios budgétaires — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **modèles chiffrés, hypothèses, incertitudes et sensibilité**.

## Structure détectée
- Niveau 1: **Scénarios budgétaires**

## Énoncés de baseline extraits
- **S0 — Étude documentaire + faisabilité numérique** : 6 mois ; 9,000 h ; 1.350 M€ — Architecture, exigences, modèles, maquettes numériques; aucun article propulsif.
- **S1 — Démonstrateur mécanique non-vol** : 15 mois ; 29,850 h ; 6.787 M€ — Sous-systèmes mécaniques, interfaces, séparation/repli simulés à énergie sûre; essais au sol.
- **S2 — Article structurel intégré au sol** : 30 mois ; 140,000 h ; 28.000 M€ — Structure intégrée, moyens d'essais lourds, qualification partielle; sans système de propulsion opérationnel.
- **S3 — Véhicule orbital** : N/D mois ; heures N/D ; coût non chiffré — Non chiffré: données de mission, masse, propulsion, loads, avionique, site, licence et architecture validée absentes.

## Axes à documenter
- unités et dimensions
- équations
- valeurs d'entrée
- incertitude
- scénarios
- sensibilité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
