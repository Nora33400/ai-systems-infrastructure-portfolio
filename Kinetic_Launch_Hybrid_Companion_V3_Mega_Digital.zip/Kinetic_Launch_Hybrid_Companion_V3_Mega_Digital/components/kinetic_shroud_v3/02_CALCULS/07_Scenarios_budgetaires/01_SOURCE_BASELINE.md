# Scénarios budgétaires

- **S0 — Étude documentaire + faisabilité numérique** : 6 mois ; 9,000 h ; 1.350 M€ — Architecture, exigences, modèles, maquettes numériques; aucun article propulsif.
- **S1 — Démonstrateur mécanique non-vol** : 15 mois ; 29,850 h ; 6.787 M€ — Sous-systèmes mécaniques, interfaces, séparation/repli simulés à énergie sûre; essais au sol.
- **S2 — Article structurel intégré au sol** : 30 mois ; 140,000 h ; 28.000 M€ — Structure intégrée, moyens d'essais lourds, qualification partielle; sans système de propulsion opérationnel.
- **S3 — Véhicule orbital** : N/D mois ; heures N/D ; coût non chiffré — Non chiffré: données de mission, masse, propulsion, loads, avionique, site, licence et architecture validée absentes.
