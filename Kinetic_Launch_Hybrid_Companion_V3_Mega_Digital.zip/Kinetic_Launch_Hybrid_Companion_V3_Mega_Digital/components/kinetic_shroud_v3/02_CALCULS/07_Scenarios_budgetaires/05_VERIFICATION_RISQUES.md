# Scénarios budgétaires — vérification, risques et critères

## Méthodes
- recalcul indépendant
- contrôle d'unités
- test de sensibilité
- bornes P10/P50/P80/P90
- audit hypothèses

## Points issus de la source
- Vérifier : **S0 — Étude documentaire + faisabilité numérique** : 6 mois ; 9,000 h ; 1.350 M€ — Architecture, exigences, modèles, maquettes numériques; aucun article propulsif.
- Vérifier : **S1 — Démonstrateur mécanique non-vol** : 15 mois ; 29,850 h ; 6.787 M€ — Sous-systèmes mécaniques, interfaces, séparation/repli simulés à énergie sûre; essais au sol.
- Vérifier : **S2 — Article structurel intégré au sol** : 30 mois ; 140,000 h ; 28.000 M€ — Structure intégrée, moyens d'essais lourds, qualification partielle; sans système de propulsion opérationnel.
- Vérifier : **S3 — Véhicule orbital** : N/D mois ; heures N/D ; coût non chiffré — Non chiffré: données de mission, masse, propulsion, loads, avionique, site, licence et architecture validée absentes.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
