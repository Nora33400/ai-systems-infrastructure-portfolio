# Scénarios budgétaires — données et calculs

## Valeurs numériques détectées
- `6 m`
- `9,000 h`
- `1.350 M`
- `15 m`
- `29,850 h`
- `6.787 M`
- `30 m`
- `140,000 h`
- `28.000 M`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Discipline de calcul
Pour chaque grandeur : symbole, unité SI, valeur, source, date, incertitude et statut.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
