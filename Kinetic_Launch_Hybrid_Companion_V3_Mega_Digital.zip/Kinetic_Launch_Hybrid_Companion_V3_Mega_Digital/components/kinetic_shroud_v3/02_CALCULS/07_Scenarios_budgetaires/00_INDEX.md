# Scénarios budgétaires — dossier développé

**Ancien document :** `02_CALCULS/07_Scenarios_budgetaires.md`  
**Catégorie :** `02_CALCULS`  
**Version :** V2 Expanded  
**Hash source :** `3a88ff00a927a2e29ee434a13230694acf1d6a78ca884a88c8187d41a1fd323c`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
