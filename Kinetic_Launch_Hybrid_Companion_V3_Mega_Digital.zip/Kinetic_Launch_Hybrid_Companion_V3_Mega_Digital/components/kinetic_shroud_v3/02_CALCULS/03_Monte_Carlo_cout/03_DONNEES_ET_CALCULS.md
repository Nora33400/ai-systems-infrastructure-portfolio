# Incertitude coût — Monte-Carlo — données et calculs

## Valeurs numériques détectées
- `30 000`
- `260819`
- `5.164 M`
- `5.581 M`
- `5.881 M`
- `6.035 M`
- `5.591 M`
- `06`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Modèle recommandé
Utiliser des distributions documentées, conserver la graine et publier au moins P10/P50/P80/P90.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
