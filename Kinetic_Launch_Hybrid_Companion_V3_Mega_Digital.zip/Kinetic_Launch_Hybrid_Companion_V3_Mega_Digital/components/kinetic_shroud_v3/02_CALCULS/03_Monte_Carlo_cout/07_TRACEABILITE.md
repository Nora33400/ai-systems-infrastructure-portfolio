# Incertitude coût — Monte-Carlo — traçabilité

## Origine
- Ancien chemin V1 : `02_CALCULS/03_Monte_Carlo_cout.md`
- SHA-256 V1 : `583d04963baf241eda48f4c6ee8b538e51c00a47defe81803a167f468b4f86f2`
- Catégorie : `02_CALCULS`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
