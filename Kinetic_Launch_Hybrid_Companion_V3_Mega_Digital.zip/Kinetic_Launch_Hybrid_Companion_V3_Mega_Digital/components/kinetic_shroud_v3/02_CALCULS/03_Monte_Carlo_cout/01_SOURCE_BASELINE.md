# Incertitude coût — Monte-Carlo

Simulation déterministe reproductible : 30 000 tirages triangulaires, graine `260819`.

- P10 : **5.164 M€**
- P50 : **5.581 M€**
- P80 : **5.881 M€**
- P90 : **6.035 M€**
- Moyenne : **5.591 M€**

Les distributions d'entrée sont dans `06_MODELES_MACHINE/cost_monte_carlo_inputs.json`.
