# Incertitude coût — Monte-Carlo — vérification, risques et critères

## Méthodes
- recalcul indépendant
- contrôle d'unités
- test de sensibilité
- bornes P10/P50/P80/P90
- audit hypothèses

## Points issus de la source
- Vérifier : P10 : **5.164 M€**
- Vérifier : P50 : **5.581 M€**
- Vérifier : P80 : **5.881 M€**
- Vérifier : P90 : **6.035 M€**
- Vérifier : Moyenne : **5.591 M€**

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
