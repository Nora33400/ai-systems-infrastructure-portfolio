# Bilan énergétique des mécanismes dits passifs — traçabilité

## Origine
- Ancien chemin V1 : `02_CALCULS/06_Energie_passive_bilan.md`
- SHA-256 V1 : `028512b780b00af4a5d0fa85a109590ed1586819355048b303a729c3371a7c68`
- Catégorie : `02_CALCULS`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
