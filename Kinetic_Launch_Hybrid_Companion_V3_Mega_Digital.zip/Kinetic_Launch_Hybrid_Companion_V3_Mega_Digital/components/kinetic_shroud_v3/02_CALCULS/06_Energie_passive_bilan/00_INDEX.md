# Bilan énergétique des mécanismes dits passifs — dossier développé

**Ancien document :** `02_CALCULS/06_Energie_passive_bilan.md`  
**Catégorie :** `02_CALCULS`  
**Version :** V2 Expanded  
**Hash source :** `028512b780b00af4a5d0fa85a109590ed1586819355048b303a729c3371a7c68`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
