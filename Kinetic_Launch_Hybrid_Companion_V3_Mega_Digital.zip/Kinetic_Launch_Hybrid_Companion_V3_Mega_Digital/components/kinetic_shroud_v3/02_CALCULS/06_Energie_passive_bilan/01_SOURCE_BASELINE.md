# Bilan énergétique des mécanismes dits passifs

Un mécanisme « passif » n'a jamais une énergie nette gratuite.

Bilan conceptuel :
`E_disponible = E_mouvement_source - E_pertes_frottement - E_deformation - E_chocs - E_marge`

Conséquences :
- une rampe/came peut **transférer** une partie d'un mouvement vers un autre ;
- l'inertie peut contribuer à une cinématique ;
- des ressorts peuvent stocker puis restituer une énergie préalablement fournie ;
- aucune de ces solutions ne permet de compter « 0 W » au niveau système si la force source a été créée par le véhicule.

Le dossier remplace donc « zéro énergie » par « **actionneur dédié potentiellement supprimable** ».
