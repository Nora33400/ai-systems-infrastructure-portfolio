# Bilan énergétique des mécanismes dits passifs — vérification, risques et critères

## Méthodes
- recalcul indépendant
- contrôle d'unités
- test de sensibilité
- bornes P10/P50/P80/P90
- audit hypothèses

## Points issus de la source
- Vérifier : une rampe/came peut **transférer** une partie d'un mouvement vers un autre ;
- Vérifier : l'inertie peut contribuer à une cinématique ;
- Vérifier : des ressorts peuvent stocker puis restituer une énergie préalablement fournie ;
- Vérifier : aucune de ces solutions ne permet de compter « 0 W » au niveau système si la force source a été créée par le véhicule.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
