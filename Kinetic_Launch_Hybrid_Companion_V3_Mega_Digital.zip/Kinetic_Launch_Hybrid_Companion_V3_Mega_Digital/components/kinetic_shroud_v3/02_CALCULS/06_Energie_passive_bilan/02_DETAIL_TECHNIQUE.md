# Bilan énergétique des mécanismes dits passifs — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **modèles chiffrés, hypothèses, incertitudes et sensibilité**.

## Structure détectée
- Niveau 1: **Bilan énergétique des mécanismes dits passifs**

## Énoncés de baseline extraits
- une rampe/came peut **transférer** une partie d'un mouvement vers un autre ;
- l'inertie peut contribuer à une cinématique ;
- des ressorts peuvent stocker puis restituer une énergie préalablement fournie ;
- aucune de ces solutions ne permet de compter « 0 W » au niveau système si la force source a été créée par le véhicule.

## Axes à documenter
- unités et dimensions
- équations
- valeurs d'entrée
- incertitude
- scénarios
- sensibilité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
