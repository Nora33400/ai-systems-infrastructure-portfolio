# Durées, charge de travail et capacité

Somme séquentielle des phases : **80 semaines**.  
Calendrier cible avec chevauchements : **60 semaines** (~13.8 mois).  
Charge cumulée : **29,850 heures**.

Équivalence homme-années à 1 650 h/an : `29850 / 1650 = 18.09` ETP-an.

La différence entre 80 semaines séquentielles et 60 semaines calendaires suppose des activités parallèles; elle doit être remplacée par un planning réseau une fois les dépendances stabilisées.
