# Durées, charge de travail et capacité — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **modèles chiffrés, hypothèses, incertitudes et sensibilité**.

## Structure détectée
- Niveau 1: **Durées, charge de travail et capacité**

## Énoncés de baseline extraits
- Somme séquentielle des phases : **80 semaines**.  
Calendrier cible avec chevauchements : **60 semaines** (~13.8 mois).  
Charge cumulée : **29,850 heures**.
- Équivalence homme-années à 1 650 h/an : `29850 / 1650 = 18.09` ETP-an.
- La différence entre 80 semaines séquentielles et 60 semaines calendaires suppose des activités parallèles; elle doit être remplacée par un planning réseau une fois les dépendances stabilisées.

## Axes à documenter
- unités et dimensions
- équations
- valeurs d'entrée
- incertitude
- scénarios
- sensibilité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
