# Durées, charge de travail et capacité — dossier développé

**Ancien document :** `02_CALCULS/04_Durees_et_charge.md`  
**Catégorie :** `02_CALCULS`  
**Version :** V2 Expanded  
**Hash source :** `7c25038f76d3909dfe347871e3a5b759f0f467dd6b2eb7a0079d0688e4c4f967`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
