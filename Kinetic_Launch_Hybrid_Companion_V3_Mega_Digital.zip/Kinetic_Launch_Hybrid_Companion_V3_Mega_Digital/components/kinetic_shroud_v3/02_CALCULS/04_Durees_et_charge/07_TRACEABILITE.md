# Durées, charge de travail et capacité — traçabilité

## Origine
- Ancien chemin V1 : `02_CALCULS/04_Durees_et_charge.md`
- SHA-256 V1 : `7c25038f76d3909dfe347871e3a5b759f0f467dd6b2eb7a0079d0688e4c4f967`
- Catégorie : `02_CALCULS`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
