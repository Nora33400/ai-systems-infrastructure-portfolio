# Prix matières — méthode de calcul

La source ne contient ni masse de matière par pièce, ni nuance finale, ni quantité commandée. Un prix total matière « précis » serait donc inventé.

Le modèle proposé utilise :
`C_matière = masse_nette × prix_unitaire × facteur_chute × facteur_aérospatial`

À renseigner pour chaque lot :
- masse nette issue CAO ;
- nuance exacte ;
- prix daté et fournisseur ;
- quantité minimum ;
- facteur de rebut/chutes ;
- certificat matière ;
- traitement thermique / surface ;
- usinage et contrôle non destructif séparés.

Les publications USGS servent de **référence macro de marché**, pas de devis pour alliage aérospatial fini.
