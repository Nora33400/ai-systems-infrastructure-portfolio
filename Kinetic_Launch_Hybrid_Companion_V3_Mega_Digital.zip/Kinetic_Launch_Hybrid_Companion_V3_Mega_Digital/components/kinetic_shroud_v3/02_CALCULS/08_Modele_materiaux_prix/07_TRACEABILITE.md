# Prix matières — méthode de calcul — traçabilité

## Origine
- Ancien chemin V1 : `02_CALCULS/08_Modele_materiaux_prix.md`
- SHA-256 V1 : `48870dbe377d30de56a3dec2d4dfcb43034b06815fe6eac5f4954c40b047d6db`
- Catégorie : `02_CALCULS`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
