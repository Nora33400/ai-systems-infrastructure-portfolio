# Prix matières — méthode de calcul — vérification, risques et critères

## Méthodes
- recalcul indépendant
- contrôle d'unités
- test de sensibilité
- bornes P10/P50/P80/P90
- audit hypothèses

## Points issus de la source
- Vérifier : masse nette issue CAO ;
- Vérifier : nuance exacte ;
- Vérifier : prix daté et fournisseur ;
- Vérifier : quantité minimum ;
- Vérifier : facteur de rebut/chutes ;
- Vérifier : certificat matière ;
- Vérifier : traitement thermique / surface ;
- Vérifier : usinage et contrôle non destructif séparés.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
