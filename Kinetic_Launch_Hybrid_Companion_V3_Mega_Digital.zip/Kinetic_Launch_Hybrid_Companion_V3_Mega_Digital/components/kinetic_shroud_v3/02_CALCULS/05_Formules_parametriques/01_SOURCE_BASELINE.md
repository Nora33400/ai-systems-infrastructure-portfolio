# Formules paramétriques

## Coût
- `C_travail = Σ(heures_i × taux_i)`
- `C_base = C_travail + C_matières + C_outillage + C_essais + C_installations + C_QA`
- `C_plan = C_base × (1 + réserve)`

## Surface de coque — uniquement pour modèle géométrique
Pour un cylindre idéal de diamètre `D` et hauteur `H` :
- surface latérale `A = π D H`
- avec `N` segments identiques, surface théorique par segment `A/N`

Aucune épaisseur ni masse de vol n'est imposée dans cette V1.

## Centre de masse (modèle générique)
`r_CM = Σ(m_i r_i) / Σ(m_i)`

Le fait de déplacer deux masses égales en sens opposés peut maintenir le centre de masse dans un modèle idéal, mais ne supprime pas nécessairement couples, vibrations, jeux, accélérations transitoires et déformation structurelle.
