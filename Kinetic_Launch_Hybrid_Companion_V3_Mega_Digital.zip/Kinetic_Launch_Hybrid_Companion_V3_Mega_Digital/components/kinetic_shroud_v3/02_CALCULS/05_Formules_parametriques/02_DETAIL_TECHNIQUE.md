# Formules paramétriques — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **modèles chiffrés, hypothèses, incertitudes et sensibilité**.

## Structure détectée
- Niveau 1: **Formules paramétriques**
- Niveau 2: **Coût**
- Niveau 2: **Surface de coque — uniquement pour modèle géométrique**
- Niveau 2: **Centre de masse (modèle générique)**

## Énoncés de baseline extraits
- `C_travail = Σ(heures_i × taux_i)`
- `C_base = C_travail + C_matières + C_outillage + C_essais + C_installations + C_QA`
- `C_plan = C_base × (1 + réserve)`
- surface latérale `A = π D H`
- avec `N` segments identiques, surface théorique par segment `A/N`

## Axes à documenter
- unités et dimensions
- équations
- valeurs d'entrée
- incertitude
- scénarios
- sensibilité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
