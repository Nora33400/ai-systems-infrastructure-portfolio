# Formules paramétriques — vérification, risques et critères

## Méthodes
- recalcul indépendant
- contrôle d'unités
- test de sensibilité
- bornes P10/P50/P80/P90
- audit hypothèses

## Points issus de la source
- Vérifier : `C_travail = Σ(heures_i × taux_i)`
- Vérifier : `C_base = C_travail + C_matières + C_outillage + C_essais + C_installations + C_QA`
- Vérifier : `C_plan = C_base × (1 + réserve)`
- Vérifier : surface latérale `A = π D H`
- Vérifier : avec `N` segments identiques, surface théorique par segment `A/N`

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
