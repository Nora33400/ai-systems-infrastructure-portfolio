# Plan de conception

### Gate G0 — Concept figé
Architecture, mission de démonstration, hypothèses et exclusions signées.

### G1 — SRR-like
Exigences traçables, risques critiques identifiés.

### G2 — PDR-like
Interfaces et analyses principales assez matures pour lancer le démonstrateur.

### G3 — CDR-like démonstrateur
Dossiers de fabrication libérés; instrumentation et procédures d'essai approuvées.

### G4 — TRR
Moyen d'essai, article, sécurité, critères succès/abort validés.

### G5 — Test / Review
Résultats, écarts, décision itération/arrêt/poursuite.
