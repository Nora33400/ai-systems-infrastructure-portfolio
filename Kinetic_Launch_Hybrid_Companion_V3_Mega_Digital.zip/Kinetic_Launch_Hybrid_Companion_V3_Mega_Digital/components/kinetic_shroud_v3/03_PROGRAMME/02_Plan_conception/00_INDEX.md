# Plan de conception — dossier développé

**Ancien document :** `03_PROGRAMME/02_Plan_conception.md`  
**Catégorie :** `03_PROGRAMME`  
**Version :** V2 Expanded  
**Hash source :** `59fbc9507390d27931c2a41e22fa6a4b85717adb54aad0be789a2ba8d87a9686`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
