# Gestion de configuration — vérification, risques et critères

## Méthodes
- revue de jalon
- audit de configuration
- contrôle complétude livrables
- analyse chemin critique
- revue budget

## Points issus de la source
- Vérifier : `KS-BL-001` : architecture source nettoyée.
- Vérifier : `KS-BL-002` : architecture V1 corrigée physiquement.
- Vérifier : `KS-DM-xxx` : modèles numériques.
- Vérifier : `KS-REQ-xxx` : exigences.
- Vérifier : `KS-ICD-xxx` : interfaces.
- Vérifier : `KS-TEST-xxx` : procédures/résultats.
- Vérifier : `KS-NCR-xxx` : non-conformités.
- Vérifier : `KS-DEC-xxx` : décisions.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
