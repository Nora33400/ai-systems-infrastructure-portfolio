# Gestion de configuration — traçabilité

## Origine
- Ancien chemin V1 : `03_PROGRAMME/07_Configuration_management.md`
- SHA-256 V1 : `95cd4a666ac5f1151f57cdfc460e36efd40ea07d53b58b647dbd990b05df4678`
- Catégorie : `03_PROGRAMME`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
