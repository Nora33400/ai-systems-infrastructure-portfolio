# Gestion de configuration

Baseline proposée :
- `KS-BL-001` : architecture source nettoyée.
- `KS-BL-002` : architecture V1 corrigée physiquement.
- `KS-DM-xxx` : modèles numériques.
- `KS-REQ-xxx` : exigences.
- `KS-ICD-xxx` : interfaces.
- `KS-TEST-xxx` : procédures/résultats.
- `KS-NCR-xxx` : non-conformités.
- `KS-DEC-xxx` : décisions.

Toute modification d'un élément critique doit indiquer l'impact coût, planning, risque, interfaces et vérification.
