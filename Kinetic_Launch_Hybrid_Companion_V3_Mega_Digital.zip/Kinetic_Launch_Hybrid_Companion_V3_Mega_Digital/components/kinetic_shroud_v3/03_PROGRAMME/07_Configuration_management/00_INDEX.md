# Gestion de configuration — dossier développé

**Ancien document :** `03_PROGRAMME/07_Configuration_management.md`  
**Catégorie :** `03_PROGRAMME`  
**Version :** V2 Expanded  
**Hash source :** `95cd4a666ac5f1151f57cdfc460e36efd40ea07d53b58b647dbd990b05df4678`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
