# Décisions majeures à prendre — dossier développé

**Ancien document :** `03_PROGRAMME/08_Decision_gates.md`  
**Catégorie :** `03_PROGRAMME`  
**Version :** V2 Expanded  
**Hash source :** `ded4439ac2213a805057c94c28d9157ae7b80b1edf1adcd2f80225d8f8aeb7fc`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
