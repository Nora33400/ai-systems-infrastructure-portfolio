# Décisions majeures à prendre — traçabilité

## Origine
- Ancien chemin V1 : `03_PROGRAMME/08_Decision_gates.md`
- SHA-256 V1 : `ded4439ac2213a805057c94c28d9157ae7b80b1edf1adcd2f80225d8f8aeb7fc`
- Catégorie : `03_PROGRAMME`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
