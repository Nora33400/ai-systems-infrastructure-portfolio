# Décisions majeures à prendre — vérification, risques et critères

## Méthodes
- revue de jalon
- audit de configuration
- contrôle complétude livrables
- analyse chemin critique
- revue budget

## Points issus de la source
- Vérifier : Mission réelle du système.
- Vérifier : Noyau habité ou non habité pour les premiers prototypes.
- Vérifier : Nombre de segments par étage.
- Vérifier : Réservoirs mobiles ou réservoirs fixes + transfert séparé.
- Vérifier : Séparation passive, active ou hybride.
- Vérifier : Réutilisation des segments externes.
- Vérifier : Rampe : abandon, étude indépendante ou intégration.
- Vérifier : Matériau principal par sous-système.
- Vérifier : Niveau TRL cible du prochain cycle.
- Vérifier : Budget maximal acceptable avant arrêt.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
