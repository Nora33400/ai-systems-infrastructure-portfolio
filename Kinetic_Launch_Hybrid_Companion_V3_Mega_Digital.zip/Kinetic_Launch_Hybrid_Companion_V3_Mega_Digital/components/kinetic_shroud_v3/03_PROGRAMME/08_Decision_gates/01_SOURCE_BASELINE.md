# Décisions majeures à prendre

1. Mission réelle du système.
2. Noyau habité ou non habité pour les premiers prototypes.
3. Nombre de segments par étage.
4. Réservoirs mobiles ou réservoirs fixes + transfert séparé.
5. Séparation passive, active ou hybride.
6. Réutilisation des segments externes.
7. Rampe : abandon, étude indépendante ou intégration.
8. Matériau principal par sous-système.
9. Niveau TRL cible du prochain cycle.
10. Budget maximal acceptable avant arrêt.
