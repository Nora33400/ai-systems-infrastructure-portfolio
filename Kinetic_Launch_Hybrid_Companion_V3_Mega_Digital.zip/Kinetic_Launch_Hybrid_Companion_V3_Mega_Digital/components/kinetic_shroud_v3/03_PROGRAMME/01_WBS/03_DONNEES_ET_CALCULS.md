# Work Breakdown Structure (WBS) — données et calculs

## Valeurs numériques détectées
- `1.0 M`
- `2.0`
- `3.0`
- `4.0`
- `5.0`
- `6.0`
- `7.0`
- `8.0`
- `9.0`
- `10.0 G`
- `11.0`
- `12.0`
- `13.0 M`
- `14.0`
- `15.0`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Discipline de calcul
Pour chaque grandeur : symbole, unité SI, valeur, source, date, incertitude et statut.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
