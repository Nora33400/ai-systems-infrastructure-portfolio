# Work Breakdown Structure (WBS) — traçabilité

## Origine
- Ancien chemin V1 : `03_PROGRAMME/01_WBS.md`
- SHA-256 V1 : `3dfdbbfdc2e6ab803608b1b2e175c613db199b404e2b585bf9a269d8e9aaf6f5`
- Catégorie : `03_PROGRAMME`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
