# Work Breakdown Structure (WBS) — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **organisation du travail, dépendances, livrables, ressources et jalons**.

## Structure détectée
- Niveau 1: **Work Breakdown Structure (WBS)**

## Énoncés de baseline extraits
- 1.0 Management programme  
2.0 Systems engineering  
3.0 Safety & mission assurance  
4.0 Noyau Home  
5.0 Exo-coque 4 étages  
6.0 Interfaces et mécanismes de segmentation  
7.0 Réservoirs / systèmes pressurisés (branche critique séparée)  
8.0 Avionique et instrumentation  
9.0 Logiciel / modèle numérique  
10.0 Ground Support Equipment / rampe (option)  
11.0 Intégration et assemblage  
12.0 Vérification & validation  
13.0 Moyens d'essais  
14.0 Opérations / maintenance  
15.0 Documentation et configuration
- Structure inspirée d'une logique WBS produit afin de rattacher coût, planning, risque et vérification au même découpage.

## Axes à documenter
- WBS
- dépendances
- ressources
- critères d'entrée/sortie
- configuration
- coût/planning

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
