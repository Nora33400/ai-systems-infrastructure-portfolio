# Work Breakdown Structure (WBS)

1.0 Management programme  
2.0 Systems engineering  
3.0 Safety & mission assurance  
4.0 Noyau Home  
5.0 Exo-coque 4 étages  
6.0 Interfaces et mécanismes de segmentation  
7.0 Réservoirs / systèmes pressurisés (branche critique séparée)  
8.0 Avionique et instrumentation  
9.0 Logiciel / modèle numérique  
10.0 Ground Support Equipment / rampe (option)  
11.0 Intégration et assemblage  
12.0 Vérification & validation  
13.0 Moyens d'essais  
14.0 Opérations / maintenance  
15.0 Documentation et configuration

Structure inspirée d'une logique WBS produit afin de rattacher coût, planning, risque et vérification au même découpage.
