# Plan de fabrication — démonstrateur non-vol — vérification, risques et critères

## Méthodes
- revue de jalon
- audit de configuration
- contrôle complétude livrables
- analyse chemin critique
- revue budget

## Points issus de la source
- Vérifier : Libération des plans et nomenclatures.
- Vérifier : Approvisionnement matière commerciale non pressurisée pour maquettes.
- Vérifier : Fabrication des couples/anneaux de démonstration.
- Vérifier : Fabrication des panneaux segmentés.
- Vérifier : Fabrication des interfaces de guidage et butées.
- Vérifier : Métrologie dimensionnelle.
- Vérifier : Pré-assemblage de chaque étage.
- Vérifier : Assemblage autour du noyau factice instrumenté.
- Vérifier : Tests basse énergie.
- Vérifier : Reprise de conception.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
