# Plan de fabrication — démonstrateur non-vol — traçabilité

## Origine
- Ancien chemin V1 : `03_PROGRAMME/03_Plan_fabrication.md`
- SHA-256 V1 : `3ab4dfb6927863f0f8b89580eea6429ed5e2aef1b4f507640f0f4eebc1056e19`
- Catégorie : `03_PROGRAMME`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
