# Plan de fabrication — démonstrateur non-vol — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **organisation du travail, dépendances, livrables, ressources et jalons**.

## Structure détectée
- Niveau 1: **Plan de fabrication — démonstrateur non-vol**

## Énoncés de baseline extraits
- Libération des plans et nomenclatures.
- Approvisionnement matière commerciale non pressurisée pour maquettes.
- Fabrication des couples/anneaux de démonstration.
- Fabrication des panneaux segmentés.
- Fabrication des interfaces de guidage et butées.
- Métrologie dimensionnelle.
- Pré-assemblage de chaque étage.
- Assemblage autour du noyau factice instrumenté.
- Tests basse énergie.
- Reprise de conception.

## Axes à documenter
- WBS
- dépendances
- ressources
- critères d'entrée/sortie
- configuration
- coût/planning

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
