# Plan de fabrication — démonstrateur non-vol

1. Libération des plans et nomenclatures.
2. Approvisionnement matière commerciale non pressurisée pour maquettes.
3. Fabrication des couples/anneaux de démonstration.
4. Fabrication des panneaux segmentés.
5. Fabrication des interfaces de guidage et butées.
6. Métrologie dimensionnelle.
7. Pré-assemblage de chaque étage.
8. Assemblage autour du noyau factice instrumenté.
9. Tests basse énergie.
10. Reprise de conception.

Les réservoirs réels pressurisés/cryogéniques ne font pas partie de ce plan V1.
