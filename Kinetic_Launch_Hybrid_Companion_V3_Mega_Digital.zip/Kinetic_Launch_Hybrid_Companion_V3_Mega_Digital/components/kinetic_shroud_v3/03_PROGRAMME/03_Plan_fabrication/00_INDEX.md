# Plan de fabrication — démonstrateur non-vol — dossier développé

**Ancien document :** `03_PROGRAMME/03_Plan_fabrication.md`  
**Catégorie :** `03_PROGRAMME`  
**Version :** V2 Expanded  
**Hash source :** `3ab4dfb6927863f0f8b89580eea6429ed5e2aef1b4f507640f0f4eebc1056e19`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
