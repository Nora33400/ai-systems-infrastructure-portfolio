# Plan d'analyse — traçabilité

## Origine
- Ancien chemin V1 : `03_PROGRAMME/05_Plan_analyse.md`
- SHA-256 V1 : `ffe5de94be5146dc229bd2cad12c871d18d9f90d1d48657e5d5e063b0bb6ccdd`
- Catégorie : `03_PROGRAMME`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
