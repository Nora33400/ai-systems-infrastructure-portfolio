# Plan d'analyse — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **organisation du travail, dépendances, livrables, ressources et jalons**.

## Structure détectée
- Niveau 1: **Plan d'analyse**

## Énoncés de baseline extraits
- géométrie et interférences ;
- chemins de charge ;
- modes propres/vibrations ;
- cinématique de séparation ;
- tolérances et jeux ;
- thermique préliminaire ;
- centre de masse ;
- fiabilité / fault tree ;
- facteurs humains ;
- coût et planning ;
- réglementation ;
- comparaison architecture classique / concentrique.

## Axes à documenter
- WBS
- dépendances
- ressources
- critères d'entrée/sortie
- configuration
- coût/planning

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
