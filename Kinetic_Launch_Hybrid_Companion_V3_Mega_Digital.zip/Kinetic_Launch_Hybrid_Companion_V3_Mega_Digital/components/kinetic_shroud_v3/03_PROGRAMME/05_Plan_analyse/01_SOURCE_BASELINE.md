# Plan d'analyse

Lots d'analyse :
- géométrie et interférences ;
- chemins de charge ;
- modes propres/vibrations ;
- cinématique de séparation ;
- tolérances et jeux ;
- thermique préliminaire ;
- centre de masse ;
- fiabilité / fault tree ;
- facteurs humains ;
- coût et planning ;
- réglementation ;
- comparaison architecture classique / concentrique.

Chaque analyse doit produire : entrées, hypothèses, modèle, résultats, incertitudes, décision.
