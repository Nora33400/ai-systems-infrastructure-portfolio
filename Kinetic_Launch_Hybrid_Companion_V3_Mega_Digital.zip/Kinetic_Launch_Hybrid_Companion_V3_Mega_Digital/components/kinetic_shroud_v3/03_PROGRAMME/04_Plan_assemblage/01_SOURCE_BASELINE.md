# Plan d'assemblage

- Assemblage par modules d'étage.
- Contrôle géométrique avant jonction.
- Installation instrumentation.
- Vérification des jeux et interférences.
- Fermeture des segments.
- Test de continuité des états.
- Essai de séparation à énergie sûre.
- Inspection post-test.
- Analyse des données et remise en configuration.

Objectif : démontrer la cinématique et la répétabilité avant toute tentative d'intégration de sous-systèmes plus énergétiques.
