# Plan d'assemblage — dossier développé

**Ancien document :** `03_PROGRAMME/04_Plan_assemblage.md`  
**Catégorie :** `03_PROGRAMME`  
**Version :** V2 Expanded  
**Hash source :** `5d325ee169c9aa8cd82dea3d9aea0972b91215f28c31b0868495663ccbc430a5`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
