# Plan d'assemblage — vérification, risques et critères

## Méthodes
- revue de jalon
- audit de configuration
- contrôle complétude livrables
- analyse chemin critique
- revue budget

## Points issus de la source
- Vérifier : Assemblage par modules d'étage.
- Vérifier : Contrôle géométrique avant jonction.
- Vérifier : Installation instrumentation.
- Vérifier : Vérification des jeux et interférences.
- Vérifier : Fermeture des segments.
- Vérifier : Test de continuité des états.
- Vérifier : Essai de séparation à énergie sûre.
- Vérifier : Inspection post-test.
- Vérifier : Analyse des données et remise en configuration.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
