# Plan d'assemblage — traçabilité

## Origine
- Ancien chemin V1 : `03_PROGRAMME/04_Plan_assemblage.md`
- SHA-256 V1 : `5d325ee169c9aa8cd82dea3d9aea0972b91215f28c31b0868495663ccbc430a5`
- Catégorie : `03_PROGRAMME`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
