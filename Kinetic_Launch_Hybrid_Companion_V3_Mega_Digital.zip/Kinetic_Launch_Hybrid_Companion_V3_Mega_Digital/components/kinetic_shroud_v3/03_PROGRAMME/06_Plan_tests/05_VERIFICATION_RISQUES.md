# Plan de tests — vérification, risques et critères

## Méthodes
- revue de jalon
- audit de configuration
- contrôle complétude livrables
- analyse chemin critique
- revue budget

## Points issus de la source
- Vérifier : test fonctionnel logiciel / machine d'états ;
- Vérifier : tests unitaires de segment ;
- Vérifier : tests répétabilité mécanisme ;
- Vérifier : tests d'interférence noyau/panneaux ;
- Vérifier : tests d'une maquette d'étage complète ;
- Vérifier : tests multi-étages en séquence à basse énergie ;
- Vérifier : vibrations/charges représentatives sur article non-vol ;
- Vérifier : revue d'écarts ;
- Vérifier : seulement ensuite : décision sur branches pressurisées et énergétiques par équipe qualifiée.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
