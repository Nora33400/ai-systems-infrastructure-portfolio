# Plan de tests — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **organisation du travail, dépendances, livrables, ressources et jalons**.

## Structure détectée
- Niveau 1: **Plan de tests**

## Énoncés de baseline extraits
- test fonctionnel logiciel / machine d'états ;
- tests unitaires de segment ;
- tests répétabilité mécanisme ;
- tests d'interférence noyau/panneaux ;
- tests d'une maquette d'étage complète ;
- tests multi-étages en séquence à basse énergie ;
- vibrations/charges représentatives sur article non-vol ;
- revue d'écarts ;
- seulement ensuite : décision sur branches pressurisées et énergétiques par équipe qualifiée.

## Axes à documenter
- WBS
- dépendances
- ressources
- critères d'entrée/sortie
- configuration
- coût/planning

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
