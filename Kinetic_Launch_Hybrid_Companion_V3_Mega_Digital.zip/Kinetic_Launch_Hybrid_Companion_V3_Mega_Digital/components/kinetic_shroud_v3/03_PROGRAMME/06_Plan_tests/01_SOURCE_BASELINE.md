# Plan de tests

Ordre recommandé :
1. test fonctionnel logiciel / machine d'états ;
2. tests unitaires de segment ;
3. tests répétabilité mécanisme ;
4. tests d'interférence noyau/panneaux ;
5. tests d'une maquette d'étage complète ;
6. tests multi-étages en séquence à basse énergie ;
7. vibrations/charges représentatives sur article non-vol ;
8. revue d'écarts ;
9. seulement ensuite : décision sur branches pressurisées et énergétiques par équipe qualifiée.

Les critères d'essai sont liés à la matrice `verification_matrix.csv`.
