from pathlib import Path
import json,tempfile,unittest,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from ks_digital.engine import build_project
from ks_digital.safety import assess_scope

class TestV3(unittest.TestCase):
    def load(self,name): return json.loads((ROOT/'examples'/name).read_text(encoding='utf-8'))
    def test_safe_request_builds(self):
        req=self.load('request_nonflight_concrete.json')
        with tempfile.TemporaryDirectory() as td:
            result=build_project(req,td)
            self.assertIn(result['gate'],{'ACCEPT','ACCEPT_WITH_GAPS'})
            self.assertEqual(result['scope_status'],'DIGITAL_SCOPE_OK')
            expected={'project_instance.json','EXECUTIVE_SUMMARY.md','requirement_matrix.csv','verification_plan.csv','risk_register_scoped.csv','wbs_plan.csv','budget_summary.json','missing_data.json','configuration_model.json','traceability.json','manifest.sha256.json'}
            self.assertTrue(expected.issubset({p.name for p in Path(td).iterdir()}))
    def test_operational_request_rejected(self):
        req=self.load('request_rejected_operational.json')
        self.assertFalse(assess_scope(req)['allowed'])
        with tempfile.TemporaryDirectory() as td:
            self.assertEqual(build_project(req,td)['gate'],'REJECT_SCOPE')
    def test_no_real_physical_parameters_generated(self):
        req=self.load('request_nonflight_concrete.json')
        with tempfile.TemporaryDirectory() as td:
            build_project(req,td)
            model=json.loads((Path(td)/'configuration_model.json').read_text(encoding='utf-8'))
            self.assertIsNone(model['physical_parameters'])
            self.assertEqual(model['physical_parameters_status'],'EXCLUDED_FROM_DIGITAL_LAYER')
    def test_unknown_constraint_stays_gap(self):
        req=self.load('request_nonflight_concrete.json'); req['constraints']['calendar_weeks_max']=None
        with tempfile.TemporaryDirectory() as td:
            build_project(req,td)
            gaps=json.loads((Path(td)/'missing_data.json').read_text(encoding='utf-8'))
            self.assertTrue(any(g['field']=='calendar_weeks_max' for g in gaps))
    def test_s1_uses_sourced_monte_carlo(self):
        req=self.load('request_nonflight_concrete.json'); req['scenario']='S1'; req['constraints']['budget_eur_max']=7000000
        with tempfile.TemporaryDirectory() as td:
            build_project(req,td)
            budget=json.loads((Path(td)/'budget_summary.json').read_text(encoding='utf-8'))
            self.assertEqual(budget['uncertainty']['seed'],260819)
            self.assertGreater(budget['uncertainty']['P90_eur'],budget['uncertainty']['P10_eur'])

if __name__=='__main__': unittest.main()
