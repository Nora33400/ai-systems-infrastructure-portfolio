#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python -m ks_digital build examples/request_nonflight_concrete.json --out build/example
python -m unittest discover -s tests -v
