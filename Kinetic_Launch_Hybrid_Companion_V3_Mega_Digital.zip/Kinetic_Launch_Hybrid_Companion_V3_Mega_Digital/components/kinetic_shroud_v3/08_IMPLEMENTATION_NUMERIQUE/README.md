# Kinetic-Shroud V3 — implémentation numérique

Cette couche transforme la documentation V2 en **projet numérique instanciable** à partir d'une demande concrète.

Elle ne dimensionne pas un système de vol et ne produit pas de paramètres de propulsion, d'ergols, de guidage, de profil de lancement, de sortie de rampe ou de récipient pressurisé prêt au vol. Son rôle est de convertir une demande en objets d'ingénierie traçables : exigences, WBS, risques, V&V, coûts ROM, décisions, données manquantes et modèle de configuration abstrait.

## Implémenté
- contrat JSON de demande ;
- validation structurale et contrôle de périmètre ;
- chargement des modèles machine V2 ;
- scoping exigences / risques / V&V ;
- WBS et coût ROM ;
- Monte-Carlo reproductible quand la V2 contient les distributions ;
- données manquantes explicites ;
- gate `ACCEPT / ACCEPT_WITH_GAPS / REJECT_SCOPE` ;
- modèle de configuration non physique ;
- manifeste SHA-256 ;
- adaptateur Python pour orchestrateur ;
- CLI standard-library-only ;
- tests unitaires.

## Démarrage
```bash
python -m ks_digital build examples/request_nonflight_concrete.json --out build/example
python -m unittest discover -s tests -v
```
