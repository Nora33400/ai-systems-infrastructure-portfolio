from pathlib import Path
import hashlib
from .models import load_baseline
from .validation import validate_request
from .safety import assess_scope
from .costing import build_budget
from .io import write_json, write_csv

def _applicability(req, requirement):
    rid=requirement["id"]; scope=req.get("scope",{})
    if rid=="REQ-SYS-006" and not scope.get("pressurized_or_cryogenic"):
        return "DEFERRED","Sous-système pressurisé/cryogénique non demandé dans cette instance."
    if rid=="REQ-SYS-007" and not scope.get("human_rated"):
        return "DEFERRED","Conception habitée non demandée dans cette instance."
    if rid=="REQ-SYS-010" and not scope.get("ramp_trade_study"):
        return "DEFERRED","Étude de rampe non demandée."
    return "APPLICABLE","Exigence de baseline applicable au périmètre numérique."

def _scope_requirements(req, baseline):
    rows=[]
    for r in baseline["requirements"]:
        status,rationale=_applicability(req,r)
        rows.append({**r,"applicability":status,"rationale":rationale,"verification_status":"PLANNED" if status=="APPLICABLE" else "DEFERRED"})
    return rows

def _scope_verification(req_rows, baseline):
    applicable={r["id"] for r in req_rows if r["applicability"]=="APPLICABLE"}
    by_req={}
    for v in baseline["verification"]: by_req.setdefault(v["requirement_id"],[]).append(v)
    rows=[]
    for r in req_rows:
        if r["id"] not in applicable: continue
        vs=by_req.get(r["id"])
        if vs:
            for v in vs: rows.append({**v,"status":"PLANNED","evidence":"N/D"})
        else:
            rows.append({"test_id":"GAP","requirement_id":r["id"],"method":"N/D","success_criterion":"N/D","status":"MISSING_VV","evidence":"N/D"})
    return rows

def _scope_risks(req, baseline):
    scope=req.get("scope",{}); rows=[]
    for r in baseline["risks"]:
        rid=r["id"]; applicability="ACTIVE"
        if rid=="R-003" and not scope.get("pressurized_or_cryogenic"): applicability="DEFERRED"
        if rid=="R-005" and not scope.get("human_rated"): applicability="DEFERRED"
        if rid=="R-006" and not scope.get("ramp_trade_study"): applicability="DEFERRED"
        rows.append({**r,"applicability":applicability,"owner":"N/D","evidence":"N/D"})
    return rows

def _wbs_plan(req, baseline):
    scenario=req["scenario"]
    active_by_scenario={"S0":{"P0","P1"},"S1":{"P0","P1","P2","P3","P4","P5","P6"},"S2":{"P0","P1","P2","P3","P4","P5","P6"}}
    active=active_by_scenario[scenario]
    return [{**r,"instance_status":"ACTIVE" if r["phase"] in active else "DEFERRED","source_note":"V2 phase model; scenario total is tracked separately"} for r in baseline["wbs"]]

def _configuration_model(req):
    components=[{"id":"home-core","type":"logical_core","status":"continuous"}]
    for i in range(1,5): components.append({"id":f"stage-{i}","type":"logical_external_stage","status":"configured"})
    return {
        "model_kind":"configuration_only_non_physical",
        "request_id":req["request_id"],
        "components":components,
        "interfaces":[
            {"id":"IF-01","from":"home-core","to":"stage-*","kind":"abstract_boundary"},
            {"id":"IF-02","from":"stage-n","to":"stage-n+1","kind":"abstract_stage_interface"},
            {"id":"IF-03","from":"segment","to":"segment","kind":"abstract_segmentation_interface"},
            {"id":"IF-04","from":"peripheral-storage-placeholder","to":"structure","kind":"critical_placeholder"},
            {"id":"IF-05","from":"system","to":"ground-infrastructure-placeholder","kind":"optional_trade_placeholder"}],
        "state_machine":{"initial":"GROUND_SAFE","states":["GROUND_SAFE","INTEGRATED","DYNAMIC_PHASE_MODEL","STAGE_1_RELEASED_MODEL","STAGE_2_RELEASED_MODEL","STAGE_3_RELEASED_MODEL","STAGE_4_RELEASED_MODEL","HOME_ONLY_MODEL","RECOVERY_OR_END_MODEL"],"rule":"Transitions pilotées par préconditions booléennes simulées, autorisation, observation et état sûr de repli; aucun seuil physique."},
        "physical_parameters":None,
        "physical_parameters_status":"EXCLUDED_FROM_DIGITAL_LAYER"
    }

def _missing_data(req, vv_rows, budget):
    gaps=[]; constraints=req.get("constraints",{})
    for key in ("budget_eur_max","calendar_weeks_max","labor_hours_max"):
        if constraints.get(key) is None:
            gaps.append({"id":f"GAP-CONSTRAINT-{key.upper()}","category":"planning","field":key,"status":"MISSING","resolution":"Fournir une contrainte de planification ou accepter UNKNOWN."})
    for v in vv_rows:
        if v["status"]=="MISSING_VV":
            gaps.append({"id":f"GAP-VV-{v['requirement_id']}","category":"verification","field":v["requirement_id"],"status":"MISSING","resolution":"Définir une méthode et un critère de vérification non opérationnels."})
    if budget.get("uncertainty") is None:
        gaps.append({"id":"GAP-COST-DISTRIBUTION","category":"cost","field":"uncertainty_distribution","status":"MISSING","resolution":"Ajouter des distributions de coût sourcées pour ce scénario."})
    gaps.append({"id":"EXT-PHYSICAL-ENGINEERING","category":"boundary","field":"real_physical_dimensioning","status":"EXTERNAL_INPUT_REQUIRED","resolution":"À traiter hors de cette couche numérique par une équipe qualifiée si une phase physique autorisée est un jour ouverte."})
    return gaps

def _gate(scope,gaps,req_rows,vv_rows):
    if not scope["allowed"]: return "REJECT_SCOPE"
    missing_must={v["requirement_id"] for v in vv_rows if v["status"]=="MISSING_VV"}
    must_ids={r["id"] for r in req_rows if r["priority"]=="Must" and r["applicability"]=="APPLICABLE"}
    if missing_must & must_ids: return "ACCEPT_WITH_GAPS"
    return "ACCEPT_WITH_GAPS" if any(g["status"]=="MISSING" for g in gaps) else "ACCEPT"

def _summary_md(req,instance,budget,gaps,scope):
    reasons="\n".join(f"- {x}" for x in scope["reasons"]) or "- Aucun dépassement détecté."
    return (
        f"# Résumé d'instance — {req['title']}\n\n"
        f"- **Request ID** : `{req['request_id']}`\n"
        f"- **Instance ID** : `{instance['instance_id']}`\n"
        f"- **Scénario** : `{req['scenario']}`\n"
        f"- **Gate** : **{instance['gate']}**\n"
        f"- **Statut de périmètre** : `{scope['status']}`\n\n"
        f"## Objectif\n{req['objective']}\n\n"
        "## Frontière numérique\nCette instance transforme la demande en architecture de projet, exigences, risques, V&V, WBS, coût ROM, gaps et modèle de configuration. Elle ne produit aucun dimensionnement opérationnel de propulsion, guidage, profil de lancement ou récipient pressurisé prêt au vol.\n\n"
        f"## Contrôle de périmètre\n{reasons}\n\n"
        f"## Budget\n- Baseline ROM : `{budget['baseline'].get('rom_cost_eur')}` EUR\n- Contrainte budget : `{budget.get('constraint_budget_eur_max')}` EUR\n- Ajustement : `{budget.get('budget_fit')}`\n\n"
        f"## Données manquantes\n{len(gaps)} élément(s) dans `missing_data.json`. Les inconnues ne sont pas remplacées par des valeurs inventées.\n"
    )

def _hash_file(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()

def build_project(request, output_dir):
    errors=validate_request(request)
    if errors: raise ValueError("; ".join(errors))
    baseline=load_baseline(); scope=assess_scope(request); out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    req_rows=_scope_requirements(request,baseline)
    vv_rows=_scope_verification(req_rows,baseline)
    risk_rows=_scope_risks(request,baseline)
    wbs_rows=_wbs_plan(request,baseline)
    budget=build_budget(request,baseline)
    gaps=_missing_data(request,vv_rows,budget)
    gate=_gate(scope,gaps,req_rows,vv_rows)
    artifacts=[]
    def ej(name,data): write_json(out/name,data); artifacts.append(name)
    def ec(name,data): write_csv(out/name,data); artifacts.append(name)
    ec("requirement_matrix.csv",req_rows); ec("verification_plan.csv",vv_rows); ec("risk_register_scoped.csv",risk_rows); ec("wbs_plan.csv",wbs_rows)
    ej("budget_summary.json",budget); ej("missing_data.json",gaps); ej("configuration_model.json",_configuration_model(request))
    ej("traceability.json",{"request_id":request["request_id"],"baseline_sources":{"requirements":"06_MODELES_MACHINE/requirements.csv","risks":"06_MODELES_MACHINE/risk_register.csv","verification":"06_MODELES_MACHINE/verification_matrix.csv","wbs":"06_MODELES_MACHINE/wbs_cost_schedule.csv","cost_inputs":"06_MODELES_MACHINE/cost_monte_carlo_inputs.json","architecture":"06_MODELES_MACHINE/architecture_v1.json"},"rules":["No invented flight parameters","Unknowns remain explicit","Operational capabilities rejected"]})
    instance={"instance_id":f"{request['request_id']}-V3","request_id":request["request_id"],"title":request["title"],"scenario":request["scenario"],"gate":gate,"scope_status":scope["status"],"scope_assessment":scope,"requirements":{"total":len(req_rows),"applicable":sum(r["applicability"]=="APPLICABLE" for r in req_rows)},"risks":{"total":len(risk_rows),"active":sum(r["applicability"]=="ACTIVE" for r in risk_rows)},"gaps":len(gaps),"artifacts":[]}
    (out/"EXECUTIVE_SUMMARY.md").write_text(_summary_md(request,instance,budget,gaps,scope),encoding="utf-8"); artifacts.append("EXECUTIVE_SUMMARY.md")
    instance["artifacts"]=sorted(artifacts+["project_instance.json","manifest.sha256.json"])
    write_json(out/"project_instance.json",instance)
    manifest={name:_hash_file(out/name) for name in sorted(artifacts+["project_instance.json"])}
    write_json(out/"manifest.sha256.json",manifest)
    return instance
