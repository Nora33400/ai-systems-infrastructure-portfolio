REQUIRED_TOP=("request_id","title","objective","scenario","scope","desired_outputs","constraints")
VALID_SCENARIOS={"S0","S1","S2"}

def validate_request(req):
    errors=[]
    for key in REQUIRED_TOP:
        if key not in req: errors.append(f"champ obligatoire absent: {key}")
    if req.get("scenario") not in VALID_SCENARIOS: errors.append("scenario doit être S0, S1 ou S2")
    scope=req.get("scope") or {}
    for key in ("digital_only","physical_build","flight_intent","requested_capabilities"):
        if key not in scope: errors.append(f"scope.{key} absent")
    if not isinstance(req.get("desired_outputs",[]),list) or not req.get("desired_outputs"):
        errors.append("desired_outputs doit contenir au moins un livrable")
    constraints=req.get("constraints") or {}
    for key in ("budget_eur_max","calendar_weeks_max","labor_hours_max"):
        if key not in constraints: errors.append(f"constraints.{key} absent")
        elif constraints.get(key) is not None and constraints.get(key)<0: errors.append(f"constraints.{key} doit être positif ou null")
    return errors
