import random

def _f(row,key):
    try: return float(row.get(key,0) or 0)
    except (TypeError,ValueError): return 0.0

def scenario_baseline(baseline,scenario):
    row=next((x for x in baseline["scenarios"] if x["id"]==scenario),None)
    if not row: return {"scenario":scenario,"labor_hours":None,"rom_cost_eur":None,"duration_months":None}
    return {"scenario":scenario,"labor_hours":_f(row,"labor_hours") or None,"rom_cost_eur":_f(row,"rom_cost_eur") or None,"duration_months":_f(row,"duration_months") or None,"scope":row.get("scope")}

def monte_carlo(inputs,draws=20000,seed=260819):
    rnd=random.Random(seed); samples=[]; keys=sorted(inputs)
    for _ in range(draws):
        total=0.0
        for key in keys:
            low,mode,high=[float(x) for x in inputs[key]]
            total += rnd.triangular(low,high,mode)
        samples.append(total)
    samples.sort()
    def q(p):
        i=min(len(samples)-1,max(0,round((len(samples)-1)*p)))
        return round(samples[i],2)
    return {"method":"triangular_sum","draws":draws,"seed":seed,"P10_eur":q(.10),"P50_eur":q(.50),"P80_eur":q(.80),"P90_eur":q(.90),"mean_eur":round(sum(samples)/len(samples),2)}

def build_budget(request,baseline):
    scenario=scenario_baseline(baseline,request["scenario"])
    constraints=request.get("constraints",{}); overrides=request.get("planning_overrides",{}) or {}
    out={"baseline":scenario,"constraint_budget_eur_max":constraints.get("budget_eur_max")}
    if request["scenario"]=="S1": out["uncertainty"]=monte_carlo(baseline["mc_inputs"])
    else:
        out["uncertainty"]=None
        out["uncertainty_reason"]="Aucune distribution source spécifique à ce scénario dans la V2."
    rate=overrides.get("loaded_rate_eur_h"); non_labor=overrides.get("non_labor_cost_eur"); reserve=overrides.get("planning_reserve_fraction")
    if any(v is not None for v in (rate,non_labor,reserve)):
        hours=scenario.get("labor_hours")
        if hours is not None and rate is not None:
            labor=hours*float(rate); nl=float(non_labor or 0); r=float(reserve or 0)
            out["override_model"]={"labor_hours":hours,"loaded_rate_eur_h":float(rate),"labor_cost_eur":round(labor,2),"non_labor_cost_eur":nl,"planning_reserve_fraction":r,"planned_total_eur":round((labor+nl)*(1+r),2),"status":"USER_PLANNING_ASSUMPTION"}
        else: out["override_model"]={"status":"INCOMPLETE","reason":"hours et loaded_rate_eur_h requis pour recalculer"}
    budget_max=constraints.get("budget_eur_max"); rom=scenario.get("rom_cost_eur")
    if budget_max is None or rom is None: out["budget_fit"]="UNKNOWN"
    else:
        out["budget_fit"]="WITHIN_BASELINE_ROM" if rom<=budget_max else "ABOVE_BASELINE_ROM"
        out["budget_gap_eur"]=round(float(budget_max)-float(rom),2)
    return out
