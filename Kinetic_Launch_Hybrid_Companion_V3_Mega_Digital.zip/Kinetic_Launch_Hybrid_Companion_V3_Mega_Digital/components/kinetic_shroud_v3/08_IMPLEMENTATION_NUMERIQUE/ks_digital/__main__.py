import argparse, json
from .io import read_json
from .engine import build_project

def main(argv=None):
    p=argparse.ArgumentParser(prog="ks_digital",description="Kinetic-Shroud V3 digital project builder")
    sub=p.add_subparsers(dest="cmd",required=True)
    b=sub.add_parser("build"); b.add_argument("request"); b.add_argument("--out",required=True)
    args=p.parse_args(argv)
    try:
        result=build_project(read_json(args.request),args.out)
    except Exception as e:
        print(json.dumps({"ok":False,"error":str(e)},ensure_ascii=False,indent=2)); return 2
    print(json.dumps({"ok":True,"result":result},ensure_ascii=False,indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())
