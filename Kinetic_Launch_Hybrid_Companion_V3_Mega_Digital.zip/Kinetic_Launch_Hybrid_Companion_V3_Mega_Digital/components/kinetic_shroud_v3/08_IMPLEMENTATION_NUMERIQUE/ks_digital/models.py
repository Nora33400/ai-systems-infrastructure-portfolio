from pathlib import Path
from .io import read_csv, read_json

def repo_root():
    return Path(__file__).resolve().parents[2]

def load_baseline():
    machine=repo_root()/"06_MODELES_MACHINE"
    return {
        "architecture": read_json(machine/"architecture_v1.json"),
        "requirements": read_csv(machine/"requirements.csv"),
        "assumptions": read_csv(machine/"assumptions.csv"),
        "wbs": read_csv(machine/"wbs_cost_schedule.csv"),
        "risks": read_csv(machine/"risk_register.csv"),
        "verification": read_csv(machine/"verification_matrix.csv"),
        "scenarios": read_csv(machine/"scenarios.csv"),
        "mc_inputs": read_json(machine/"cost_monte_carlo_inputs.json"),
        "trl": read_csv(machine/"trl.csv"),
    }
