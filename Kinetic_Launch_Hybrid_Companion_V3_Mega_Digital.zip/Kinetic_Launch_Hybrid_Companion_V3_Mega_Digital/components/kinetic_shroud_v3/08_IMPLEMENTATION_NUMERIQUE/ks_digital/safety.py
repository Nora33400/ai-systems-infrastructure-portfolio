BLOCKED_CAPABILITIES={
    "operational_propulsion","propellant_formulation","launch_guidance","launch_profile",
    "ramp_exit_sizing","flight_ready_pressure_vessel_sizing","weaponization"
}
TEXT_PATTERNS=(
    "propellant formulation","formulation d'ergol","launch guidance","guidage de lancement",
    "profil de tir","ramp exit velocity","vitesse de sortie de rampe","ramp exit angle","angle de sortie de rampe"
)

def assess_scope(request):
    scope=request.get("scope",{})
    caps=set(scope.get("requested_capabilities",[]))
    blocked=sorted(caps & BLOCKED_CAPABILITIES)
    reasons=[]
    if scope.get("digital_only") is not True: reasons.append("digital_only doit être true")
    if scope.get("physical_build"): reasons.append("la V3 ne produit pas d'instructions de fabrication physique")
    if scope.get("flight_intent"): reasons.append("la V3 ne dimensionne pas un système destiné au vol")
    if blocked: reasons.append("capacités hors frontière: "+", ".join(blocked))
    text=(request.get("objective","")+" "+request.get("notes","")).lower()
    hits=[p for p in TEXT_PATTERNS if p in text]
    if hits: reasons.append("texte contenant des paramètres opérationnels interdits: "+", ".join(hits))
    return {"allowed":not reasons,"status":"DIGITAL_SCOPE_OK" if not reasons else "OUT_OF_SCOPE","blocked_capabilities":blocked,"reasons":reasons}
