# Contrat de demande concrète

Une demande exploitable contient un identifiant, un titre, un objectif, un scénario `S0/S1/S2`, `digital_only: true`, les livrables et les contraintes connues. Les inconnues restent `null` : le moteur ne crée pas de valeurs physiques absentes.

- `S0` : faisabilité documentaire et numérique.
- `S1` : préparation programme d'un démonstrateur mécanique non-vol.
- `S2` : préparation programme d'un article structurel intégré au sol, toujours sans paramètres opérationnels de propulsion.
