# Guide d'intégration

## Bibliothèque
```python
from adapters.aione_adapter import handle_request
result = handle_request(payload, output_dir="build/job-001")
```

## CLI
```bash
python -m ks_digital build request.json --out build/request-id
```

Le manifeste `project.plugin.json` permet à un orchestrateur AIONE/Codex de sélectionner ce projet pour architecture système, faisabilité numérique, WBS, coût ROM, risques, V&V et traçabilité.

Cycle : `demande -> validation -> scoping -> génération -> revue des gaps -> décision -> enrichissement -> nouvelle génération`.
