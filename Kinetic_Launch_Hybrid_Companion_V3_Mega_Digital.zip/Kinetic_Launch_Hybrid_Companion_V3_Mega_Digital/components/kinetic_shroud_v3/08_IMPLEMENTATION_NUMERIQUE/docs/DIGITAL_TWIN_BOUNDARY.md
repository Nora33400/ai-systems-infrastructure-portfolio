# Frontière du modèle numérique

Le modèle est un **jumeau de configuration et de projet**, pas un jumeau physique prédictif. Il représente composants logiques, interfaces, états, exigences, risques, preuves attendues, coûts ROM, décisions et gaps.

Il ne génère pas de poussée/impulsion, formulation d'ergols, lois de guidage, profil de lancement, vitesse/angle de sortie de rampe, ni dimensionnement de récipient pressurisé prêt au vol. Une demande de ce type reçoit `REJECT_SCOPE`.
