# Critères d'acceptation

1. Une demande S0/S1/S2 valide produit un dossier projet complet.
2. Chaque exigence Must applicable a une V&V ou un gap explicite.
3. Les coûts donnent une plage d'incertitude quand des distributions sources existent, sinon un motif explicite.
4. Les données inconnues restent inconnues et sont recensées.
5. Les capacités opérationnelles interdites passent à `REJECT_SCOPE`.
6. Aucun paramètre opérationnel de propulsion/guidage/profil de lancement n'est ajouté par le moteur.
7. Chaque artefact généré est hashé.
