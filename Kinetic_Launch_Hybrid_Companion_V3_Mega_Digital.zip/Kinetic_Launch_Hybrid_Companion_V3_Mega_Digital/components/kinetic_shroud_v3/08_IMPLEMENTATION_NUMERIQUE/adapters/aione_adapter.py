"""Adaptateur minimal pour AIONE/Codex ou tout orchestrateur Python."""
from pathlib import Path
import sys
_IMPL=Path(__file__).resolve().parents[1]
if str(_IMPL) not in sys.path: sys.path.insert(0,str(_IMPL))
from ks_digital.engine import build_project

def handle_request(payload:dict, output_dir:str)->dict:
    return build_project(payload,output_dir)
