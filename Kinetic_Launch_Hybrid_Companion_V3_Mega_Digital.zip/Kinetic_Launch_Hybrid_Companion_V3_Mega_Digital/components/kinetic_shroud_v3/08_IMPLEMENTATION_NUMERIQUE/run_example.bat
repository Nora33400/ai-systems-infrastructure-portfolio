@echo off
setlocal
cd /d %~dp0
python -m ks_digital build examples\request_nonflight_concrete.json --out build\example
if errorlevel 1 exit /b %errorlevel%
python -m unittest discover -s tests -v
