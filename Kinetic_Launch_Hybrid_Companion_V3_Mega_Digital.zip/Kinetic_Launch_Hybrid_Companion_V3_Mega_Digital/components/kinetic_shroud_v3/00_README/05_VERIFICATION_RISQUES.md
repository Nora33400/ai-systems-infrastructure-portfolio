# Kinetic-Shroud — dossier documentaire V1 — vérification, risques et critères

## Méthodes
- revue documentaire
- cohérence croisée
- contrôle liens
- versioning
- validation par gate

## Points issus de la source
- Vérifier : les éléments réellement présents dans la source utilisateur ;
- Vérifier : les corrections physiques nécessaires ;
- Vérifier : les hypothèses de chiffrage ;
- Vérifier : les résultats calculés ;
- Vérifier : les inconnues qui empêchent un dimensionnement de vol.
- Vérifier : Référence Falcon 9 : élancement H/D calculé = **18.919** ; fraction charge LEO / masse au décollage = **4.153%**.
- Vérifier : Référence Falcon Heavy : fraction charge LEO / masse au décollage = **4.490%**.
- Vérifier : Référence Starship : élancement H/D calculé = **13.778**.
- Vérifier : Scénario S1 démonstrateur mécanique non-vol : **29,850 h** de travail planifiées ; coût déterministe avec réserve de 30 % = **6.787 M€**.
- Vérifier : Monte-Carlo S1 (hypothèses documentées) : P50 **5.581 M€**, P80 **5.881 M€**, P90 **6.035 M€**.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
