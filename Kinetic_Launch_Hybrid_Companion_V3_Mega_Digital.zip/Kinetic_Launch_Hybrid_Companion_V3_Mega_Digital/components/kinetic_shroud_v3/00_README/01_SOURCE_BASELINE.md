# Kinetic-Shroud — dossier documentaire V1

**Version :** 1.0 — 2026-08-19  
**Objet :** dossier documentaire paramétrique et traçable de l'architecture envisagée.

Ce ZIP transforme le matériau de discussion en un dossier d'ingénierie préliminaire. Il ne prétend pas qu'un véhicule est faisable. Il sépare explicitement :

1. les éléments réellement présents dans la source utilisateur ;
2. les corrections physiques nécessaires ;
3. les hypothèses de chiffrage ;
4. les résultats calculés ;
5. les inconnues qui empêchent un dimensionnement de vol.

## Résultats chiffrés principaux

- Référence Falcon 9 : élancement H/D calculé = **18.919** ; fraction charge LEO / masse au décollage = **4.153%**.
- Référence Falcon Heavy : fraction charge LEO / masse au décollage = **4.490%**.
- Référence Starship : élancement H/D calculé = **13.778**.
- Scénario S1 démonstrateur mécanique non-vol : **29,850 h** de travail planifiées ; coût déterministe avec réserve de 30 % = **6.787 M€**.
- Monte-Carlo S1 (hypothèses documentées) : P50 **5.581 M€**, P80 **5.881 M€**, P90 **6.035 M€**.
- Calendrier cible S1 avec chevauchements : **60 semaines** (~13.8 mois).

## Limite de sûreté

Le dossier reste au niveau architecture / programme / V&V / coût / risques. Il n'inclut pas de recette d'ergol, de géométrie de moteur, de calcul de poussée opérationnelle, de guidage de tir, de vitesse de sortie de rampe ou de procédure de lancement.

## Arborescence

- `01_ARCHITECTURE/` : baseline, décomposition, interfaces, ConOps, données.
- `02_CALCULS/` : calculs de références, coût, durée, charge de travail, modèles.
- `03_PROGRAMME/` : WBS, calendrier, assemblage, fabrication, décisions.
- `04_VERIFICATION_SECURITE/` : exigences, V&V, risques, FMEA, TRL, facteurs humains.
- `05_NORMES_SOURCES/` : normes, références publiques, traçabilité.
- `06_MODELES_MACHINE/` : JSON/CSV réutilisables par une IA ou un tableur.
- `SOURCE/` : copie de la source utilisateur.
