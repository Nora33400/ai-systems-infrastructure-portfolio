# Kinetic-Shroud — dossier documentaire V1 — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **documentation de soutien, décision, glossaire et traçabilité**.

## Structure détectée
- Niveau 1: **Kinetic-Shroud — dossier documentaire V1**
- Niveau 2: **Résultats chiffrés principaux**
- Niveau 2: **Limite de sûreté**
- Niveau 2: **Arborescence**

## Énoncés de baseline extraits
- les éléments réellement présents dans la source utilisateur ;
- les corrections physiques nécessaires ;
- les hypothèses de chiffrage ;
- les résultats calculés ;
- les inconnues qui empêchent un dimensionnement de vol.
- Référence Falcon 9 : élancement H/D calculé = **18.919** ; fraction charge LEO / masse au décollage = **4.153%**.
- Référence Falcon Heavy : fraction charge LEO / masse au décollage = **4.490%**.
- Référence Starship : élancement H/D calculé = **13.778**.
- Scénario S1 démonstrateur mécanique non-vol : **29,850 h** de travail planifiées ; coût déterministe avec réserve de 30 % = **6.787 M€**.
- Monte-Carlo S1 (hypothèses documentées) : P50 **5.581 M€**, P80 **5.881 M€**, P90 **6.035 M€**.
- Calendrier cible S1 avec chevauchements : **60 semaines** (~13.8 mois).
- `01_ARCHITECTURE/` : baseline, décomposition, interfaces, ConOps, données.
- `02_CALCULS/` : calculs de références, coût, durée, charge de travail, modèles.
- `03_PROGRAMME/` : WBS, calendrier, assemblage, fabrication, décisions.
- `04_VERIFICATION_SECURITE/` : exigences, V&V, risques, FMEA, TRL, facteurs humains.
- `05_NORMES_SOURCES/` : normes, références publiques, traçabilité.
- `06_MODELES_MACHINE/` : JSON/CSV réutilisables par une IA ou un tableur.
- `SOURCE/` : copie de la source utilisateur.

## Axes à documenter
- objectif
- contenu
- dépendances
- utilisateur cible
- données
- mise à jour

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
