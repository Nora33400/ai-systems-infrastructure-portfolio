# Kinetic-Shroud — dossier documentaire V1 — dossier développé

**Ancien document :** `00_README.md`  
**Catégorie :** `ROOT`  
**Version :** V2 Expanded  
**Hash source :** `403059940590819cd2949c73e639baf30f8fd0b515fb3289fb8921f34a133090`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
