# Kinetic-Shroud — dossier documentaire V1 — traçabilité

## Origine
- Ancien chemin V1 : `00_README.md`
- SHA-256 V1 : `403059940590819cd2949c73e639baf30f8fd0b515fb3289fb8921f34a133090`
- Catégorie : `ROOT`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
