# Kinetic-Shroud — dossier documentaire V1 — données et calculs

## Valeurs numériques détectées
- `1.0`
- `2026`
- `08`
- `19`
- `1.`
- `2.`
- `3.`
- `4.`
- `5.`
- `18.919`
- `4.153%`
- `4.490%`
- `13.778`
- `29,850 h`
- `30 %`
- `6.787 M`
- `5.581 M`
- `5.881 M`
- `6.035 M`
- `60 semaines`
- `13.8 m`
- `01`
- `02`
- `03`
- `04`
- `05`
- `06`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Discipline de calcul
Pour chaque grandeur : symbole, unité SI, valeur, source, date, incertitude et statut.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
