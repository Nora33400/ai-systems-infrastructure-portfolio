# V3 — données à intégrer ensuite

Pour aller au-delà du documentaire :
- CAO/dimensions ;
- BOM ;
- masses par pièce ;
- devis fournisseurs ;
- temps d'usinage ;
- temps d'assemblage ;
- résultats de simulation ;
- résultats d'essais ;
- exigences de mission ;
- cadre de site et conformité.

Ces données permettront de remplacer progressivement les champs N/D et les ROM par des calculs industriels sourcés.

## Réalisé dans la V3 numérique

- contrat de demande machine-readable ;
- moteur d'instanciation ;
- scoping exigences/risques/V&V ;
- génération WBS et coût ROM ;
- modèle de configuration abstrait ;
- liste de gaps et données externes requises ;
- adaptateur d'intégration et tests automatisés.

Les éléments CAO/BOM/masses/devis/essais physiques restent hors de cette implémentation tant qu'ils ne proviennent pas de données réelles, autorisées et qualifiées.
