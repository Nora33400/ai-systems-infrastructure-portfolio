# Kinetic-Shroud — Documentation V2 Expanded

- Anciens `.md` transformés : **46**
- Documents `.md` générés dans les dossiers : **368**
- Chaque ancien Markdown est devenu un dossier du même nom sans extension.
- Les CSV/JSON V1 sont conservés.

Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.

## Extension V3 numérique

Le dossier `08_IMPLEMENTATION_NUMERIQUE/` ajoute une couche exécutable capable de transformer une demande concrète en instance projet numérique avec traçabilité, exigences, risques, V&V, WBS, budget ROM, gaps et manifeste d'intégrité.
