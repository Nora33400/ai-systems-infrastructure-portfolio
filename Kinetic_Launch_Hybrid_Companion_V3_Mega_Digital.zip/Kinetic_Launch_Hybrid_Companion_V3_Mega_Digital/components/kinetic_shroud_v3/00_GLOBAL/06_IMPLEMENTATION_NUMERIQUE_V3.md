# V3 — implémentation numérique ajoutée

La V2 documentaire est complétée par `08_IMPLEMENTATION_NUMERIQUE/`.

Cette couche reçoit une demande JSON concrète et produit une instance projet traçable : exigences, V&V, risques, WBS, budget ROM, gaps, configuration abstraite, décision de gate et manifeste d'intégrité.

Le périmètre reste **numérique et non opérationnel**. Les demandes de propulsion opérationnelle, formulation d'ergols, guidage/profil de lancement, dimensionnement de sortie de rampe, dimensionnement de récipient pressurisé prêt au vol ou militarisation sont rejetées par le moteur de scope.

```bash
cd 08_IMPLEMENTATION_NUMERIQUE
python -m ks_digital build examples/request_nonflight_concrete.json --out build/example
```
