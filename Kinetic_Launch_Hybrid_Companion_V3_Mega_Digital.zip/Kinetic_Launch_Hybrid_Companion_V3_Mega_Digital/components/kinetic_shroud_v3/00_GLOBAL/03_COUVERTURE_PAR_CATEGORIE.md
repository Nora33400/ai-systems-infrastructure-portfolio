# Couverture par catégorie

- **01_ARCHITECTURE** : 8 anciens `.md` → 64 documents V2
- **02_CALCULS** : 8 anciens `.md` → 64 documents V2
- **03_PROGRAMME** : 8 anciens `.md` → 64 documents V2
- **04_VERIFICATION_SECURITE** : 8 anciens `.md` → 64 documents V2
- **05_NORMES_SOURCES** : 5 anciens `.md` → 40 documents V2
- **07_ANNEXES** : 7 anciens `.md` → 56 documents V2
- **ROOT** : 1 anciens `.md` → 8 documents V2
- **SOURCE** : 1 anciens `.md` → 8 documents V2
