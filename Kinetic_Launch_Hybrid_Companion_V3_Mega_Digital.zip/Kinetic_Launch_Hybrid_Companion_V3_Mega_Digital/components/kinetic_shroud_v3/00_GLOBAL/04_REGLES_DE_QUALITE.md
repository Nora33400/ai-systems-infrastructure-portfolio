# Règles de qualité documentaire V2

1. Aucun nombre non sourcé comme donnée réelle.
2. Chaque calcul indique unités et statut des entrées.
3. Chaque hypothèse doit pouvoir être invalidée.
4. Chaque exigence critique est reliée à une vérification.
5. Chaque sous-système a owner et WBS.
6. Les coûts publient incertitude et base monétaire.
7. Les variantes restent séparées de la baseline.
8. Les systèmes pressurisés/cryogéniques/propulsifs ont une branche dédiée.
9. Pas de généralisation au vol sans environnement représentatif.
10. Toute modification est versionnée et traçable.
