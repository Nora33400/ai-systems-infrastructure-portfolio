# source utilisateur original — traçabilité

## Origine
- Ancien chemin V1 : `SOURCE/source_utilisateur_original.md`
- SHA-256 V1 : `5465ec167a5ca1acf9e32ffe2fa40f24dc91028224fb2a2d6bf35b0ca1f16942`
- Catégorie : `SOURCE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
