# source utilisateur original — données et calculs

## Valeurs numériques détectées
- `15`
- `08`
- `1.105 g`
- `3.8`
- `99`
- `13366`
- `100m`
- `213124.h`
- `10584321`
- `20.03 g`
- `25`
- `3.82`
- `101.42`
- `8423919`
- `46`
- `89978449`
- `1787231951882000`
- `99,9%`
- `1.13366`
- `-100M`
- `99,8`
- `24,45 EUR`
- `09`
- `450`
- `17405888613737472.h`
- `15 ans`
- `85`
- `26`
- `6415`
- `902312`
- `10249096`
- `14`
- `21`
- `9269`
- `1228115`
- `10373794`
- `12`
- `1.`
- `2.`
- `3.`
- `1 15`
- `42359210`
- `248`
- `25057`
- `263320399`
- `64`
- `11`
- `7241`
- `426101`
- `0.4`
- `47`
- `16`
- `17`
- `1925`
- `2019,`
- `1114110`
- `18857`
- `1356`
- `27`
- `2004`
- `18`
- `19`
- `120`
- `1.2`
- `1787232086615000`
- `00`
- `3,`
- `1787232252066000`
- `80 %`
- `1787232630895000`
- `4.`
- `-160`
- `-183`
- `1787232706570000`
- `100%`
- `5.`
- `10 cm`
- `5 cm`
- `1787232767080000`
- `1,5G`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Discipline de calcul
Pour chaque grandeur : symbole, unité SI, valeur, source, date, incertitude et statut.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
