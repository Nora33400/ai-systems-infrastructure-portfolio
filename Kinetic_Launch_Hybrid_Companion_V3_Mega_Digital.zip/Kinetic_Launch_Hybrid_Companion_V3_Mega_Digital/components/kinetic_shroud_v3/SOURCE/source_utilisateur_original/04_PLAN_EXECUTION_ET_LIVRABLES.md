# source utilisateur original — plan d'exécution et livrables

## Séquence
1. Geler la source.
2. Extraire exigences, hypothèses et décisions.
3. Affecter IDs WBS/REQ/ICD/TEST.
4. Identifier les données manquantes.
5. Produire analyse ou maquette adaptée.
6. Réaliser une revue.
7. Enregistrer écarts et décisions.
8. Mettre à jour coût, planning, risques et configuration.

## Travaux dérivés
- Transformer **Vous avez dit : galvanisation au deuterium sur l'oxyde** en livrable versionné avec propriétaire, entrée et critère de sortie.
- Transformer **Vous avez dit : galvanisation légère avec électrolyse des "jsp comment s'apele mais prend" neutron ion acide phospho jspquoi et nitro jsp pas glycerine (je crois)** en livrable versionné avec propriétaire, entrée et critère de sortie.
- Transformer **Vous avez dit : phosphatation + électrozingage procédé double en 1** en livrable versionné avec propriétaire, entrée et critère de sortie.
- Transformer **Vous avez dit : nitriogen avec propylen glicol et amoniac ? ru tu ou te ou tf ? poc trial vial ?** en livrable versionné avec propriétaire, entrée et critère de sortie.
- Transformer **Vous avez dit : luminesance ?** en livrable versionné avec propriétaire, entrée et critère de sortie.
- Transformer **Vous avez dit : luminecance radio active (spectre visible -yeux))** en livrable versionné avec propriétaire, entrée et critère de sortie.
- Transformer **Vous avez dit : huelium hydroxide** en livrable versionné avec propriétaire, entrée et critère de sortie.

## Livrables minimaux
- note d'hypothèses ;
- tableau de données ;
- analyse ou modèle ;
- résultat reproductible ;
- liste d'écarts ;
- décision de gate ;
- mise à jour risques ;
- mise à jour V&V.

## Definition of Done
Une autre personne doit pouvoir reconstruire la conclusion à partir des entrées et de la méthode.
