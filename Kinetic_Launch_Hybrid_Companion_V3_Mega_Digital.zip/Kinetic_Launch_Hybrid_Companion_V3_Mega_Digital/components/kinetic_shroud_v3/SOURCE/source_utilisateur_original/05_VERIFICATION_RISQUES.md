# source utilisateur original — vérification, risques et critères

## Méthodes
- source primaire
- version contrôlée
- revue d'applicabilité
- matrice de conformité
- historique des changements

## Points issus de la source
- Vérifier : **Formula:** D₂O
- Vérifier : **Molar mass:** 20.03 g/mol
- Vérifier : **Density:** 1.105 g/mL at 25 °C
- Vérifier : **Melting point:** 3.82 °C
- Vérifier : **Boiling point:** 101.42 °C [[1](https://www.fishersci.fr/shop/products/deuterium-oxide-nmr-99-8-atom-d-thermo-scientific/10584321), [2](https://www.atamanchemicals.com/deuterium-oxide_u26031/?lang=FR), [3](https://vitrinelinguistique.oqlf.gouv.qc.ca/fiche-gdt/fiche/8423919/oxyde-de-deuterium)]
- Vérifier : **Nuclear reactors:** Acts as a neutron moderator to slow down neutrons without absorbing them, enabling natural uranium reactors to maintain a fission chain reaction. [[1](https://vitrinelinguistique.oqlf.gouv.qc.ca/fiche-gdt/fiche/8423919/oxyde-de-deuterium)]
- Vérifier : **Spectroscopy:** Used as a non-protonic solvent in [**Nuclear Magnetic Resonance (NMR) spectroscopy**](https://www.google.com/url?sa=i\&source=web\&rct=j\&url=https://www.humeau.com/deuterium-oxide-99-9-d-magnisolv-merck-1-13366-100ml-213124.html?srsltid%3DAfmBOoq49TUvnaXGvq20ULLnBbmvPhj3hza_W1aQOPquchL5dYi9i_KE\&ved=2ahUKEwig0qD-46yWAxX9KvsDHdjnM6EQy_kOegkIAggBCNMCEAc\&opi=89978449\&cd\&psig=AOvVaw3TtuQhY1XB_m9A1YMfBnY-\&ust=1787231951882000) to prevent hydrogen signals from masking the sample data. [[1](https://www.humeau.com/deuterium-oxide-99-9-d-magnisolv-merck-1-13366-100ml-213124.html)]
- Vérifier : **Tracer studies:** Utilized in biochemical and medical research to track metabolic processes and water dynamics in living organisms.
- Vérifier : Laboratoires Humeau
- Vérifier : Fisher Scientific SAS

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
