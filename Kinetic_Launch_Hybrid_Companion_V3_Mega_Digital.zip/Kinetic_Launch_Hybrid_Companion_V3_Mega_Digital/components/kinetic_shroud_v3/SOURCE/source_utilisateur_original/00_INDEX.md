# source utilisateur original — dossier développé

**Ancien document :** `SOURCE/source_utilisateur_original.md`  
**Catégorie :** `SOURCE`  
**Version :** V2 Expanded  
**Hash source :** `5465ec167a5ca1acf9e32ffe2fa40f24dc91028224fb2a2d6bf35b0ca1f16942`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
