# Concept of Operations (ConOps) préliminaire — vérification, risques et critères

## Méthodes
- revue d'architecture
- modèle d'interfaces
- analyse d'interférences
- maquette basse énergie
- traçabilité exigence→fonction

## Points issus de la source
- Vérifier : **Configuration au sol** : noyau + quatre étages externes assemblés et instrumentés.
- Vérifier : **Vérification avant opération** : configuration, continuité structurelle, état des interfaces, capteurs.
- Vérifier : **Phase dynamique** : l'humain n'effectue aucune opération critique sur fluides dangereux.
- Vérifier : **Transition d'étage** : ordre séquentiel logique; la V1 exige confirmation instrumentée et capacité à inhiber une transition.
- Vérifier : **Fin de mission / récupération** : fonctions séparées à définir selon mission réelle.
- Vérifier : **Maintenance** : prioritairement au sol; toute maintenance en vol doit être justifiée par analyse de risques dédiée.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
