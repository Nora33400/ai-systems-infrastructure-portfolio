# Concept of Operations (ConOps) préliminaire

1. **Configuration au sol** : noyau + quatre étages externes assemblés et instrumentés.
2. **Vérification avant opération** : configuration, continuité structurelle, état des interfaces, capteurs.
3. **Phase dynamique** : l'humain n'effectue aucune opération critique sur fluides dangereux.
4. **Transition d'étage** : ordre séquentiel logique; la V1 exige confirmation instrumentée et capacité à inhiber une transition.
5. **Fin de mission / récupération** : fonctions séparées à définir selon mission réelle.
6. **Maintenance** : prioritairement au sol; toute maintenance en vol doit être justifiée par analyse de risques dédiée.

Ce ConOps remplace les formulations « déclenchement parfaitement passif » et « trajectoire parfaite » par des états observables, vérifiables et sûrs.
