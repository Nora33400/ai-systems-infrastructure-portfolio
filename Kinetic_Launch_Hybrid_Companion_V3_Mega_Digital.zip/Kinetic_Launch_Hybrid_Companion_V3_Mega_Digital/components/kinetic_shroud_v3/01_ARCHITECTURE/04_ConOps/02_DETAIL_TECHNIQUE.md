# Concept of Operations (ConOps) préliminaire — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **structure système, fonctions, états, interfaces et contraintes**.

## Structure détectée
- Niveau 1: **Concept of Operations (ConOps) préliminaire**

## Énoncés de baseline extraits
- **Configuration au sol** : noyau + quatre étages externes assemblés et instrumentés.
- **Vérification avant opération** : configuration, continuité structurelle, état des interfaces, capteurs.
- **Phase dynamique** : l'humain n'effectue aucune opération critique sur fluides dangereux.
- **Transition d'étage** : ordre séquentiel logique; la V1 exige confirmation instrumentée et capacité à inhiber une transition.
- **Fin de mission / récupération** : fonctions séparées à définir selon mission réelle.
- **Maintenance** : prioritairement au sol; toute maintenance en vol doit être justifiée par analyse de risques dédiée.

## Axes à documenter
- frontière système
- interfaces physiques et logiques
- états/configurations
- entrées/sorties
- hypothèses de charge
- dépendances inter-sous-systèmes

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
