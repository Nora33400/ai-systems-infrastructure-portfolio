# Concept of Operations (ConOps) préliminaire — dossier développé

**Ancien document :** `01_ARCHITECTURE/04_ConOps.md`  
**Catégorie :** `01_ARCHITECTURE`  
**Version :** V2 Expanded  
**Hash source :** `7da96878b5569ce3fe63878c715c3fe54105926f1ba7bd32ee83f0ab43ee9cf4`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
