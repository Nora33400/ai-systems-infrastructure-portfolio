# Concept of Operations (ConOps) préliminaire — traçabilité

## Origine
- Ancien chemin V1 : `01_ARCHITECTURE/04_ConOps.md`
- SHA-256 V1 : `7da96878b5569ce3fe63878c715c3fe54105926f1ba7bd32ee83f0ab43ee9cf4`
- Catégorie : `01_ARCHITECTURE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
