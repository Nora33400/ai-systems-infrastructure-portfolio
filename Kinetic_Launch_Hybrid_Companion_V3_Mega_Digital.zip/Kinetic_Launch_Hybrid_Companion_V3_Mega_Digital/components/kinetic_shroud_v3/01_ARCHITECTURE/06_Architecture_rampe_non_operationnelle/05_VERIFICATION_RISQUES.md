# Rampe — analyse non opérationnelle — vérification, risques et critères

## Méthodes
- revue d'architecture
- modèle d'interfaces
- analyse d'interférences
- maquette basse énergie
- traçabilité exigence→fonction

## Points issus de la source
- Vérifier : accélérations admissibles pour la structure et l'équipage ;
- Vérifier : charges de courbure et vibrations ;
- Vérifier : interaction rail/véhicule ;
- Vérifier : chauffage aérodynamique et pression dynamique ;
- Vérifier : disponibilité énergétique du site ;
- Vérifier : coût génie civil / maintenance / sécurité ;
- Vérifier : réglementation du site et corridors de sécurité.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
