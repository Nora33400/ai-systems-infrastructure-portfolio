# Rampe — analyse non opérationnelle

L'assistance au lancement par rampe est conservée comme **option de recherche**, pas comme économie acquise.

### Questions à fermer avant tout crédit de performance
- accélérations admissibles pour la structure et l'équipage ;
- charges de courbure et vibrations ;
- interaction rail/véhicule ;
- chauffage aérodynamique et pression dynamique ;
- disponibilité énergétique du site ;
- coût génie civil / maintenance / sécurité ;
- réglementation du site et corridors de sécurité.

### Règle V1
Aucune longueur, vitesse de sortie, angle terminal ou profil de guidage de tir n'est fixé tant que la mission et les charges ne sont pas définies.
