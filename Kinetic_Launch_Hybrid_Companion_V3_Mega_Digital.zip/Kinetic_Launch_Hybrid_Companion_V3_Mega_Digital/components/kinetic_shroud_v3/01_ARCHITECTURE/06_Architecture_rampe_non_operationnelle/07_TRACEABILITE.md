# Rampe — analyse non opérationnelle — traçabilité

## Origine
- Ancien chemin V1 : `01_ARCHITECTURE/06_Architecture_rampe_non_operationnelle.md`
- SHA-256 V1 : `b05fbeb45db1a352f01f38614d9a422bbd590f6acb3e63e1b0205377ebda0ab6`
- Catégorie : `01_ARCHITECTURE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
