# Baseline architecture

## Configuration retenue depuis la source

- **Noyau central `Home`** : structure continue, distincte de l'exo-coque.
- **Exo-coque** : quatre étages horizontaux indépendants.
- **Segmentation** : chaque étage peut comporter plusieurs panneaux/segments latéraux.
- **Bonbonnes/réservoirs périphériques** : répartis autour du noyau, avec idée de transfert/repli avant séparation.
- **Transition** : séparation latérale séquentielle des parties externes.
- **Infrastructure optionnelle** : rampe d'assistance au lancement étudiée séparément.
- **Vaisseau interne** : nombre de niveaux `X` non fixé.

## Correction indispensable

L'architecture n'abolit ni la masse, ni les charges, ni l'aérodynamique, ni les pertes énergétiques. La formule « plus grand/plus lourd, ce n'est pas grave » est donc classée **hypothèse invalidée**. Une exo-coque plus large et/ou plus puissante doit elle-même supporter des charges supérieures et augmente sa propre masse.

## Baseline V1 sûre

La V1 documentaire considère la séparation et le repli uniquement comme des **fonctions à démontrer sur maquettes non propulsives**. Les interfaces avec fluides dangereux restent hors démonstrateur mécanique initial.
