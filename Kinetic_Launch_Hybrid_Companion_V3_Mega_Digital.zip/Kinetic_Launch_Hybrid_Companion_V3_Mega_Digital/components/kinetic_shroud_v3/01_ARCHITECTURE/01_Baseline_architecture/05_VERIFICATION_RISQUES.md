# Baseline architecture — vérification, risques et critères

## Méthodes
- revue d'architecture
- modèle d'interfaces
- analyse d'interférences
- maquette basse énergie
- traçabilité exigence→fonction

## Points issus de la source
- Vérifier : **Noyau central `Home`** : structure continue, distincte de l'exo-coque.
- Vérifier : **Exo-coque** : quatre étages horizontaux indépendants.
- Vérifier : **Segmentation** : chaque étage peut comporter plusieurs panneaux/segments latéraux.
- Vérifier : **Bonbonnes/réservoirs périphériques** : répartis autour du noyau, avec idée de transfert/repli avant séparation.
- Vérifier : **Transition** : séparation latérale séquentielle des parties externes.
- Vérifier : **Infrastructure optionnelle** : rampe d'assistance au lancement étudiée séparément.
- Vérifier : **Vaisseau interne** : nombre de niveaux `X` non fixé.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
