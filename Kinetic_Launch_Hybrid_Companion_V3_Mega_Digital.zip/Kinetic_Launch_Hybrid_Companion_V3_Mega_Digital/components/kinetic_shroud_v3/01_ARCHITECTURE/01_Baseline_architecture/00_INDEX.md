# Baseline architecture — dossier développé

**Ancien document :** `01_ARCHITECTURE/01_Baseline_architecture.md`  
**Catégorie :** `01_ARCHITECTURE`  
**Version :** V2 Expanded  
**Hash source :** `5b47e4e4a0402ab8d3e580425fa8f537c0c9263abda4585e8604f3f7891fdc23`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
