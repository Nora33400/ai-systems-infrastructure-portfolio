# Baseline architecture — traçabilité

## Origine
- Ancien chemin V1 : `01_ARCHITECTURE/01_Baseline_architecture.md`
- SHA-256 V1 : `5b47e4e4a0402ab8d3e580425fa8f537c0c9263abda4585e8604f3f7891fdc23`
- Catégorie : `01_ARCHITECTURE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
