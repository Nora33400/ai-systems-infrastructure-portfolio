# Baseline architecture — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **structure système, fonctions, états, interfaces et contraintes**.

## Structure détectée
- Niveau 1: **Baseline architecture**
- Niveau 2: **Configuration retenue depuis la source**
- Niveau 2: **Correction indispensable**
- Niveau 2: **Baseline V1 sûre**

## Énoncés de baseline extraits
- **Noyau central `Home`** : structure continue, distincte de l'exo-coque.
- **Exo-coque** : quatre étages horizontaux indépendants.
- **Segmentation** : chaque étage peut comporter plusieurs panneaux/segments latéraux.
- **Bonbonnes/réservoirs périphériques** : répartis autour du noyau, avec idée de transfert/repli avant séparation.
- **Transition** : séparation latérale séquentielle des parties externes.
- **Infrastructure optionnelle** : rampe d'assistance au lancement étudiée séparément.
- **Vaisseau interne** : nombre de niveaux `X` non fixé.

## Axes à documenter
- frontière système
- interfaces physiques et logiques
- états/configurations
- entrées/sorties
- hypothèses de charge
- dépendances inter-sous-systèmes

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
