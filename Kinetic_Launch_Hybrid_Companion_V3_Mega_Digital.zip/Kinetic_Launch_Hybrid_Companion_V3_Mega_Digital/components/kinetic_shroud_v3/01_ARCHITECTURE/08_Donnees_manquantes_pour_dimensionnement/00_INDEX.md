# Données manquantes pour un dimensionnement de vol — dossier développé

**Ancien document :** `01_ARCHITECTURE/08_Donnees_manquantes_pour_dimensionnement.md`  
**Catégorie :** `01_ARCHITECTURE`  
**Version :** V2 Expanded  
**Hash source :** `552473401ce36ef022732e457e3aae38557c9d62a7325c273ea805973418f65c`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
