# Données manquantes pour un dimensionnement de vol

Un calcul de vol défendable exige au minimum :

- mission (LEO, GTO, lunaire, autre) ;
- charge utile et volume ;
- masse sèche du noyau ;
- architecture propulsive sélectionnée par équipe qualifiée ;
- enveloppes de charges ;
- dimensions et matériaux réellement choisis ;
- stratégie thermique ;
- stratégie de rentrée/récupération ;
- exigences habitabilité ;
- site et cadre réglementaire ;
- objectifs de réutilisation ;
- marges structurelles et fiabilité.

Sans ces données, toute « masse exacte », « prix exact du lanceur » ou « durée exacte de fabrication » serait une fausse précision.
