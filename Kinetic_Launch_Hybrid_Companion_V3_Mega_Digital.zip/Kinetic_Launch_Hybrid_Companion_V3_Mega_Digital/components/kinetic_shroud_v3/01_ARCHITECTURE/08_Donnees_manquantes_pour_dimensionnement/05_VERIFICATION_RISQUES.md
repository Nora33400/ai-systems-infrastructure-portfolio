# Données manquantes pour un dimensionnement de vol — vérification, risques et critères

## Méthodes
- revue d'architecture
- modèle d'interfaces
- analyse d'interférences
- maquette basse énergie
- traçabilité exigence→fonction

## Points issus de la source
- Vérifier : mission (LEO, GTO, lunaire, autre) ;
- Vérifier : charge utile et volume ;
- Vérifier : masse sèche du noyau ;
- Vérifier : architecture propulsive sélectionnée par équipe qualifiée ;
- Vérifier : enveloppes de charges ;
- Vérifier : dimensions et matériaux réellement choisis ;
- Vérifier : stratégie thermique ;
- Vérifier : stratégie de rentrée/récupération ;
- Vérifier : exigences habitabilité ;
- Vérifier : site et cadre réglementaire ;

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
