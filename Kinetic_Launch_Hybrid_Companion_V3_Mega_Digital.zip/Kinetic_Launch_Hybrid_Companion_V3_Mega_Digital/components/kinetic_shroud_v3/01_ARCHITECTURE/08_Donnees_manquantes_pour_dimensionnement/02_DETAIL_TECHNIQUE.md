# Données manquantes pour un dimensionnement de vol — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **structure système, fonctions, états, interfaces et contraintes**.

## Structure détectée
- Niveau 1: **Données manquantes pour un dimensionnement de vol**

## Énoncés de baseline extraits
- mission (LEO, GTO, lunaire, autre) ;
- charge utile et volume ;
- masse sèche du noyau ;
- architecture propulsive sélectionnée par équipe qualifiée ;
- enveloppes de charges ;
- dimensions et matériaux réellement choisis ;
- stratégie thermique ;
- stratégie de rentrée/récupération ;
- exigences habitabilité ;
- site et cadre réglementaire ;
- objectifs de réutilisation ;
- marges structurelles et fiabilité.

## Axes à documenter
- frontière système
- interfaces physiques et logiques
- états/configurations
- entrées/sorties
- hypothèses de charge
- dépendances inter-sous-systèmes

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
