# Données manquantes pour un dimensionnement de vol — traçabilité

## Origine
- Ancien chemin V1 : `01_ARCHITECTURE/08_Donnees_manquantes_pour_dimensionnement.md`
- SHA-256 V1 : `552473401ce36ef022732e457e3aae38557c9d62a7325c273ea805973418f65c`
- Catégorie : `01_ARCHITECTURE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
