# ICD préliminaire — interfaces — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **structure système, fonctions, états, interfaces et contraintes**.

## Structure détectée
- Niveau 1: **ICD préliminaire — interfaces**
- Niveau 3: **IF-01 Noyau ↔ exo-coque**
- Niveau 3: **IF-02 Étage externe ↔ étage externe**
- Niveau 3: **IF-03 Segment ↔ segment**
- Niveau 3: **IF-04 Réservoir périphérique ↔ structure**
- Niveau 3: **IF-05 Véhicule ↔ rampe**

## Énoncés de baseline extraits
- Les interfaces sont décrites sans dimensions de vol.

## Axes à documenter
- frontière système
- interfaces physiques et logiques
- états/configurations
- entrées/sorties
- hypothèses de charge
- dépendances inter-sous-systèmes

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
