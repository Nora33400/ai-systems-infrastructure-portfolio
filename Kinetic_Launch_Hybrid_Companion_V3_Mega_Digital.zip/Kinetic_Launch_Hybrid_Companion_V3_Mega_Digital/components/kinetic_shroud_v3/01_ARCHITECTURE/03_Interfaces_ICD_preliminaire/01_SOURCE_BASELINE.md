# ICD préliminaire — interfaces

Les interfaces sont décrites sans dimensions de vol.

### IF-01 Noyau ↔ exo-coque
Charges mécaniques, jeux, isolation vibratoire, chemins de charge, points de séparation, instrumentation.

### IF-02 Étage externe ↔ étage externe
Alignement, continuité aérodynamique, reprise de charge, état « attaché » / « isolé ».

### IF-03 Segment ↔ segment
Verrouillage, tolérances, détection de position, état sûr en cas de défaut simple.

### IF-04 Réservoir périphérique ↔ structure
Support mécanique, isolation, dilatation thermique, inspection. Toute connexion fluide réelle est une branche séparée certifiable.

### IF-05 Véhicule ↔ rampe
Traité comme interface GSE (Ground Support Equipment) : support, transport, instrumentation, sûreté de zone. Aucun paramètre de lancement n'est défini ici.
