# ICD préliminaire — interfaces — traçabilité

## Origine
- Ancien chemin V1 : `01_ARCHITECTURE/03_Interfaces_ICD_preliminaire.md`
- SHA-256 V1 : `17670c89f210cb4f40128e62727ac44fa9e5067ad99538edcfc2c174599190d6`
- Catégorie : `01_ARCHITECTURE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
