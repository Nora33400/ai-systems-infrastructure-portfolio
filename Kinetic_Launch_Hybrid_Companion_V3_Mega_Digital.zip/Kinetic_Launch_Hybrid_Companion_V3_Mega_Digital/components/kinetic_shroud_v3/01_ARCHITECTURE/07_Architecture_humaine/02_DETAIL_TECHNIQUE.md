# Architecture humaine — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **structure système, fonctions, états, interfaces et contraintes**.

## Structure détectée
- Niveau 1: **Architecture humaine**

## Énoncés de baseline extraits
- Sous fortes accélérations, mobilité, dextérité et perception se dégradent.
- Les interventions manuelles sur fluides cryogéniques/pressurisés pendant une phase dynamique ne sont pas retenues comme baseline.
- La compensation de masse par contrepoids est un sujet mécanique intéressant mais ne garantit pas à elle seule l'absence de couples, vibrations ou modes transitoires.
- Baseline recommandée : équipage passif pendant les phases dynamiques; maintenance après stabilisation ou au sol.

## Axes à documenter
- frontière système
- interfaces physiques et logiques
- états/configurations
- entrées/sorties
- hypothèses de charge
- dépendances inter-sous-systèmes

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
