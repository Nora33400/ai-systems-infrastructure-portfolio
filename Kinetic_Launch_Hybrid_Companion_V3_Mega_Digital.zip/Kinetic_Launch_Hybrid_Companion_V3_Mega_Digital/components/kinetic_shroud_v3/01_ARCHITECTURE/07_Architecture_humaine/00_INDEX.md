# Architecture humaine — dossier développé

**Ancien document :** `01_ARCHITECTURE/07_Architecture_humaine.md`  
**Catégorie :** `01_ARCHITECTURE`  
**Version :** V2 Expanded  
**Hash source :** `3b1fc08c2ae404b1967d682fb0f192dd79efdeb05cc1055df316e82381d51ba7`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
