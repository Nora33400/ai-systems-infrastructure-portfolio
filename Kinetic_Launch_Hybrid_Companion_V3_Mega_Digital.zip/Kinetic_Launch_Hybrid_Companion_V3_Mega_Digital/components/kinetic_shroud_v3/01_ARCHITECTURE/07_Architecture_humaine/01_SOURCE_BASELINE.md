# Architecture humaine

La source imagine un technicien mobile à bord. La V1 documentaire classe cette idée comme **option à haut risque**.

- Sous fortes accélérations, mobilité, dextérité et perception se dégradent.
- Les interventions manuelles sur fluides cryogéniques/pressurisés pendant une phase dynamique ne sont pas retenues comme baseline.
- La compensation de masse par contrepoids est un sujet mécanique intéressant mais ne garantit pas à elle seule l'absence de couples, vibrations ou modes transitoires.
- Baseline recommandée : équipage passif pendant les phases dynamiques; maintenance après stabilisation ou au sol.
