# Architecture humaine — vérification, risques et critères

## Méthodes
- revue d'architecture
- modèle d'interfaces
- analyse d'interférences
- maquette basse énergie
- traçabilité exigence→fonction

## Points issus de la source
- Vérifier : Sous fortes accélérations, mobilité, dextérité et perception se dégradent.
- Vérifier : Les interventions manuelles sur fluides cryogéniques/pressurisés pendant une phase dynamique ne sont pas retenues comme baseline.
- Vérifier : La compensation de masse par contrepoids est un sujet mécanique intéressant mais ne garantit pas à elle seule l'absence de couples, vibrations ou modes transitoires.
- Vérifier : Baseline recommandée : équipage passif pendant les phases dynamiques; maintenance après stabilisation ou au sol.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
