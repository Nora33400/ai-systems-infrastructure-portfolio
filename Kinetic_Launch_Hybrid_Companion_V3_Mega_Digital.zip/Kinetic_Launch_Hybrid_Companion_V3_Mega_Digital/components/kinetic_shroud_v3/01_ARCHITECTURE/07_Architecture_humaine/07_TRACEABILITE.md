# Architecture humaine — traçabilité

## Origine
- Ancien chemin V1 : `01_ARCHITECTURE/07_Architecture_humaine.md`
- SHA-256 V1 : `3b1fc08c2ae404b1967d682fb0f192dd79efdeb05cc1055df316e82381d51ba7`
- Catégorie : `01_ARCHITECTURE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
