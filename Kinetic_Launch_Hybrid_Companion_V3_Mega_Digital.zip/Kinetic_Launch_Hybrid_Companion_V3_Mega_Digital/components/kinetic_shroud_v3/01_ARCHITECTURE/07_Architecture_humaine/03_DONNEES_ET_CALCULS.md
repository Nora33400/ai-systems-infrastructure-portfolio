# Architecture humaine — données et calculs

## Valeurs numériques détectées
- Aucun paramètre numérique exploitable détecté automatiquement.

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Modèles génériques utiles
- Surface cylindrique idéale : `A = π D H`
- Centre de masse : `r_CM = Σ(m_i r_i) / Σ(m_i)`
- Un calcul de masse exige dimensions, épaisseurs, densités, rebut et marges sourcés.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
