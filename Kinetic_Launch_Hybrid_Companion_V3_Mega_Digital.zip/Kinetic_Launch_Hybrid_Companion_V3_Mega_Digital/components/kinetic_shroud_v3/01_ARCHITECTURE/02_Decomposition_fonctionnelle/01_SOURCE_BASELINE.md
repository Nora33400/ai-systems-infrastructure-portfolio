# Décomposition fonctionnelle

| Fonction | Sous-fonction | État V1 |
|---|---|---|
| Transporter | Maintenir le noyau `Home` | Baseline |
| Porter | Supporter exo-coque et interfaces | À dimensionner |
| Segmenter | Décomposer chaque étage externe | Baseline configurable |
| Séparer | Libérer latéralement un étage | PoC mécanique requis |
| Stocker | Réservoirs périphériques | Hypothèse critique |
| Transférer | Déplacer/reconfigurer les réservoirs | Hypothèse critique |
| Protéger | Isolation thermique/mécanique du noyau | Trade study |
| Guider | Avionique / navigation | Hors détail dans ce dossier |
| Assister au sol | Rampe / infrastructure | Option indépendante |
| Maintenir | Inspection / maintenance | Baseline au sol; humain en vol non retenu V1 |
