# Décomposition fonctionnelle — traçabilité

## Origine
- Ancien chemin V1 : `01_ARCHITECTURE/02_Decomposition_fonctionnelle.md`
- SHA-256 V1 : `cbca8818abc856f40f4a5fbfa1c20f93de31678fc723bd35482f5c905e011721`
- Catégorie : `01_ARCHITECTURE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
