# Décomposition fonctionnelle — dossier développé

**Ancien document :** `01_ARCHITECTURE/02_Decomposition_fonctionnelle.md`  
**Catégorie :** `01_ARCHITECTURE`  
**Version :** V2 Expanded  
**Hash source :** `cbca8818abc856f40f4a5fbfa1c20f93de31678fc723bd35482f5c905e011721`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
