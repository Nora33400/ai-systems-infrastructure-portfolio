# Décomposition fonctionnelle — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **structure système, fonctions, états, interfaces et contraintes**.

## Structure détectée
- Niveau 1: **Décomposition fonctionnelle**

## Énoncés de baseline extraits
- | Fonction | Sous-fonction | État V1 |
|---|---|---|
| Transporter | Maintenir le noyau `Home` | Baseline |
| Porter | Supporter exo-coque et interfaces | À dimensionner |
| Segmenter | Décomposer chaque étage externe | Baseline configurable |
| Séparer | Libérer latéralement un étage | PoC mécanique requis |
| Stocker | Réservoirs périphériques | Hypothèse critique |
| Transférer | Déplacer/reconfigurer les réservoirs | Hypothèse critique |
| Protéger | Isolation thermique/mécanique du noyau | Trade study |
| Guider | Avionique / navigation | Hors détail dans ce dossier |
| Assister au sol | Rampe / infrastructure | Option indépendante |
| Maintenir | Inspection / maintenance | Baseline au sol; humain en vol non retenu V1 |

## Axes à documenter
- frontière système
- interfaces physiques et logiques
- états/configurations
- entrées/sorties
- hypothèses de charge
- dépendances inter-sous-systèmes

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
