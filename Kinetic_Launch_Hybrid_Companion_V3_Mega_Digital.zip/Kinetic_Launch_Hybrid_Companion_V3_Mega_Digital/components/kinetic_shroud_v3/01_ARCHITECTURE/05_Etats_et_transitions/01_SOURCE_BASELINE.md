# Machine d'états conceptuelle

`GROUND_SAFE → INTEGRATED → DYNAMIC_PHASE → STAGE_1_RELEASED → STAGE_2_RELEASED → STAGE_3_RELEASED → STAGE_4_RELEASED → HOME_ONLY → RECOVERY/END`

Chaque transition possède :
- préconditions mesurables ;
- autorisation ;
- détection de réussite ;
- timeout ;
- état d'abandon sûr ;
- journal de configuration.

Aucune transition n'est autorisée uniquement parce qu'une pression ou une force « devrait » avoir atteint une valeur.
