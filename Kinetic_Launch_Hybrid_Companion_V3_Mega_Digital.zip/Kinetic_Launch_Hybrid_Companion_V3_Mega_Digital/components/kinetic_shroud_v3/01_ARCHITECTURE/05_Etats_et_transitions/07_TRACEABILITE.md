# Machine d'états conceptuelle — traçabilité

## Origine
- Ancien chemin V1 : `01_ARCHITECTURE/05_Etats_et_transitions.md`
- SHA-256 V1 : `9d7a59ace0ef6005a9e3c924224561c66b6296700c0c3986ff59afab31ac6d56`
- Catégorie : `01_ARCHITECTURE`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
