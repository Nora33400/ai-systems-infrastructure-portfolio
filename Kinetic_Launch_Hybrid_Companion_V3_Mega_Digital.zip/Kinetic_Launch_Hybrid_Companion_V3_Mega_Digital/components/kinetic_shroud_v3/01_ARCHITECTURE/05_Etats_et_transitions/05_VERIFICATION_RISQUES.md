# Machine d'états conceptuelle — vérification, risques et critères

## Méthodes
- revue d'architecture
- modèle d'interfaces
- analyse d'interférences
- maquette basse énergie
- traçabilité exigence→fonction

## Points issus de la source
- Vérifier : préconditions mesurables ;
- Vérifier : autorisation ;
- Vérifier : détection de réussite ;
- Vérifier : timeout ;
- Vérifier : état d'abandon sûr ;
- Vérifier : journal de configuration.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
