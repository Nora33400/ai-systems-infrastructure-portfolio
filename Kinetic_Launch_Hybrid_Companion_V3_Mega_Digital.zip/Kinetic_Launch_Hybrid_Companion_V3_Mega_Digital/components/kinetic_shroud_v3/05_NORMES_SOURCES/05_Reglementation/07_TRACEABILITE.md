# Réglementation — cadre préliminaire — traçabilité

## Origine
- Ancien chemin V1 : `05_NORMES_SOURCES/05_Reglementation.md`
- SHA-256 V1 : `2e1f18a6466316d734a3f59d2c03c2eb15fd501925c2c2ea38b021c235b5b18f`
- Catégorie : `05_NORMES_SOURCES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
