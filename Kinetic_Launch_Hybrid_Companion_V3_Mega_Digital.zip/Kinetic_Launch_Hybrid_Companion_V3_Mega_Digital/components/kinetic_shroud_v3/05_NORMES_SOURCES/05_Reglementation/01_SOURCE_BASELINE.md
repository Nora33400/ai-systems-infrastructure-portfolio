# Réglementation — cadre préliminaire

Le cadre réglementaire dépend du pays, du site, du type d'opération, de l'altitude et du statut commercial.

Référence internationale pratique pour le dossier :
- aux États-Unis, la FAA indique que Part 450 couvre les licences d'opérateur de lancement/rentrée et le périmètre associé ;
- en Europe/France, une analyse spécifique avec les autorités et le droit spatial applicable serait requise avant toute opération réelle.

Aucune étape opérationnelle de lancement n'est couverte par ce ZIP.
