# Réglementation — cadre préliminaire — vérification, risques et critères

## Méthodes
- source primaire
- version contrôlée
- revue d'applicabilité
- matrice de conformité
- historique des changements

## Points issus de la source
- Vérifier : aux États-Unis, la FAA indique que Part 450 couvre les licences d'opérateur de lancement/rentrée et le périmètre associé ;
- Vérifier : en Europe/France, une analyse spécifique avec les autorités et le droit spatial applicable serait requise avant toute opération réelle.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
