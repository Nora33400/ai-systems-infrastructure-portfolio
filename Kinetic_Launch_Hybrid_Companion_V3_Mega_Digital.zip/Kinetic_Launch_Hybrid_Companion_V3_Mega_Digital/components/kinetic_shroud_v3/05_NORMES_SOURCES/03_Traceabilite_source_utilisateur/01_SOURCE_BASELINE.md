# Traçabilité vers la source utilisateur

Repères principaux de la source :
- architecture cylindres concentriques et noyau Home ;
- remplacement des glissières par segmentation latérale ;
- idée de réservoirs périphériques ;
- passage de 3 à 4 segments, puis clarification : **4 étages, chaque étage pouvant avoir plusieurs segments** ;
- extension à noyau interne `X` niveaux ;
- idée de rampe d'assistance ;
- demande explicite de synthèse très poussée.

Cette V1 conserve l'intention d'architecture mais corrige les conclusions physiques non démontrées.
