# Traçabilité vers la source utilisateur — traçabilité

## Origine
- Ancien chemin V1 : `05_NORMES_SOURCES/03_Traceabilite_source_utilisateur.md`
- SHA-256 V1 : `15f5c43466c9aa330c99d05d9e60f31d3667e157f95901950c5bb33e1cfb5352`
- Catégorie : `05_NORMES_SOURCES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
