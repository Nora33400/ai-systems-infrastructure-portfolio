# Traçabilité vers la source utilisateur — vérification, risques et critères

## Méthodes
- source primaire
- version contrôlée
- revue d'applicabilité
- matrice de conformité
- historique des changements

## Points issus de la source
- Vérifier : architecture cylindres concentriques et noyau Home ;
- Vérifier : remplacement des glissières par segmentation latérale ;
- Vérifier : idée de réservoirs périphériques ;
- Vérifier : passage de 3 à 4 segments, puis clarification : **4 étages, chaque étage pouvant avoir plusieurs segments** ;
- Vérifier : extension à noyau interne `X` niveaux ;
- Vérifier : idée de rampe d'assistance ;
- Vérifier : demande explicite de synthèse très poussée.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
