# Traçabilité vers la source utilisateur — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **sources, normes, applicabilité, preuves et limites documentaires**.

## Structure détectée
- Niveau 1: **Traçabilité vers la source utilisateur**

## Énoncés de baseline extraits
- architecture cylindres concentriques et noyau Home ;
- remplacement des glissières par segmentation latérale ;
- idée de réservoirs périphériques ;
- passage de 3 à 4 segments, puis clarification : **4 étages, chaque étage pouvant avoir plusieurs segments** ;
- extension à noyau interne `X` niveaux ;
- idée de rampe d'assistance ;
- demande explicite de synthèse très poussée.

## Axes à documenter
- autorité de la source
- date/version
- applicabilité
- exigences dérivées
- écarts
- traçabilité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
