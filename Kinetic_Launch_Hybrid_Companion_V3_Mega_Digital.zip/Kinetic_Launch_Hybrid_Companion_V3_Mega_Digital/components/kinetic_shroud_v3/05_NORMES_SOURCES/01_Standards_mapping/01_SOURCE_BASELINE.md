# Matrice standards / méthodes

- **NASA Systems Engineering Handbook** : cycle de vie, exigences, trade studies, TRL.
- **NASA Cost Estimating Handbook v4** : WBS, méthodes de coût, risque/incertitude, JCL, construction/GSE.
- **NASA WBS Handbook** : structure produit pour coûts/planning/risques.
- **ECSS-E-ST-10-02C** : vérification d'un système spatial.
- **ECSS-E-ST-10-03C Rev.1** : essais au sol des éléments du segment spatial.
- **ECSS-E-ST-32C Rev.1** : exigences générales de structures.
- **ECSS-E-ST-32-02C Rev.2 (2025)** : hardware pressurisé.
- **FAA Part 450** : référence réglementaire américaine pour licence launch/reentry; à remplacer/compléter selon pays/site réel.
