# Matrice standards / méthodes — décisions et données manquantes

## Questions ouvertes
- [ ] Quelles données sont des exigences et lesquelles sont seulement des idées ?
- [ ] Quel propriétaire valide ce sujet ?
- [ ] Quelle preuve minimale faut-il au prochain gate ?
- [ ] Quelles données manquent pour sortir du ROM ?
- [ ] Quel impact sur architecture, interfaces, tests et planning ?
- [ ] Quel kill criterion stoppe une branche non rentable ou non vérifiable ?

## Journal de décision
| ID | Date | Décision | Options | Données | Motif | Impact | Approbateur |
|---|---|---|---|---|---|---|---|

## Règle
Une donnée manquante reste visible; elle n'est pas remplacée silencieusement.
