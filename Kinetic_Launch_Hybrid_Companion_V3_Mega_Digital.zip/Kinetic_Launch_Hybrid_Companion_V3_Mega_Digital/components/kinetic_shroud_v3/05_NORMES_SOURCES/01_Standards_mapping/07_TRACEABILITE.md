# Matrice standards / méthodes — traçabilité

## Origine
- Ancien chemin V1 : `05_NORMES_SOURCES/01_Standards_mapping.md`
- SHA-256 V1 : `d40062cf690d96bbaa0368ea2b09b4818b8b4f81f48bb8d14528ec00f284a365`
- Catégorie : `05_NORMES_SOURCES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
