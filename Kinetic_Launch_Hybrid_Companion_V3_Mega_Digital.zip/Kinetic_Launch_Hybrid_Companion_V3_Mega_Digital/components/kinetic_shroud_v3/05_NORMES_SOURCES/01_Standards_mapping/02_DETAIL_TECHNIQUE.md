# Matrice standards / méthodes — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **sources, normes, applicabilité, preuves et limites documentaires**.

## Structure détectée
- Niveau 1: **Matrice standards / méthodes**

## Énoncés de baseline extraits
- **NASA Systems Engineering Handbook** : cycle de vie, exigences, trade studies, TRL.
- **NASA Cost Estimating Handbook v4** : WBS, méthodes de coût, risque/incertitude, JCL, construction/GSE.
- **NASA WBS Handbook** : structure produit pour coûts/planning/risques.
- **ECSS-E-ST-10-02C** : vérification d'un système spatial.
- **ECSS-E-ST-10-03C Rev.1** : essais au sol des éléments du segment spatial.
- **ECSS-E-ST-32C Rev.1** : exigences générales de structures.
- **ECSS-E-ST-32-02C Rev.2 (2025)** : hardware pressurisé.
- **FAA Part 450** : référence réglementaire américaine pour licence launch/reentry; à remplacer/compléter selon pays/site réel.

## Axes à documenter
- autorité de la source
- date/version
- applicabilité
- exigences dérivées
- écarts
- traçabilité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
