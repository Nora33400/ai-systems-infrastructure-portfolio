# Matrice standards / méthodes — vérification, risques et critères

## Méthodes
- source primaire
- version contrôlée
- revue d'applicabilité
- matrice de conformité
- historique des changements

## Points issus de la source
- Vérifier : **NASA Systems Engineering Handbook** : cycle de vie, exigences, trade studies, TRL.
- Vérifier : **NASA Cost Estimating Handbook v4** : WBS, méthodes de coût, risque/incertitude, JCL, construction/GSE.
- Vérifier : **NASA WBS Handbook** : structure produit pour coûts/planning/risques.
- Vérifier : **ECSS-E-ST-10-02C** : vérification d'un système spatial.
- Vérifier : **ECSS-E-ST-10-03C Rev.1** : essais au sol des éléments du segment spatial.
- Vérifier : **ECSS-E-ST-32C Rev.1** : exigences générales de structures.
- Vérifier : **ECSS-E-ST-32-02C Rev.2 (2025)** : hardware pressurisé.
- Vérifier : **FAA Part 450** : référence réglementaire américaine pour licence launch/reentry; à remplacer/compléter selon pays/site réel.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
