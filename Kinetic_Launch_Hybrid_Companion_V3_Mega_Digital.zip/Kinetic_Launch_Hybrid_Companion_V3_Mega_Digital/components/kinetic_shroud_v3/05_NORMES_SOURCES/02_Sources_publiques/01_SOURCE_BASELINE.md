# Sources publiques

## Source utilisateur
- Fichier conversation : `Fichier markdown(6).md collé`, 1 149 lignes.
- Éléments clés : noyau Home; exo-coque 4 étages; segmentation variable; bonbonnes; séparation latérale; rampe optionnelle.

## Sources publiques consultées — août 2026
1. SpaceX — Falcon 9: https://www.spacex.com/vehicles/falcon-9/
2. SpaceX — Falcon Heavy: https://www.spacex.com/vehicles/falcon-heavy
3. SpaceX — Starship: https://www.spacex.com/vehicles/starship
4. SpaceX — Falcon Payload User's Guide (2025): https://www.spacex.com/assets/media/falcon-users-guide-2025-05-09.pdf
5. NASA — Systems Engineering Handbook / TRL: https://www.nasa.gov/reference/system-engineering-handbook-appendix/
6. NASA — Technology Readiness Levels: https://www.nasa.gov/directorates/somd/space-communications-navigation-program/technology-readiness-levels/
7. NASA — Cost Estimating Handbook / PP&C: https://www.nasa.gov/ocfo/ppc-corner/ppc-guidance-documents/
8. NASA — Project Cost Estimating Capability: https://www.nasa.gov/ocfo/ppc-corner/pcec-project-cost-estimating-capability/
9. NASA — WBS Handbook: https://ntrs.nasa.gov/api/citations/20180000844/downloads/20180000844.pdf
10. ECSS — active standards: https://ecss.nl/standards/active-standards/
11. ECSS-E-ST-10-03C Rev.1 Testing: https://ecss.nl/standard/ecss-e-st-10-03c-rev-1-testing-31-may-2022/
12. ECSS-E-ST-32-02C Rev.2 pressurized hardware: https://ecss.nl/standard/ecss-e-st-32-02c-rev-2-structural-design-and-verification-of-pressurized-hardware-15-november-2008/
13. FAA — operator licenses / Part 450: https://www.faa.gov/space/licenses/operator_licenses_permits
14. USGS — Mineral Commodity Summaries 2026: https://pubs.usgs.gov/publication/mcs2026

## Règle de confiance
Les pages constructeur servent pour les caractéristiques publiées. NASA/ECSS servent pour méthode et standards. USGS sert pour tendance matière brute, pas pour devis de pièces aérospatiales.
