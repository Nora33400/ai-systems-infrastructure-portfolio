# Sources publiques — données et calculs

## Valeurs numériques détectées
- `1 149`
- `2026 1.`
- `2.`
- `3.`
- `4.`
- `2025`
- `05`
- `09.`
- `5.`
- `6.`
- `7.`
- `8.`
- `9.`
- `20180000844`
- `20180000844.`
- `10.`
- `11.`
- `10`
- `03`
- `31`
- `2022`
- `12.`
- `32`
- `02`
- `15`
- `2008`
- `13.`
- `450`
- `14.`
- `2026`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Discipline de calcul
Pour chaque grandeur : symbole, unité SI, valeur, source, date, incertitude et statut.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
