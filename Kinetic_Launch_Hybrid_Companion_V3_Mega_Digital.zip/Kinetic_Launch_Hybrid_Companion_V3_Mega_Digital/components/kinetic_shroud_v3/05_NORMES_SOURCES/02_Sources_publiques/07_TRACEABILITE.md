# Sources publiques — traçabilité

## Origine
- Ancien chemin V1 : `05_NORMES_SOURCES/02_Sources_publiques.md`
- SHA-256 V1 : `7c61003e050a2e7b53ed753f4cecff8742b873baa205ed893f10aeb9b928fdba`
- Catégorie : `05_NORMES_SOURCES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
