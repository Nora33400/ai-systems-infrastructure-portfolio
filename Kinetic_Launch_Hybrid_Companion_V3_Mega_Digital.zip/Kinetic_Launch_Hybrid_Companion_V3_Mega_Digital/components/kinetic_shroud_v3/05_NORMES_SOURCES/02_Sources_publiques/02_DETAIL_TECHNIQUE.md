# Sources publiques — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **sources, normes, applicabilité, preuves et limites documentaires**.

## Structure détectée
- Niveau 1: **Sources publiques**
- Niveau 2: **Source utilisateur**
- Niveau 2: **Sources publiques consultées — août 2026**
- Niveau 2: **Règle de confiance**

## Énoncés de baseline extraits
- Fichier conversation : `Fichier markdown(6).md collé`, 1 149 lignes.
- Éléments clés : noyau Home; exo-coque 4 étages; segmentation variable; bonbonnes; séparation latérale; rampe optionnelle.
- SpaceX — Falcon 9: https://www.spacex.com/vehicles/falcon-9/
- SpaceX — Falcon Heavy: https://www.spacex.com/vehicles/falcon-heavy
- SpaceX — Starship: https://www.spacex.com/vehicles/starship
- SpaceX — Falcon Payload User's Guide (2025): https://www.spacex.com/assets/media/falcon-users-guide-2025-05-09.pdf
- NASA — Systems Engineering Handbook / TRL: https://www.nasa.gov/reference/system-engineering-handbook-appendix/
- NASA — Technology Readiness Levels: https://www.nasa.gov/directorates/somd/space-communications-navigation-program/technology-readiness-levels/
- NASA — Cost Estimating Handbook / PP&C: https://www.nasa.gov/ocfo/ppc-corner/ppc-guidance-documents/
- NASA — Project Cost Estimating Capability: https://www.nasa.gov/ocfo/ppc-corner/pcec-project-cost-estimating-capability/
- NASA — WBS Handbook: https://ntrs.nasa.gov/api/citations/20180000844/downloads/20180000844.pdf
- ECSS — active standards: https://ecss.nl/standards/active-standards/
- ECSS-E-ST-10-03C Rev.1 Testing: https://ecss.nl/standard/ecss-e-st-10-03c-rev-1-testing-31-may-2022/
- ECSS-E-ST-32-02C Rev.2 pressurized hardware: https://ecss.nl/standard/ecss-e-st-32-02c-rev-2-structural-design-and-verification-of-pressurized-hardware-15-november-2008/
- FAA — operator licenses / Part 450: https://www.faa.gov/space/licenses/operator_licenses_permits
- USGS — Mineral Commodity Summaries 2026: https://pubs.usgs.gov/publication/mcs2026

## Axes à documenter
- autorité de la source
- date/version
- applicabilité
- exigences dérivées
- écarts
- traçabilité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
