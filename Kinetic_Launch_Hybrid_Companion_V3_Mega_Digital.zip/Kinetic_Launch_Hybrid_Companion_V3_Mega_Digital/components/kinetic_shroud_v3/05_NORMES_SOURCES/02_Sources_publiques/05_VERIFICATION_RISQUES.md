# Sources publiques — vérification, risques et critères

## Méthodes
- source primaire
- version contrôlée
- revue d'applicabilité
- matrice de conformité
- historique des changements

## Points issus de la source
- Vérifier : Fichier conversation : `Fichier markdown(6).md collé`, 1 149 lignes.
- Vérifier : Éléments clés : noyau Home; exo-coque 4 étages; segmentation variable; bonbonnes; séparation latérale; rampe optionnelle.
- Vérifier : SpaceX — Falcon 9: https://www.spacex.com/vehicles/falcon-9/
- Vérifier : SpaceX — Falcon Heavy: https://www.spacex.com/vehicles/falcon-heavy
- Vérifier : SpaceX — Starship: https://www.spacex.com/vehicles/starship
- Vérifier : SpaceX — Falcon Payload User's Guide (2025): https://www.spacex.com/assets/media/falcon-users-guide-2025-05-09.pdf
- Vérifier : NASA — Systems Engineering Handbook / TRL: https://www.nasa.gov/reference/system-engineering-handbook-appendix/
- Vérifier : NASA — Technology Readiness Levels: https://www.nasa.gov/directorates/somd/space-communications-navigation-program/technology-readiness-levels/
- Vérifier : NASA — Cost Estimating Handbook / PP&C: https://www.nasa.gov/ocfo/ppc-corner/ppc-guidance-documents/
- Vérifier : NASA — Project Cost Estimating Capability: https://www.nasa.gov/ocfo/ppc-corner/pcec-project-cost-estimating-capability/

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
