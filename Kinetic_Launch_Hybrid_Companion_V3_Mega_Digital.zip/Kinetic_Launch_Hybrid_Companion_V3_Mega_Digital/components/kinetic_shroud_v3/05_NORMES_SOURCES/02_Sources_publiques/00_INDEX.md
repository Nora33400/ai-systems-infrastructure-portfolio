# Sources publiques — dossier développé

**Ancien document :** `05_NORMES_SOURCES/02_Sources_publiques.md`  
**Catégorie :** `05_NORMES_SOURCES`  
**Version :** V2 Expanded  
**Hash source :** `7c61003e050a2e7b53ed753f4cecff8742b873baa205ed893f10aeb9b928fdba`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
