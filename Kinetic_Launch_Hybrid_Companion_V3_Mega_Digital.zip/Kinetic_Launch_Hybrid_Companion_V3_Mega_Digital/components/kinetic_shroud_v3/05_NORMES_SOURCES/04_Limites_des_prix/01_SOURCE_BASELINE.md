# Limites des données prix

Les prix de composants aérospatiaux sont fortement dépendants de la nuance, du certificat, de la taille de lot, des tolérances, des CND, du traitement et du fournisseur. Les données publiques de minerais ou de métal primaire ne représentent pas un prix de pièce finie.

Pour passer de ROM à devis :
1. figer une BOM ;
2. obtenir masse et drawing par pièce ;
3. demander au moins 3 RFQ ;
4. séparer matière, transformation, contrôle et intégration ;
5. dater la devise et la convertir dans une base monétaire commune.
