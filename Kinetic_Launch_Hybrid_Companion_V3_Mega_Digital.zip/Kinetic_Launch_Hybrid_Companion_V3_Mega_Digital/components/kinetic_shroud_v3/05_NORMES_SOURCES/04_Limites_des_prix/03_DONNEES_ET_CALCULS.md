# Limites des données prix — données et calculs

## Valeurs numériques détectées
- `1.`
- `2.`
- `3.`
- `4.`
- `5.`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Modèle recommandé
- `C_travail = Σ(heures_i × taux_i)`
- `C_achat = Σ(qté_i × prix_unitaire_i)`
- `C_base = C_travail + C_achat + C_essais + C_installations + C_QA`
- `C_plan = C_base × (1 + réserve)`
- Chaque prix porte date, devise, source, quantité et maturité.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
