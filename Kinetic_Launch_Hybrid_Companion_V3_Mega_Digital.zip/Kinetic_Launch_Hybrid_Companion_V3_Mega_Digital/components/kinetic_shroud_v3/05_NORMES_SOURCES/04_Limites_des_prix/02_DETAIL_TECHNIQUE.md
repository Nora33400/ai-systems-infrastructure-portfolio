# Limites des données prix — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **modèles chiffrés, hypothèses, incertitudes et sensibilité**.

## Structure détectée
- Niveau 1: **Limites des données prix**

## Énoncés de baseline extraits
- figer une BOM ;
- obtenir masse et drawing par pièce ;
- demander au moins 3 RFQ ;
- séparer matière, transformation, contrôle et intégration ;
- dater la devise et la convertir dans une base monétaire commune.

## Axes à documenter
- unités et dimensions
- équations
- valeurs d'entrée
- incertitude
- scénarios
- sensibilité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
