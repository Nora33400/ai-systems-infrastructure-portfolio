# Limites des données prix — traçabilité

## Origine
- Ancien chemin V1 : `05_NORMES_SOURCES/04_Limites_des_prix.md`
- SHA-256 V1 : `83c50c9c24bf9c5e154bb13abf03ff749e410be01eb1738ece0228336848bd13`
- Catégorie : `05_NORMES_SOURCES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
