# Questions ouvertes

1. Quelle mission vise le premier démonstrateur ?
2. Le noyau est-il d'abord non habité ?
3. Combien de segments par étage sont réellement nécessaires ?
4. Les bonbonnes doivent-elles être mobiles, ou peut-on séparer fonction stockage et fonction coque ?
5. Quel gain mesurable justifie la segmentation latérale ?
6. Quelle masse structurelle additionnelle l'exo-coque impose-t-elle ?
7. Quelle stratégie de récupération est économiquement défendable ?
8. La rampe apporte-t-elle un gain net après coût de site et charges induites ?
9. Quel TRL cible au bout du prochain financement ?
10. Quel budget maximal constitue un kill criterion ?
