# Questions ouvertes — vérification, risques et critères

## Méthodes
- revue documentaire
- cohérence croisée
- contrôle liens
- versioning
- validation par gate

## Points issus de la source
- Vérifier : Quelle mission vise le premier démonstrateur ?
- Vérifier : Le noyau est-il d'abord non habité ?
- Vérifier : Combien de segments par étage sont réellement nécessaires ?
- Vérifier : Les bonbonnes doivent-elles être mobiles, ou peut-on séparer fonction stockage et fonction coque ?
- Vérifier : Quel gain mesurable justifie la segmentation latérale ?
- Vérifier : Quelle masse structurelle additionnelle l'exo-coque impose-t-elle ?
- Vérifier : Quelle stratégie de récupération est économiquement défendable ?
- Vérifier : La rampe apporte-t-elle un gain net après coût de site et charges induites ?
- Vérifier : Quel TRL cible au bout du prochain financement ?
- Vérifier : Quel budget maximal constitue un kill criterion ?

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
