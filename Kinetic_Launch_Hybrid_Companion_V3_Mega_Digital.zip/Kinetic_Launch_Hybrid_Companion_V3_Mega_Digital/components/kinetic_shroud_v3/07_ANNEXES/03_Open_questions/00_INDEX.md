# Questions ouvertes — dossier développé

**Ancien document :** `07_ANNEXES/03_Open_questions.md`  
**Catégorie :** `07_ANNEXES`  
**Version :** V2 Expanded  
**Hash source :** `6021952fb7f76cbf0aa9b9f18b4f91d228bbcc854e622a3200369d45e1dd06f9`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
