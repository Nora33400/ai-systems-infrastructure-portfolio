# Questions ouvertes — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **documentation de soutien, décision, glossaire et traçabilité**.

## Structure détectée
- Niveau 1: **Questions ouvertes**

## Énoncés de baseline extraits
- Quelle mission vise le premier démonstrateur ?
- Le noyau est-il d'abord non habité ?
- Combien de segments par étage sont réellement nécessaires ?
- Les bonbonnes doivent-elles être mobiles, ou peut-on séparer fonction stockage et fonction coque ?
- Quel gain mesurable justifie la segmentation latérale ?
- Quelle masse structurelle additionnelle l'exo-coque impose-t-elle ?
- Quelle stratégie de récupération est économiquement défendable ?
- La rampe apporte-t-elle un gain net après coût de site et charges induites ?
- Quel TRL cible au bout du prochain financement ?
- Quel budget maximal constitue un kill criterion ?

## Axes à documenter
- objectif
- contenu
- dépendances
- utilisateur cible
- données
- mise à jour

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
