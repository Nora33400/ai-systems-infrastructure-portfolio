# Questions ouvertes — traçabilité

## Origine
- Ancien chemin V1 : `07_ANNEXES/03_Open_questions.md`
- SHA-256 V1 : `6021952fb7f76cbf0aa9b9f18b4f91d228bbcc854e622a3200369d45e1dd06f9`
- Catégorie : `07_ANNEXES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
