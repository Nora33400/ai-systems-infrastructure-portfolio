# Questions ouvertes — données et calculs

## Valeurs numériques détectées
- `1.`
- `2.`
- `3.`
- `4.`
- `5.`
- `6.`
- `7.`
- `8.`
- `9.`
- `10.`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Discipline de calcul
Pour chaque grandeur : symbole, unité SI, valeur, source, date, incertitude et statut.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
