# Journal de changement du modèle coût

- **2026-08-19 / V1.0** : création du ROM S0/S1/S2.
- S1 déterministe : 6,786,975 €.
- Monte-Carlo : P50 5,581,271 €, P80 5,881,180 €, P90 6,034,974 €.
- Toute mise à jour doit conserver ancienne hypothèse, nouvelle hypothèse, source et impact.
