# Journal de changement du modèle coût — données et calculs

## Valeurs numériques détectées
- `2026`
- `08`
- `19`
- `6,786,975 €`
- `5,581,271 €`
- `5,881,180 €`
- `6,034,974 €`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Discipline de calcul
Pour chaque grandeur : symbole, unité SI, valeur, source, date, incertitude et statut.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
