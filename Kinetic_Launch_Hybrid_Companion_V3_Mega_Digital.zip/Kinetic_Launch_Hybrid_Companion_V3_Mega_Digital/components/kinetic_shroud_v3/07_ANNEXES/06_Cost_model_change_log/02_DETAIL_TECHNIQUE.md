# Journal de changement du modèle coût — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **documentation de soutien, décision, glossaire et traçabilité**.

## Structure détectée
- Niveau 1: **Journal de changement du modèle coût**

## Énoncés de baseline extraits
- **2026-08-19 / V1.0** : création du ROM S0/S1/S2.
- S1 déterministe : 6,786,975 €.
- Monte-Carlo : P50 5,581,271 €, P80 5,881,180 €, P90 6,034,974 €.
- Toute mise à jour doit conserver ancienne hypothèse, nouvelle hypothèse, source et impact.

## Axes à documenter
- objectif
- contenu
- dépendances
- utilisateur cible
- données
- mise à jour

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
