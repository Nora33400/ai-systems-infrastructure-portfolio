# Journal de changement du modèle coût — vérification, risques et critères

## Méthodes
- revue documentaire
- cohérence croisée
- contrôle liens
- versioning
- validation par gate

## Points issus de la source
- Vérifier : **2026-08-19 / V1.0** : création du ROM S0/S1/S2.
- Vérifier : S1 déterministe : 6,786,975 €.
- Vérifier : Monte-Carlo : P50 5,581,271 €, P80 5,881,180 €, P90 6,034,974 €.
- Vérifier : Toute mise à jour doit conserver ancienne hypothèse, nouvelle hypothèse, source et impact.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
