# Journal de changement du modèle coût — traçabilité

## Origine
- Ancien chemin V1 : `07_ANNEXES/06_Cost_model_change_log.md`
- SHA-256 V1 : `1ff9aa51f9ac621b5f157223b20bf36eaab8e6c740ef9a8a7eb48e19bfa39494`
- Catégorie : `07_ANNEXES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
