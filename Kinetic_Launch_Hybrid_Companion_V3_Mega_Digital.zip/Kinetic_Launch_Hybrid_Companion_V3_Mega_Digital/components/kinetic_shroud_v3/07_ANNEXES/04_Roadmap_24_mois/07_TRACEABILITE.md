# Roadmap 24 mois — traçabilité

## Origine
- Ancien chemin V1 : `07_ANNEXES/04_Roadmap_24_mois.md`
- SHA-256 V1 : `649795756a0d318ddbf11093c470d6163d8688ce2eca6ec3ced0d6800806500b`
- Catégorie : `07_ANNEXES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
