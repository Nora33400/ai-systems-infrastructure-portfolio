# Roadmap 24 mois

### M0–M3
Nettoyage exigences, modèle système, trades critiques, architecture numérique.

### M4–M6
Maquettes cinématiques simples, instrumentation, choix segmentation.

### M7–M12
Démonstrateur d'un étage externe autour d'un noyau factice.

### M13–M15
Séquence multi-étages basse énergie; analyse de répétabilité.

### M16–M18
Re-design, charges/vibrations, interfaces.

### M19–M24
Article intégré non-vol et décision Go/No-Go vers une branche plus mature.

La branche rampe et la branche pressurisée restent des programmes parallèles séparés.
