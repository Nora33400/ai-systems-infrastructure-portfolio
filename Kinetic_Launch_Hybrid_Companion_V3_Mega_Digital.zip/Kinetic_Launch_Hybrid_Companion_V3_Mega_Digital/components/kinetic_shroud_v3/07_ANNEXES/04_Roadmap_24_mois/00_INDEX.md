# Roadmap 24 mois — dossier développé

**Ancien document :** `07_ANNEXES/04_Roadmap_24_mois.md`  
**Catégorie :** `07_ANNEXES`  
**Version :** V2 Expanded  
**Hash source :** `649795756a0d318ddbf11093c470d6163d8688ce2eca6ec3ced0d6800806500b`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
