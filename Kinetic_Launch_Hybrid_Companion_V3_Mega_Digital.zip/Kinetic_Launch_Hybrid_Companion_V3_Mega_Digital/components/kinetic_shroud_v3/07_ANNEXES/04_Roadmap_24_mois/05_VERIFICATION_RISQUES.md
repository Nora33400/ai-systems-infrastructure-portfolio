# Roadmap 24 mois — vérification, risques et critères

## Méthodes
- revue de jalon
- audit de configuration
- contrôle complétude livrables
- analyse chemin critique
- revue budget

## Points issus de la source
- Définir au moins un critère vérifiable lié au contenu.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
