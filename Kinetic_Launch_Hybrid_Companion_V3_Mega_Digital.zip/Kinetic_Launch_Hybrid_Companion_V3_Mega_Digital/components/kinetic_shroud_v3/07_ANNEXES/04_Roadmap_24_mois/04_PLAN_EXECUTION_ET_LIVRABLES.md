# Roadmap 24 mois — plan d'exécution et livrables

## Séquence
1. Geler la source.
2. Extraire exigences, hypothèses et décisions.
3. Affecter IDs WBS/REQ/ICD/TEST.
4. Identifier les données manquantes.
5. Produire analyse ou maquette adaptée.
6. Réaliser une revue.
7. Enregistrer écarts et décisions.
8. Mettre à jour coût, planning, risques et configuration.

## Travaux dérivés
- Transformer **M0–M3** en livrable versionné avec propriétaire, entrée et critère de sortie.
- Transformer **M4–M6** en livrable versionné avec propriétaire, entrée et critère de sortie.
- Transformer **M7–M12** en livrable versionné avec propriétaire, entrée et critère de sortie.
- Transformer **M13–M15** en livrable versionné avec propriétaire, entrée et critère de sortie.
- Transformer **M16–M18** en livrable versionné avec propriétaire, entrée et critère de sortie.
- Transformer **M19–M24** en livrable versionné avec propriétaire, entrée et critère de sortie.

## Livrables minimaux
- note d'hypothèses ;
- tableau de données ;
- analyse ou modèle ;
- résultat reproductible ;
- liste d'écarts ;
- décision de gate ;
- mise à jour risques ;
- mise à jour V&V.

## Definition of Done
Une autre personne doit pouvoir reconstruire la conclusion à partir des entrées et de la méthode.
