# Roadmap 24 mois — données et calculs

## Valeurs numériques détectées
- `24 m`

Les valeurs ci-dessus sont des repères textuels : elles doivent être qualifiées avant emploi.

### Modèle recommandé
- `Charge_h = Σ(durée_phase × FTE × heures_semaine)`
- Le calendrier doit intégrer chevauchements, dépendances, marges et chemin critique.


## Fiche minimale d'une donnée
| Champ | Contenu |
|---|---|
| ID | identifiant stable |
| Nom | grandeur |
| Valeur | nominale |
| Unité | SI |
| Incertitude | ± / intervalle / distribution |
| Source | fichier, fournisseur, test ou calcul |
| Date | validité |
| Statut | mesuré / hypothèse / calculé |
| WBS | sous-système |
| Vérification | méthode |

## Règle
Une masse, un prix, une durée, une géométrie ou une performance non supportée reste **N/D**.
