# Checklist PDR-like — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **documentation de soutien, décision, glossaire et traçabilité**.

## Structure détectée
- Niveau 1: **Checklist PDR-like**

## Énoncés de baseline extraits
- [ ] Mission de démonstration figée
- [ ] Architecture baseline versionnée
- [ ] Exigences Must traçables
- [ ] ICD critiques ouverts/fermés identifiés
- [ ] Budget masse conceptuel
- [ ] Modèle coût P50/P80
- [ ] Planning réseau
- [ ] 10 risques principaux avec owners
- [ ] Plan V&V
- [ ] Plan de test basse énergie
- [ ] Sûreté systèmes pressurisés séparée
- [ ] Décision rampe indépendante
- [ ] Facteurs humains baseline
- [ ] Configuration management actif

## Axes à documenter
- objectif
- contenu
- dépendances
- utilisateur cible
- données
- mise à jour

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
