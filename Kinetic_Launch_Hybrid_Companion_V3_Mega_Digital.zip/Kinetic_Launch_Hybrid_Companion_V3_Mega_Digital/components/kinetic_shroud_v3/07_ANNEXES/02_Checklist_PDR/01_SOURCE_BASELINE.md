# Checklist PDR-like

- [ ] Mission de démonstration figée
- [ ] Architecture baseline versionnée
- [ ] Exigences Must traçables
- [ ] ICD critiques ouverts/fermés identifiés
- [ ] Budget masse conceptuel
- [ ] Modèle coût P50/P80
- [ ] Planning réseau
- [ ] 10 risques principaux avec owners
- [ ] Plan V&V
- [ ] Plan de test basse énergie
- [ ] Sûreté systèmes pressurisés séparée
- [ ] Décision rampe indépendante
- [ ] Facteurs humains baseline
- [ ] Configuration management actif
