# Checklist PDR-like — traçabilité

## Origine
- Ancien chemin V1 : `07_ANNEXES/02_Checklist_PDR.md`
- SHA-256 V1 : `9c1e3d52a00b1d676fd9b955a1f0ff86a0a7008f4c2737554558fd62a265def2`
- Catégorie : `07_ANNEXES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
