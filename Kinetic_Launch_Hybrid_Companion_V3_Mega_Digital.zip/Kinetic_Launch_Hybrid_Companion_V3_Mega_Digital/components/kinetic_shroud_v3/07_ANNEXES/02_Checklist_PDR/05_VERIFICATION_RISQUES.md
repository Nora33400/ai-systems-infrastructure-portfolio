# Checklist PDR-like — vérification, risques et critères

## Méthodes
- revue documentaire
- cohérence croisée
- contrôle liens
- versioning
- validation par gate

## Points issus de la source
- Vérifier : [ ] Mission de démonstration figée
- Vérifier : [ ] Architecture baseline versionnée
- Vérifier : [ ] Exigences Must traçables
- Vérifier : [ ] ICD critiques ouverts/fermés identifiés
- Vérifier : [ ] Budget masse conceptuel
- Vérifier : [ ] Modèle coût P50/P80
- Vérifier : [ ] Planning réseau
- Vérifier : [ ] 10 risques principaux avec owners
- Vérifier : [ ] Plan V&V
- Vérifier : [ ] Plan de test basse énergie

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
