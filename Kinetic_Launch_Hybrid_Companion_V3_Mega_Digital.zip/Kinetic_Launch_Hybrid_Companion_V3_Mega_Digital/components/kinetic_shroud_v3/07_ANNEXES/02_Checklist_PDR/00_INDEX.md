# Checklist PDR-like — dossier développé

**Ancien document :** `07_ANNEXES/02_Checklist_PDR.md`  
**Catégorie :** `07_ANNEXES`  
**Version :** V2 Expanded  
**Hash source :** `9c1e3d52a00b1d676fd9b955a1f0ff86a0a7008f4c2737554558fd62a265def2`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
