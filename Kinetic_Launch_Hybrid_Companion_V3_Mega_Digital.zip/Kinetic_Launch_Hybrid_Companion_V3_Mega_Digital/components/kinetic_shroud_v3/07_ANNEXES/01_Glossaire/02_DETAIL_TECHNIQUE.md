# Glossaire — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **documentation de soutien, décision, glossaire et traçabilité**.

## Structure détectée
- Niveau 1: **Glossaire**

## Énoncés de baseline extraits
- **Baseline** : configuration de référence contrôlée.
- **ConOps** : concept d'opérations.
- **GSE** : Ground Support Equipment.
- **ICD** : Interface Control Document.
- **PDR/CDR** : revues préliminaire / critique de conception.
- **ROM** : Rough Order of Magnitude.
- **TRL** : Technology Readiness Level.
- **V&V** : Verification & Validation.
- **WBS** : Work Breakdown Structure.

## Axes à documenter
- objectif
- contenu
- dépendances
- utilisateur cible
- données
- mise à jour

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
