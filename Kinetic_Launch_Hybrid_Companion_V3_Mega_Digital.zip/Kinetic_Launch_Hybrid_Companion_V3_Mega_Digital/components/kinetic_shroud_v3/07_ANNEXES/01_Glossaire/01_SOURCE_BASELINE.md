# Glossaire

- **Baseline** : configuration de référence contrôlée.
- **ConOps** : concept d'opérations.
- **GSE** : Ground Support Equipment.
- **ICD** : Interface Control Document.
- **PDR/CDR** : revues préliminaire / critique de conception.
- **ROM** : Rough Order of Magnitude.
- **TRL** : Technology Readiness Level.
- **V&V** : Verification & Validation.
- **WBS** : Work Breakdown Structure.
