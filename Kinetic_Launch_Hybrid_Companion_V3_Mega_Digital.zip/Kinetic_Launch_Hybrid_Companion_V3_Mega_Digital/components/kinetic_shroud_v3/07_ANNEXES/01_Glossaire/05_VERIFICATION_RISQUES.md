# Glossaire — vérification, risques et critères

## Méthodes
- revue documentaire
- cohérence croisée
- contrôle liens
- versioning
- validation par gate

## Points issus de la source
- Vérifier : **Baseline** : configuration de référence contrôlée.
- Vérifier : **ConOps** : concept d'opérations.
- Vérifier : **GSE** : Ground Support Equipment.
- Vérifier : **ICD** : Interface Control Document.
- Vérifier : **PDR/CDR** : revues préliminaire / critique de conception.
- Vérifier : **ROM** : Rough Order of Magnitude.
- Vérifier : **TRL** : Technology Readiness Level.
- Vérifier : **V&V** : Verification & Validation.
- Vérifier : **WBS** : Work Breakdown Structure.

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
