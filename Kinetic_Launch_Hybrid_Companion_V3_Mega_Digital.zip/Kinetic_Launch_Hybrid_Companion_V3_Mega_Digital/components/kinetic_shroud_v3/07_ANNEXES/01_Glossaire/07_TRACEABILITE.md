# Glossaire — traçabilité

## Origine
- Ancien chemin V1 : `07_ANNEXES/01_Glossaire.md`
- SHA-256 V1 : `9aa1a9cfc5c8d5fa4b60e9260bf388af3f207a0addc3f2365b3ce104de3b4795`
- Catégorie : `07_ANNEXES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
