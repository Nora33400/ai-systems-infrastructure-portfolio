# Template RFQ pour obtenir de vrais prix

Pour chaque pièce :
- ID / révision ;
- quantité prototype + quantité série ;
- matériau / norme / certificat ;
- brut fourni ou fourni par sous-traitant ;
- tolérances ;
- finition ;
- contrôle dimensionnel ;
- CND ;
- délai ;
- coût NRE ;
- coût unitaire ;
- MOQ ;
- incoterm ;
- validité du prix ;
- hypothèses / exclusions.

Cette fiche est la passerelle entre le modèle ROM du ZIP et des prix industriels réels.
