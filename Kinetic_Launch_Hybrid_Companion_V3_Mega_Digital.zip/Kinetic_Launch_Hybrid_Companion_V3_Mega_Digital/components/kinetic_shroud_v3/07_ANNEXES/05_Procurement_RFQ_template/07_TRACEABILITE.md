# Template RFQ pour obtenir de vrais prix — traçabilité

## Origine
- Ancien chemin V1 : `07_ANNEXES/05_Procurement_RFQ_template.md`
- SHA-256 V1 : `2085c75b70db0537784094e62863f61720f1103cbd4e03a484c4ad80ecfab9b2`
- Catégorie : `07_ANNEXES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
