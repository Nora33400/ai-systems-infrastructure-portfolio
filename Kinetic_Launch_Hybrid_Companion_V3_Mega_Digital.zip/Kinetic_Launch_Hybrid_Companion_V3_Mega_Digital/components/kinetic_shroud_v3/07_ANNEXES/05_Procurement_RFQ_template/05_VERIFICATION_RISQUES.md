# Template RFQ pour obtenir de vrais prix — vérification, risques et critères

## Méthodes
- recalcul indépendant
- contrôle d'unités
- test de sensibilité
- bornes P10/P50/P80/P90
- audit hypothèses

## Points issus de la source
- Vérifier : ID / révision ;
- Vérifier : quantité prototype + quantité série ;
- Vérifier : matériau / norme / certificat ;
- Vérifier : brut fourni ou fourni par sous-traitant ;
- Vérifier : tolérances ;
- Vérifier : finition ;
- Vérifier : contrôle dimensionnel ;
- Vérifier : CND ;
- Vérifier : délai ;
- Vérifier : coût NRE ;

## Risques génériques
| Risque | Effet | Traitement |
|---|---|---|
| Hypothèse prise pour un fait | décision erronée | statut obligatoire |
| Interface oubliée | incompatibilité | ICD + revue |
| Valeur non sourcée | fausse précision | source/date/unité |
| Test sans exigence | résultat inutilisable | matrice REQ↔TEST |
| Complexité non budgétée | dérive | WBS + réserve |
| Maturité surestimée | intégration prématurée | TRL par preuve |

## Critère de passage
Entrées identifiées, unités cohérentes, méthode reproductible, écarts enregistrés, limites explicites, lien vers décision ou exigence.
