# Template RFQ pour obtenir de vrais prix — détail technique

## Rôle
Développer l'ancien fichier en unités de travail exploitables. Focus : **modèles chiffrés, hypothèses, incertitudes et sensibilité**.

## Structure détectée
- Niveau 1: **Template RFQ pour obtenir de vrais prix**

## Énoncés de baseline extraits
- ID / révision ;
- quantité prototype + quantité série ;
- matériau / norme / certificat ;
- brut fourni ou fourni par sous-traitant ;
- tolérances ;
- finition ;
- contrôle dimensionnel ;
- CND ;
- délai ;
- coût NRE ;
- coût unitaire ;
- MOQ ;
- incoterm ;
- validité du prix ;
- hypothèses / exclusions.

## Axes à documenter
- unités et dimensions
- équations
- valeurs d'entrée
- incertitude
- scénarios
- sensibilité

## Décomposition recommandée
Pour chaque énoncé :
1. fonction ;
2. entrée ;
3. sortie ;
4. interface ;
5. hypothèse ;
6. preuve attendue ;
7. impact coût/planning ;
8. état de maturité.

## Règle de précision
Une phrase issue du concept n'est pas automatiquement une vérité d'ingénierie. Elle garde un statut explicite : **source**, **hypothèse**, **contrainte**, **mesure**, **calcul**, **vérifié** ou **rejeté**.

## Frontière de sûreté
Ce dossier reste volontairement au niveau architecture, programme, coûts, données, interfaces, vérification et sûreté. Il ne fournit pas de paramètres opérationnels permettant de construire ou d'employer un système propulsif, de formuler des ergols, de dimensionner un guidage de lancement ou de définir un profil de tir.
