# Comparaison conceptuelle — traçabilité

## Origine
- Ancien chemin V1 : `07_ANNEXES/07_Comparaison_architectures.md`
- SHA-256 V1 : `ab54c5c2dd1ce97471cc7e489d93d0281c93073c143a570f56a1b4a697f7ccf6`
- Catégorie : `07_ANNEXES`

## Données machine communes
Les CSV/JSON de `06_MODELES_MACHINE/` restent les sources structurées partagées : exigences, risques, TRL, scénarios, coût/planning, vérification, références publiques.

## Chaîne de preuve
`SOURCE → HYPOTHÈSE/EXIGENCE → ANALYSE → RÉSULTAT → VÉRIFICATION → DÉCISION → CONFIGURATION`

## Statuts
`SOURCE`, `HYPOTHESE`, `CONTRAINTE`, `MESURE`, `CALCULE`, `VERIFIE`, `REJETE`, `A_METTRE_A_JOUR`.
