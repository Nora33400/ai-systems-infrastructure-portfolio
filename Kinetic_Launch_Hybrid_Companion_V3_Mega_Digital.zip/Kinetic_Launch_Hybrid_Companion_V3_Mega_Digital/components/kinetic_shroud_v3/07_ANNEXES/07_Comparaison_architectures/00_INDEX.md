# Comparaison conceptuelle — dossier développé

**Ancien document :** `07_ANNEXES/07_Comparaison_architectures.md`  
**Catégorie :** `07_ANNEXES`  
**Version :** V2 Expanded  
**Hash source :** `ab54c5c2dd1ce97471cc7e489d93d0281c93073c143a570f56a1b4a697f7ccf6`

## Contenu
1. `01_SOURCE_BASELINE.md`
2. `02_DETAIL_TECHNIQUE.md`
3. `03_DONNEES_ET_CALCULS.md`
4. `04_PLAN_EXECUTION_ET_LIVRABLES.md`
5. `05_VERIFICATION_RISQUES.md`
6. `06_DECISIONS_ET_DONNEES_MANQUANTES.md`
7. `07_TRACEABILITE.md`

Le contenu V1 est conservé intégralement dans `01_SOURCE_BASELINE.md`.
