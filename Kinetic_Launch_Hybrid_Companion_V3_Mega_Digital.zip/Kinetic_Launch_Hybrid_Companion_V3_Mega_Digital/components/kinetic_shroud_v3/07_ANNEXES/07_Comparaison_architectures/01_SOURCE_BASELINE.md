# Comparaison conceptuelle

| Critère | Architecture empilée classique | Kinetic-Shroud concentrique |
|---|---|---|
| Héritage industriel | très élevé | très faible |
| Interfaces nouvelles | limitées | nombreuses |
| Séparation | axial/staging connu | latéral multi-segments à démontrer |
| Noyau continu | non nécessaire | objectif central |
| Risque d'interférence | connu/maîtrisé | élevé au départ |
| Réservoirs périphériques mobiles | généralement non | hypothèse spécifique |
| Certification | cadres établis | programme de preuve important |
| Potentiel modularité | élevé | potentiellement élevé |
| TRL global | élevé pour architectures existantes | ~1–2 pour concept spécifique |
