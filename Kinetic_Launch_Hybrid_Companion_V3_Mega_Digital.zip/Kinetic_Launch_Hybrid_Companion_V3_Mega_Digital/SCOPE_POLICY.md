# Scope policy

Allowed: software architecture, abstract state machines, digital twins, interface contracts, requirements, risk/V&V, planning, cost/effort, synthetic normalized health indicators, safe fault injection and documentation.

Excluded from generation: real propulsion sizing, propellant composition/recipe, oxidizer/fuel operating ratios, chamber/feed data, nozzle/grain/injector geometry, ignition design, real attachment/release loads or hardware sizing, launch trajectory/guidance/targeting, and weaponization. Unknown physical values remain external rather than guessed.
