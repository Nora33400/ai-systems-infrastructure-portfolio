from __future__ import annotations

DEPENDENCIES = {
    "shroud": ["launch_support", "attachment_release", "system_core"],
    "launch_support": ["attachment_release", "system_core"],
    "attachment_release": ["shroud", "system_core"],
    "hybrid_primary": ["system_core", "propulsion_coordination"],
    "hybrid_aux": ["system_core", "propulsion_coordination"],
    "fuel_surrogates": ["trade_study", "hybrid_primary", "hybrid_aux"],
}

def analyze(changed_domains:list[str]) -> dict:
    direct=set(changed_domains); impacted=set(changed_domains)
    frontier=list(changed_domains)
    while frontier:
        d=frontier.pop(0)
        for nxt in DEPENDENCIES.get(d,[]):
            if nxt not in impacted:
                impacted.add(nxt); frontier.append(nxt)
    return {
        "changed":sorted(direct),
        "impacted":sorted(impacted),
        "retest_recommended":sorted(impacted | {"scope_guard","compatibility","event_ledger"}),
        "impact_count":len(impacted)
    }
