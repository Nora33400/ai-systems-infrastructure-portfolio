from __future__ import annotations
from dataclasses import dataclass

BLOCKED = {
    'propellant_recipe','fuel_formula','chemical_formula','oxidizer_name','oxidizer_fuel_ratio','o_f_ratio','mix_ratio',
    'chamber_pressure','mass_flow','massflow','nozzle_throat','nozzle_exit','expansion_ratio','grain_geometry','port_diameter',
    'regression_rate','ignition_energy','igniter','thrust_newton','thrust_n','specific_impulse','isp_seconds','hold_down_release_force',
    'release_force','bolt_diameter','bolt_preload','fastener_size','pyrotechnic','explosive_bolt','launch_azimuth','trajectory',
    'guidance_gain','target_coordinates','target_location','burn_time_seconds','combustion_temperature','injector_geometry',
    'orifice_diameter','tank_pressure','feed_pressure','oxidizer_flow','flight_ready_sizing','operational_propulsion',
    'weaponization','launch_profile','ramp_exit_velocity','ramp_exit_angle'
}

@dataclass
class Audit:
    allowed: bool
    hits: list[str]
    status: str

def _walk(v,path=''):
    if isinstance(v,dict):
        for k,x in v.items():
            p=f'{path}.{k}' if path else str(k)
            yield p,str(k),x
            yield from _walk(x,p)
    elif isinstance(v,list):
        for i,x in enumerate(v): yield from _walk(x,f'{path}[{i}]')

def audit(payload:dict)->Audit:
    hits=[]
    for path,key,val in _walk(payload):
        k=key.lower().replace('-','_').replace(' ','_')
        if any(b in k for b in BLOCKED): hits.append(path)
    scope=payload.get('scope',{}) if isinstance(payload,dict) else {}
    if scope.get('digital_only') is not True: hits.append('scope.digital_only')
    if scope.get('physical_build'): hits.append('scope.physical_build')
    if scope.get('flight_intent'): hits.append('scope.flight_intent')
    return Audit(not hits,sorted(set(hits)),'DIGITAL_SCOPE_OK' if not hits else 'REJECT_SCOPE')

def validate(payload:dict):
    a=audit(payload)
    if not a.allowed:
        raise ValueError('Out of digital-only scope: '+', '.join(a.hits))
    return a
