from __future__ import annotations
import argparse,json
from pathlib import Path
from .orchestrator import run

def main():
    ap=argparse.ArgumentParser(description='Kinetic Mega Digital V3 orchestrator')
    ap.add_argument('request'); ap.add_argument('--out',default='outputs/run'); ap.add_argument('--provenance')
    a=ap.parse_args(); req=json.loads(Path(a.request).read_text(encoding='utf-8'))
    prov=json.loads(Path(a.provenance).read_text(encoding='utf-8')) if a.provenance else {}
    snap=run(req,a.out,prov); print(json.dumps({'status':'OK','request_id':snap['request_id'],'final':snap['scenario']['final'],'readiness':snap['readiness']},ensure_ascii=False))
if __name__=='__main__': main()
