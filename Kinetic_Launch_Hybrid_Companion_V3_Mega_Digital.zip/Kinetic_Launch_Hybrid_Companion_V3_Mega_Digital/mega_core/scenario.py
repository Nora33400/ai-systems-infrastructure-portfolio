from __future__ import annotations

def simulate(inputs:dict,faults:list[str]|None=None):
    faults=set(faults or [])
    states=[]
    def add(step,system,state,reason): states.append({'step':step,'system':system,'state':state,'reason':reason})
    add(0,'system','SAFE_IDLE','initial digital state')
    if 'sensor_disagreement' in faults:
        add(1,'launch_support','SAFE_HOLD','sensor disagreement -> conservative hold')
        add(2,'attachment_release','LOCKED_LOGICAL','authorization withheld')
        final='SAFE_HOLD'
    elif 'primary_health_low' in faults:
        add(1,'launch_support','READY_LOGICAL','logical interlocks satisfied')
        add(2,'propulsion_coordination','GRACEFUL_DEGRADATION','primary digital health degraded')
        add(3,'attachment_release','LOCKED_LOGICAL','release remains abstract and inhibited')
        final='GRACEFUL_DEGRADATION'
    else:
        add(1,'launch_support','READY_LOGICAL','logical interlocks satisfied')
        add(2,'propulsion_coordination','DUAL_NOMINAL','surrogate health nominal')
        add(3,'attachment_release','ARMED_LOGICAL','abstract authorization path valid')
        add(4,'system','COMPLETE','digital scenario complete')
        final='COMPLETE'
    return {'final':final,'trace':states,'safe_terminal': final in {'COMPLETE','SAFE_HOLD','GRACEFUL_DEGRADATION'}}
