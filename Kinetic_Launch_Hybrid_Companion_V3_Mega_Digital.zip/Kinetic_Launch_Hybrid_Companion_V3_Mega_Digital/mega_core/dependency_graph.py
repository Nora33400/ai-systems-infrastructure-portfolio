from __future__ import annotations
from .change_impact import DEPENDENCIES

def graph() -> dict:
    nodes=sorted(set(DEPENDENCIES) | {x for xs in DEPENDENCIES.values() for x in xs})
    edges=[]
    for src,targets in DEPENDENCIES.items():
        for dst in targets: edges.append({"source":src,"target":dst,"kind":"logical_dependency"})
    return {"nodes":nodes,"edges":edges,"node_count":len(nodes),"edge_count":len(edges)}
