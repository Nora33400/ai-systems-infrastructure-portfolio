from __future__ import annotations

def evaluate(domains:dict):
    # Purely logical contracts, no physical sizing.
    checks=[
      ('IF-MEGA-001','shroud','launch_support','state_contract', bool(domains.get('shroud',True) and domains.get('launch_support',True))),
      ('IF-MEGA-002','attachment_release','shroud','authorization_contract', bool(domains.get('attachment_release',True) and domains.get('shroud',True))),
      ('IF-MEGA-003','hybrid_primary','system_core','health_contract', bool(domains.get('hybrid_primary',True))),
      ('IF-MEGA-004','hybrid_aux','system_core','health_contract', bool(domains.get('hybrid_aux',True))),
      ('IF-MEGA-005','fuel_surrogates','trade_study','ranking_contract', bool(domains.get('fuel_surrogates',True))),
    ]
    rows=[]
    for cid,src,dst,contract,active in checks:
        rows.append({'id':cid,'source':src,'target':dst,'contract':contract,'status':'COMPATIBLE' if active else 'NOT_REQUESTED'})
    active=[r for r in rows if r['status']!='NOT_REQUESTED']
    ratio=sum(r['status']=='COMPATIBLE' for r in active)/len(active) if active else 1.0
    return {'rows':rows,'compatibility_ratio':round(ratio,4)}
