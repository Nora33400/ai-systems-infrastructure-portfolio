from __future__ import annotations
import hashlib,json
from datetime import datetime,timezone

def canonical(obj): return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def digest(text:str): return hashlib.sha256(text.encode('utf-8')).hexdigest()
def append_event(ledger:list,event_type:str,payload:dict):
    prev=ledger[-1]['hash'] if ledger else 'GENESIS'
    event={'seq':len(ledger)+1,'type':event_type,'payload':payload,'prev_hash':prev}
    event['hash']=digest(canonical(event))
    ledger.append(event); return event

def verify(ledger:list):
    prev='GENESIS'
    for i,e in enumerate(ledger,1):
        if e.get('seq')!=i or e.get('prev_hash')!=prev: return False
        copy={k:v for k,v in e.items() if k!='hash'}
        if digest(canonical(copy))!=e.get('hash'): return False
        prev=e['hash']
    return True
