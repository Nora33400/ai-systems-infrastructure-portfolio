from __future__ import annotations
from itertools import combinations
from .scenario import simulate

FAULTS = ["sensor_disagreement", "primary_health_low"]

def run_campaign(inputs: dict) -> dict:
    cases=[]
    vectors=[[]]
    for r in range(1,len(FAULTS)+1):
        vectors.extend([list(x) for x in combinations(FAULTS,r)])
    for faults in vectors:
        result=simulate(inputs,faults)
        cases.append({"faults":faults,"final":result["final"],"safe_terminal":result["safe_terminal"]})
    safe=sum(c["safe_terminal"] for c in cases)
    return {"cases":cases,"safe_terminal_rate":round(safe/len(cases),4),"count":len(cases)}
