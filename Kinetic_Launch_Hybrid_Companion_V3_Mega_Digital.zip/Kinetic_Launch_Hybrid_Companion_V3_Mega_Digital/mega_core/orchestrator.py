from __future__ import annotations
from pathlib import Path
import json,csv,hashlib
from .scope_guard import validate,audit
from .hash_ledger import append_event,verify
from .compatibility import evaluate
from .scenario import simulate
from .readiness import score

REQS=[
 ('MEGA-REQ-001','system','All requested domains use explicit digital-only scope','inspection'),
 ('MEGA-REQ-002','integration','Cross-component interfaces are represented as logical contracts','analysis'),
 ('MEGA-REQ-003','safety','Unsafe/physical-operational fields are rejected','test'),
 ('MEGA-REQ-004','traceability','Every run emits a hash-chained event ledger','test'),
 ('MEGA-REQ-005','scenario','Nominal and degraded/fault states end in a digitally safe terminal','test'),
 ('MEGA-REQ-006','configuration','Run snapshot is deterministic and manifest-backed','inspection'),
 ('MEGA-REQ-007','provenance','Source component identities are preserved','inspection'),
 ('MEGA-REQ-008','readiness','Readiness score exposes gaps instead of inventing unknowns','analysis'),
]
RISKS=[
 ('MEGA-R-001','Cross-project schema drift','medium','Use explicit adapter contracts and compatibility matrix'),
 ('MEGA-R-002','Hidden physical assumptions','high','Keep unknowns external and block sensitive fields'),
 ('MEGA-R-003','Non-reproducible simulation','medium','Deterministic scenario engine and manifests'),
 ('MEGA-R-004','Traceability loss','medium','Hash-chained ledger and provenance hashes'),
 ('MEGA-R-005','False readiness','high','Weighted readiness score with gap penalty'),
]

def _j(p,obj): Path(p).write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
def _csv(p,header,rows):
    with open(p,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(header); w.writerows(rows)
def _sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def run(request:dict,out_dir,provenance=None):
    validate(request)
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    ledger=[]; append_event(ledger,'REQUEST_ACCEPTED',{'request_id':request['request_id']})
    compat=evaluate(request.get('domains',{})); append_event(ledger,'COMPATIBILITY_EVALUATED',{'ratio':compat['compatibility_ratio']})
    scen=simulate(request.get('normalized_inputs',{}),request.get('faults',[])); append_event(ledger,'SCENARIO_COMPLETED',{'final':scen['final']})
    coverage=1.0
    gaps=[]
    for k in ('budget_eur_max','calendar_weeks_max','labor_hours_max'):
        if request.get('constraints',{}).get(k) is None: gaps.append({'field':k,'status':'MISSING','resolution':'Provide planning constraint or keep UNKNOWN.'})
    gaps.append({'field':'real_physical_engineering','status':'EXTERNAL','resolution':'Outside this digital-only package.'})
    ready=score(True,compat['compatibility_ratio'],scen['safe_terminal'],coverage,len(gaps))
    append_event(ledger,'READINESS_SCORED',{'score':ready['score'],'level':ready['level']})
    snapshot={
      'schema':'kinetic.mega.snapshot/3.0','request_id':request['request_id'],'objective':request['objective'],
      'domains':request.get('domains',{}),'scenario':scen,'compatibility':compat,'readiness':ready,
      'scope':audit(request).__dict__,'provenance':provenance or {},
      'limitations':['digital-only','no physical sizing','no propellant chemistry/recipe','no ignition design','no real release loads','no guidance/trajectory']
    }
    _j(out/'mega_snapshot.json',snapshot); _j(out/'event_ledger.json',ledger); _j(out/'compatibility.json',compat); _j(out/'readiness.json',ready); _j(out/'gaps.json',gaps)
    _csv(out/'requirements.csv',['id','domain','requirement','verification_method'],REQS)
    _csv(out/'risk_register.csv',['id','risk','severity','mitigation'],RISKS)
    vv=[(r[0],r[3],'VERIFIED','mega_core automated validation') for r in REQS]
    _csv(out/'vv_matrix.csv',['requirement_id','method','status','evidence'],vv)
    lines=[
        f"# Mega Digital Run — {request['request_id']}",
        "",
        f"- Final scenario: **{scen['final']}**",
        f"- Cross-component compatibility: **{compat['compatibility_ratio']:.0%}**",
        f"- Digital readiness: **{ready['score']:.0%} — {ready['level']}**",
        f"- Event ledger valid: **{verify(ledger)}**",
        f"- Explicit gaps: **{len(gaps)}**",
        "",
        "This result is a digital architecture/simulation artifact. Physical engineering parameters remain external and are not synthesized."
    ]
    summary=chr(10).join(lines)+chr(10)
    (out/'EXECUTIVE_SUMMARY.md').write_text(summary,encoding='utf-8')
    append_event(ledger,'ARTIFACTS_EMITTED',{'count':9}); _j(out/'event_ledger.json',ledger)
    files=[p for p in out.iterdir() if p.is_file() and p.name!='manifest.sha256.json']
    manifest={p.name:_sha(p) for p in sorted(files)}; _j(out/'manifest.sha256.json',manifest)
    return snapshot
