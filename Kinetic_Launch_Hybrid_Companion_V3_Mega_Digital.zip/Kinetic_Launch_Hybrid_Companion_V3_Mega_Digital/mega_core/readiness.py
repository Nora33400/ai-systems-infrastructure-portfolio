from __future__ import annotations

def score(scope_ok:bool,compat:float,scenario_safe:bool,requirements_coverage:float,gap_count:int):
    parts={
      'scope':1.0 if scope_ok else 0.0,
      'compatibility':compat,
      'safe_scenario':1.0 if scenario_safe else 0.0,
      'requirements_coverage':max(0.0,min(1.0,requirements_coverage)),
      'gap_penalty':max(0.0,1.0-min(gap_count,10)/10),
    }
    weights={'scope':0.30,'compatibility':0.20,'safe_scenario':0.20,'requirements_coverage':0.20,'gap_penalty':0.10}
    total=sum(parts[k]*weights[k] for k in parts)
    level='DIGITAL_READY' if total>=0.90 else 'DIGITAL_READY_WITH_GAPS' if total>=0.70 else 'DIGITAL_INCOMPLETE'
    return {'score':round(total,4),'level':level,'components':parts,'weights':weights}
