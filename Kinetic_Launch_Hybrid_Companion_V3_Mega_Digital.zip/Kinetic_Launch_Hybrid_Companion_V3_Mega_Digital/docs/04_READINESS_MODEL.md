# Digital readiness model

The score combines scope compliance (30%), cross-project compatibility (20%), safe scenario terminal (20%), requirements coverage (20%) and explicit-gap penalty (10%). It describes digital integration readiness only and must not be interpreted as flight or hardware readiness.
