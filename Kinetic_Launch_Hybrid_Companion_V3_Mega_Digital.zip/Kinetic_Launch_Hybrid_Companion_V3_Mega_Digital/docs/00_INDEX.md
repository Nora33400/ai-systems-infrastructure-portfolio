# Documentation index

1. `01_MEGA_ARCHITECTURE.md` — unified architecture.
2. `02_CROSS_PROJECT_INTERFACES.md` — logical interface contracts.
3. `03_EVENT_LEDGER_AND_PROVENANCE.md` — reproducibility and integrity.
4. `04_READINESS_MODEL.md` — digital readiness score.
5. `05_SCENARIO_AND_FAULT_MODEL.md` — safe state simulation.
6. `06_MIGRATION_V2_TO_V3.md` — migration path.
7. `07_INTEGRATION_AIONE.md` — integration contract.
8. `08_RELEASE_CRITERIA.md` — release gates.
