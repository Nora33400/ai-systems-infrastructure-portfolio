# Release criteria

A V3 package release passes when: all automated tests pass; both source component tests pass; nominal/fault scenarios produce safe digital terminals; scope rejection tests pass; event ledger verifies; source provenance hashes exist; per-run manifests verify; no cache/transient build files are packaged.
