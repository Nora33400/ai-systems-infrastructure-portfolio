# Mega architecture

`mega_core` is the umbrella orchestration layer. Existing projects remain intact under `components/`. A request is scope-audited, then evaluated through compatibility, deterministic scenario simulation, gap extraction, readiness scoring, traceability ledger and manifest generation.

The architecture uses normalized health/state values only; it does not infer physical flight parameters.
