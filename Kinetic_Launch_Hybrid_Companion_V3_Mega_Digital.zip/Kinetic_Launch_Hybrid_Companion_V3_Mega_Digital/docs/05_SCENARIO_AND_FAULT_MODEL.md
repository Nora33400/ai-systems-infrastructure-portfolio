# Scenario and fault model

Nominal: SAFE_IDLE → READY_LOGICAL → DUAL_NOMINAL → ARMED_LOGICAL → COMPLETE.

Sensor disagreement: SAFE_HOLD and release remains LOCKED_LOGICAL.

Primary health fault: GRACEFUL_DEGRADATION and release remains logically inhibited.

These are software states and do not encode physical release timing or actuation values.
