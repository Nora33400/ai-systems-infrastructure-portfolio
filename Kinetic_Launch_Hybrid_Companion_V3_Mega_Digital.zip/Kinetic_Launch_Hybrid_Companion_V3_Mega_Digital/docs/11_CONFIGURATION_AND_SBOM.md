# Configuration and software inventory

The V3 package is intentionally standard-library-only at runtime. Pytest is used only for validation. `SOFTWARE_BOM.json` records the Python package surface and source component versions, while SHA-256 manifests provide file-level integrity evidence.
