# Event ledger and provenance

Every mega run creates a canonical hash-chained event ledger. Each event references the previous hash. `config/provenance.json` records SHA-256 hashes for both source ZIPs. Per-run `manifest.sha256.json` covers emitted artifacts.
