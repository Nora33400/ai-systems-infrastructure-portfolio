# Change impact and regression

V3 adds a logical dependency graph and a change-impact analyzer. When a digital domain changes, the tool computes downstream domains that should be re-tested. This is meant for software/configuration regression planning; it does not derive physical design consequences.

Example: modifying `fuel_surrogates` marks trade-study ranking, primary/auxiliary surrogate models, propulsion coordination and system-core contracts as impacted.
