# Cross-project interfaces

Interfaces are contracts between abstract domains rather than hardware specifications. They carry logical state, authorization, health-surrogate and trade-study ranking information. This prevents accidental coupling to real dimensions, forces, pressures, chemistry or trajectory.
