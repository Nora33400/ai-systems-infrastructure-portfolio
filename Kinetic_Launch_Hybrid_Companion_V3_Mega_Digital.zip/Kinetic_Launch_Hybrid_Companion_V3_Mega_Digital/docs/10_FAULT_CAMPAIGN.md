# Fault campaign

The mega layer exhaustively runs the small abstract fault catalogue currently defined by the package, including combined faults. The release criterion is a 100% digitally safe terminal rate. Fault states contain no real timing, force, pressure or actuation parameters.
