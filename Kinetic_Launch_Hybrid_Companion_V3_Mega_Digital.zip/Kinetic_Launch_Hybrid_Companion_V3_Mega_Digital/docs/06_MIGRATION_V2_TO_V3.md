# Migration V2 → V3

- Existing Launch/Hybrid V2 files remain in `components/launch_hybrid_v2`.
- Existing Shroud V3 files remain in `components/kinetic_shroud_v3`.
- New work should enter through `templates/mega_request_template.json` and `mega_core`.
- Legacy outputs remain valid as component-level evidence; V3 adds ecosystem-level compatibility, ledger and readiness artifacts.
