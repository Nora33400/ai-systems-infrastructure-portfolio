# AIONE integration

Recommended routing key: `kinetic.mega.digital.v3`. Inputs are validated JSON requests; outputs are immutable run folders with snapshot, compatibility, readiness, gaps, requirements/V&V/risk matrices, event ledger and manifest. The adapter must keep execution digital-only and reject operational physical fields.
