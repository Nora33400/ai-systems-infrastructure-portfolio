@echo off
python scripts\validate_package.py
if errorlevel 1 exit /b %errorlevel%
