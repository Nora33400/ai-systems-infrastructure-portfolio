from mega_core.scenario import simulate

def test_nominal(): assert simulate({},[])['final']=='COMPLETE'
def test_sensor_fault(): assert simulate({},['sensor_disagreement'])['final']=='SAFE_HOLD'
def test_primary_fault(): assert simulate({},['primary_health_low'])['final']=='GRACEFUL_DEGRADATION'
def test_all_safe_terminal():
    for f in ([],['sensor_disagreement'],['primary_health_low']): assert simulate({},f)['safe_terminal']
