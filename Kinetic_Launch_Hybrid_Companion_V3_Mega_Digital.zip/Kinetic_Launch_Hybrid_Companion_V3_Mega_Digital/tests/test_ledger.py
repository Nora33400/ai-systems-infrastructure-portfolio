from mega_core.hash_ledger import append_event,verify

def test_ledger_valid():
    l=[]; append_event(l,'A',{'x':1}); append_event(l,'B',{'y':2}); assert verify(l)
def test_ledger_tamper():
    l=[]; append_event(l,'A',{'x':1}); l[0]['payload']['x']=2; assert not verify(l)
