from mega_core.change_impact import analyze
from mega_core.dependency_graph import graph

def test_change_impact_propagates():
    r=analyze(["fuel_surrogates"])
    assert "hybrid_primary" in r["impacted"] and "system_core" in r["impacted"]

def test_dependency_graph_nonempty():
    g=graph(); assert g["node_count"]>=8 and g["edge_count"]>=8
