from mega_core.readiness import score

def test_readiness_bounds():
    s=score(True,1.0,True,1.0,1); assert 0<=s['score']<=1 and s['level'] in {'DIGITAL_READY','DIGITAL_READY_WITH_GAPS','DIGITAL_INCOMPLETE'}
