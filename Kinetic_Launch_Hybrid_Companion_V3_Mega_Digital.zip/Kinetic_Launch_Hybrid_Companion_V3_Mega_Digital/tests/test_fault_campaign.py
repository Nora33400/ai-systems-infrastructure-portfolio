from mega_core.fault_campaign import run_campaign

def test_campaign_safe():
    r=run_campaign({})
    assert r["count"]==4
    assert r["safe_terminal_rate"]==1.0
