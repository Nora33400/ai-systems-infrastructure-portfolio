from mega_core.compatibility import evaluate

def test_full_compat():
    d={'shroud':True,'launch_support':True,'attachment_release':True,'hybrid_primary':True,'hybrid_aux':True,'fuel_surrogates':True}
    assert evaluate(d)['compatibility_ratio']==1.0
