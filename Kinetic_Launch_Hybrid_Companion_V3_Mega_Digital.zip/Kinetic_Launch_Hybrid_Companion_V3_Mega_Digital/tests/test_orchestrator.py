import json
from pathlib import Path
from mega_core.orchestrator import run
from mega_core.hash_ledger import verify

def req(): return {'request_id':'T','objective':'test','scope':{'digital_only':True,'physical_build':False,'flight_intent':False},'domains':{'shroud':True,'launch_support':True,'attachment_release':True,'hybrid_primary':True,'hybrid_aux':True,'fuel_surrogates':True},'faults':[],'constraints':{}}
def test_run(tmp_path):
    s=run(req(),tmp_path,{'x':{'sha256':'abc'}}); assert s['scenario']['final']=='COMPLETE'
    ledger=json.loads((tmp_path/'event_ledger.json').read_text()); assert verify(ledger)
    assert (tmp_path/'manifest.sha256.json').exists()
