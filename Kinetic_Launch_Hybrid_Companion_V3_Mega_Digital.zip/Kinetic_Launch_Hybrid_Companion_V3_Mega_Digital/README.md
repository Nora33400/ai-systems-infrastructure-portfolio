# Kinetic Launch + Shroud V3 Mega Digital Upgrade

This package unifies the previous Launch/Hybrid V2 Super Digital package and Kinetic Shroud V3 Digital implementation into a single **digital-only project ecosystem**.

## What is new

- Mega orchestrator spanning Shroud, launch-support, attachment/release, primary/auxiliary hybrid surrogates and fuel-surrogate trade studies.
- Cross-project compatibility matrix and logical interface contracts.
- Deterministic scenario engine with nominal, graceful-degradation and safe-hold paths.
- Hash-chained event ledger and SHA-256 artifact manifests.
- Weighted digital readiness score with explicit gap penalty.
- Unified request/snapshot schemas, templates, examples and CLI.
- Provenance hashes for both source ZIPs.
- Component copies retained under `components/` for auditability and migration.
- Local validation scripts and automated tests.

## Run

```bash
python -m mega_core examples/request_nominal.json --out outputs/my_run --provenance config/provenance.json
python scripts/validate_package.py
```

## Boundary

The package intentionally does **not** synthesize physical build parameters, propellant recipes or chemistry, ignition design, real release loads, engine geometry, flight guidance or trajectory. Those are not needed for the digital project architecture, workflow, traceability and simulation layer implemented here.
