from pathlib import Path
import subprocess,sys,json,hashlib,os
ROOT=Path(__file__).resolve().parents[1]
def run(cmd,cwd=ROOT):
    p=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True)
    print('$',' '.join(map(str,cmd))); print(p.stdout); print(p.stderr,file=sys.stderr)
    if p.returncode: raise SystemExit(p.returncode)

def main():
    run([sys.executable,'-m','pytest','-q','tests'])
    run([sys.executable,'-m','mega_core','examples/request_nominal.json','--out','outputs/validation_nominal','--provenance','config/provenance.json'])
    run([sys.executable,'-m','mega_core','examples/request_fault_safe_hold.json','--out','outputs/validation_fault','--provenance','config/provenance.json'])
    # Existing component tests
    launch=ROOT/'components/launch_hybrid_v2'; run([sys.executable,'-m','pytest','-q','tests'],launch)
    shroud=ROOT/'components/kinetic_shroud_v3/08_IMPLEMENTATION_NUMERIQUE'; run([sys.executable,'-m','pytest','-q','tests'],shroud)
    # Sensitive request must fail
    p=subprocess.run([sys.executable,'-m','mega_core','examples/request_rejected_sensitive.json','--out','outputs/should_not_exist'],cwd=ROOT,text=True,capture_output=True)
    if p.returncode==0: raise SystemExit('sensitive request unexpectedly accepted')
    print('Sensitive-scope rejection: PASS')
    print('MEGA VALIDATION: PASS')
if __name__=='__main__': main()
