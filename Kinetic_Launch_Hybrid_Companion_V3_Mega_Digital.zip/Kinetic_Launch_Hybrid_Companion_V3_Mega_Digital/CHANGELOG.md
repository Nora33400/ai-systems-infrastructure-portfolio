# Changelog

## 3.0.0 Mega Digital Upgrade
- Unified two source projects under one orchestrated package.
- Added mega_core orchestration, compatibility, event ledger, readiness and scenario layers.
- Added schemas, provenance, interface contracts, migration guide, examples and CI-style validation.
- Preserved digital-only safety boundary.
